package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.ProjectType;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.domain.enums.RepositoryTypeEnum;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.ProjectTypeRepository;
import com.pichincha.repositorylog.service.models.MetricDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@SpringBootTest
@ActiveProfiles("test")
public class MetricsApiImplTest {
    @Autowired
    private MetricsApiImpl metricsApi;

    @MockBean
    private MetricUsageRepository metricUsageRepository;

    @MockBean
    private ProjectTypeRepository projectTypeRepository;

    @MockBean
    private GovernmentMetricRepository governmentMetricRepository;


    @Test
    public void shouldBeCreateMetrics(){
        ProjectType projectType=new ProjectType();
        projectType.setIdProjectType(1L);
        projectType.setName(RepositoryTypeEnum.MTM.name());
        projectType.setDescription("Microservicio Tradicional con MVC");

        GovernmentMetric governmentMetric = new GovernmentMetric();
        governmentMetric.setIsOptimus(true);
        Mockito.when(metricUsageRepository.getRepositoriesByNameAndCode(Mockito.any(),Mockito.any())).thenReturn(new ArrayList<>());
        Mockito.when(projectTypeRepository.findProjectTypeByName(Mockito.any())).thenReturn(projectType);
        Mockito.when(governmentMetricRepository.getGovernmentMetricByRepositoryLogId(Mockito.any())).thenReturn(governmentMetric);
        Assertions.assertEquals(HttpStatus.CREATED,metricsApi.createMetricsUsage(getMetricDto()).getStatusCode());
    }

    @Test
    public void shouldBeGetAllMetrics(){
        RepositoryGit repositoryGit=new RepositoryGit();
        List<RepositoryGit> listRepo= new ArrayList<>();
        repositoryGit.setProjectType(new ProjectType());
        repositoryGit.getProjectType().setName("MF");
        repositoryGit.setCelula("CEL1");
        repositoryGit.setVersion("1.0.0");
        repositoryGit.setTribe("ARQ");
        repositoryGit.setType("FRONT");
        repositoryGit.setRepositoryUri("http://repo");
        repositoryGit.setCreateDate(new Date());
        repositoryGit.setCommitterEmailCreation("sroblesd@pichincha.com");
        repositoryGit.setCommitterEmailModification("sroblesd@pichincha.com");
        listRepo.add(repositoryGit);
        Mockito.when(metricUsageRepository.findAll()).thenReturn(listRepo);
        Assertions.assertEquals(HttpStatus.OK,metricsApi.getAllMetrics().getStatusCode());
    }


    private MetricDto getMetricDto(){
        MetricDto metricDto=new MetricDto();
        metricDto.setRepositoryName("frm-msa-test");
        metricDto.setIdRepository("48857885");
        metricDto.setIdProject("45885885");
        metricDto.setBranch("feature/develop");

        metricDto.setContentFile("eyAgInR5cGUiOiJNSE0iLCAgIm9wdGltdXNWZXJzaW9uIjoiMS4wLjEiLCAgImRhdGVPcHRpbXVzVmVyc2lvbiI6IjIwMjMtMDUtMjQiLCAgImNyZWF0ZWRCeUVtYWlsIjoic3JvYmxlc2RAcGljaGluY2hhLmNvbSIsICAidHJpYmUiOiJBUlFVSVRFQ1RVUkEgREUgREVTQVJST0xMTyIsICAiY2VsdWxhIjoiU1FVQUQgREUgQVJRVUlURUNUVVJBIiwgICJjcmVhdGVEYXRlIjoiMjAyMy0wNy0xMCJ9");
        metricDto.setRepositoryUri("http://duuufuuf/repo");
        metricDto.setType(MetricDto.TypeEnum.BACK);
        return metricDto;
    }
}
