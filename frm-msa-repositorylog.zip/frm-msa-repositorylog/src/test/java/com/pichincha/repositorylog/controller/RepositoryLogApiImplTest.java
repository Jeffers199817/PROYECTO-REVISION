package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.RepositoryGitRepository;

import com.pichincha.repositorylog.service.mapper.MapStructMapper;
import com.pichincha.repositorylog.service.models.RepositoryDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SpringBootTest
public class RepositoryLogApiImplTest {

    @Autowired
    private RepositoryLogApiImpl repositoryLogApi;

    @MockBean
    private RepositoryGitRepository repositoryGitRepository;

    @MockBean
    private GovernmentMetricRepository governmentMetricRepository;

    @MockBean
    private MapStructMapper mapper;

    @Test
    public void shouldBeFindRepositoryByName(){
        List<RepositoryGit> logs=new ArrayList<>();
        logs.add(new RepositoryGit());
        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.getRepositoryByName(Mockito.any())).thenReturn(logs);
        Assertions.assertEquals(repositoryLogApi.findRepositoryByName("optimus").getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void  shouldBeGetAllLogRepository(){
        List<RepositoryGit> logs=new ArrayList<>();
        logs.add(new RepositoryGit());
        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.findAll()).thenReturn(logs);
        Assertions.assertEquals(repositoryLogApi.getAllRepository().getBody().size(),1);
    }

    @Test
    public void shouldBeCreateLog(){
        Mockito.when(mapper.repositoryDTOTORepositoryGit(Mockito.any())).thenReturn(new RepositoryGit());
        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.save(Mockito.any())).thenReturn(new RepositoryGit());
        Assertions.assertNotNull(repositoryLogApi.createLogRepo(new RepositoryDTO()).getBody());
    }

}
