package com.pichincha.repositorylog.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class NamingRepositoryUtilOtherTest {

    @Test
    void shouldCheckComplianceWithValidName() {
        Assertions.assertTrue(NamingRepositoryUtil.checkCompliance("bbe-msa-ux-test-naming"));
    }

    @Test
    void shouldNotCheckComplianceWithInvalidName() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("invalid-name"));
    }
    
    @Test
    void shouldNotCheckComplianceWithInvalidNameLikeBlank() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance(""));
    }
    
    @Test
    void shouldNotCheckComplianceWithInvalidNameFrmMsa() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("frm-msa"));
    }
    
    @Test
    void shouldNotCheckComplianceWithInvalidNameXxxMsa() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("xxx-msa"));
    }

    @Test
    void shouldNotCheckComplianceWithShortName() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("short"));
    }

    @Test
    void shouldNotCheckComplianceWithIncorrectOwner() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("invalid-msa-ux-test-naming"));
    }

    @Test
    void shouldNotCheckComplianceWithIncorrectAppType() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("bbe-invalid-ux-test-naming"));
    }

    @Test
    void shouldNotCheckComplianceWithIncorrectDDDType() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("bbe-msa-invalid-test-naming"));
    }

    @Test
    void shouldNotCheckComplianceWithIncorrectBIANType() {
        Assertions.assertFalse(NamingRepositoryUtil.checkCompliance("bbe-msa-dm-invalid-test-naming"));
    }
}