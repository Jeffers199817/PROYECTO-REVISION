package com.pichincha.repositorylog.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.service.RepositoryGitService;
import com.pichincha.repositorylog.service.models.RepositoryDTO;

@SpringBootTest
class RepositoryLogApiImplOtherTest {

    @Mock
    private RepositoryGitService repositoryGitService;

    @InjectMocks
    private RepositoryLogApiImpl repositoryLogApi;
    
    private static final String TEST_REPO = "testRepo";

    @Test
    void shouldCreateLogRepo() {
        RepositoryDTO repositoryDTO = new RepositoryDTO();
        Mockito.when(repositoryGitService.createLogRepository(repositoryDTO)).thenReturn(repositoryDTO);
        ResponseEntity<RepositoryDTO> response = repositoryLogApi.createLogRepo(repositoryDTO);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
        Assertions.assertEquals(repositoryDTO, response.getBody());
    }

    @Test
    void shouldFindRepositoryByName() {
        List<RepositoryDTO> repositoryDTOList = new ArrayList<>();
        repositoryDTOList.add(new RepositoryDTO());
        Mockito.when(repositoryGitService.getLogRepositoryByName(TEST_REPO)).thenReturn(repositoryDTOList);
        ResponseEntity<List<RepositoryDTO>> response = repositoryLogApi.findRepositoryByName(TEST_REPO);
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals(repositoryDTOList, response.getBody());
    }

    @Test
    void shouldReturnNoContentWhenNoRepositoryFoundByName() {
        Mockito.when(repositoryGitService.getLogRepositoryByName(TEST_REPO)).thenThrow(NoResultsException.class);
        ResponseEntity<List<RepositoryDTO>> response = repositoryLogApi.findRepositoryByName(TEST_REPO);
        Assertions.assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Test
    void shouldGetAllRepository() {
        List<RepositoryDTO> repositoryDTOList = new ArrayList<>();
        repositoryDTOList.add(new RepositoryDTO());
        Mockito.when(repositoryGitService.getAllLogsRepository()).thenReturn(repositoryDTOList);
        ResponseEntity<List<RepositoryDTO>> response = repositoryLogApi.getAllRepository();
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals(repositoryDTOList, response.getBody());
    }

    @Test
    void shouldReturnNoContentWhenNoRepositoryLogs() {
        Mockito.when(repositoryGitService.getAllLogsRepository()).thenThrow(NoResultsException.class);
        ResponseEntity<List<RepositoryDTO>> response = repositoryLogApi.getAllRepository();
        Assertions.assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }
}

