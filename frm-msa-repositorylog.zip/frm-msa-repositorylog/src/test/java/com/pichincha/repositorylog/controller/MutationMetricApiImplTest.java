package com.pichincha.repositorylog.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.ConfigDataApplicationContextInitializer;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.pichincha.repositorylog.service.MutationMetricService;
import com.pichincha.repositorylog.service.models.MutationMetricDto;

@ExtendWith({MockitoExtension.class, SpringExtension.class})
@ContextConfiguration(initializers = ConfigDataApplicationContextInitializer.class)
class MutationMetricApiImplTest {

	private MutationMetricService mutationMetricService = mock(MutationMetricService.class);

	private MutationMetricsApi mutationMetricsApi = new MutationMetricApiImpl(mutationMetricService);

	@Test
	void test() {
		MutationMetricDto mutationMetricDto = new MutationMetricDto()
				.idRepository(UUID.randomUUID().toString())
				.branch("head/master")
				.coverageRate(BigDecimal.valueOf(75.0))
				.mutationRate(BigDecimal.valueOf(60.0));
		
		when(mutationMetricService.save(mutationMetricDto)).thenReturn(mutationMetricDto);
		
		assertEquals(HttpStatus.CREATED, mutationMetricsApi.saveMutationMetric(mutationMetricDto).getStatusCode());
	}
}