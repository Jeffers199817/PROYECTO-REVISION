package com.pichincha.repositorylog.service.impl;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.ProjectTypeRepository;
import com.pichincha.repositorylog.service.MetricsService;
import com.pichincha.repositorylog.service.models.MetricDto;
import com.pichincha.repositorylog.service.models.MetricDto.TypeEnum;

class MetricsServiceImplOtherTest {

	private MetricUsageRepository metricUsageRepository = mock(MetricUsageRepository.class);

	private GovernmentMetricRepository governmentMetricRepository = mock(GovernmentMetricRepository.class);

	private ProjectTypeRepository projectTypeRepository = mock(ProjectTypeRepository.class);

	private MetricsService metricsService = new MetricsServiceImpl(metricUsageRepository, projectTypeRepository, governmentMetricRepository);

	@Test
	void shouldCreateMetricUsageWhenRepositoryDoesNotExist() throws IOException {
		MetricDto metricDto = new MetricDto();
		metricDto.setIdRepository("testId");
		metricDto.setBranch("testBranch");
		metricDto.setType(TypeEnum.BACK);
		metricDto.setFileName("frm-msa-test-microserviceV1.java");
		metricDto.setRepositoryName("frm-msa-test-microserviceV1");
		metricDto.setContentFile("ew0KCSJ0ZXN0IjogInRlc3QiDQp9");
		when(metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch())).thenReturn(new ArrayList<>());
		MetricDto response = metricsService.createMetricUsage(metricDto);
		verify(governmentMetricRepository, times(1)).save(any());
		assertNotNull(response);
	}

	@Test
	void shouldUpdateMetricUsageWhenRepositoryExists() throws IOException {
		MetricDto metricDto = new MetricDto();
		metricDto.setIdRepository("testId");
		metricDto.setBranch("testBranch");
		metricDto.setType(TypeEnum.BACK);
		metricDto.setFileName("frm-msa-test-microserviceV2.java");
		metricDto.setRepositoryName("frm-msa-test-microserviceV2");
		metricDto.setContentFile("ew0KCSJ0ZXN0IjogInRlc3QiDQp9");
		List<RepositoryGit> repositoryGitList = new ArrayList<>();
		repositoryGitList.add(new RepositoryGit());
		when(metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch())).thenReturn(repositoryGitList);
		metricsService.createMetricUsage(metricDto);
		verify(governmentMetricRepository, times(1)).save(any());
	}

	@Test
	void shouldReturnAllMetricsUsage() {
		List<RepositoryGit> repositoryGitList = new ArrayList<>();
		RepositoryGit repositoryGit = new RepositoryGit();

		repositoryGit.setCreateDate(new Date());

		repositoryGitList.add(repositoryGit);
		when(metricUsageRepository.findAll()).thenReturn(repositoryGitList);
		List<MetricDto> response = metricsService.getAllMetricsUsage();
		assertNotNull(response);
		assertFalse(response.isEmpty());
	}

	@Test
	void shouldThrowNoResultsExceptionWhenNoMetricsUsage() {
		when(metricUsageRepository.findAll()).thenReturn(new ArrayList<>());
		assertThrows(NoResultsException.class, () -> metricsService.getAllMetricsUsage());
	}
}