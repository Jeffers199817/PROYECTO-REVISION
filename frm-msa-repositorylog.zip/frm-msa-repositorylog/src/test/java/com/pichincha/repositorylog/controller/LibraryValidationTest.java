package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.domain.LibraryValidation;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.LibraryValidationRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.service.DetailLibraryValidationService;
import com.pichincha.repositorylog.service.models.MetricDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class LibraryValidationTest {
    @Autowired
    private LibrariesApiImpl librariesApi;

    @MockBean
    private MetricUsageRepository metricUsageRepository;

    @MockBean
    private DetailLibraryValidationService detailLibraryValidationService;

    @MockBean
    private LibraryValidationRepository libraryValidationRepository;

    @Test
    public void shouldBeLibraryValidation() throws IOException {
        MetricDto metricDto = getMetricDto();
        RepositoryGit repositoryGit=new RepositoryGit();
        List<RepositoryGit> list=new ArrayList<>();
        list.add(repositoryGit);
        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(Mockito.any(),Mockito.any())).thenReturn(list);
        Mockito.when(libraryValidationRepository.getLibraryValidationByRepositoryLogId(Mockito.any())).thenReturn(null);
        Assertions.assertEquals(librariesApi.createValidationLibrary("", metricDto).getStatusCode(), HttpStatus.CREATED);


    }
    @Test
    public void shouldThrowExceptionWhenDoesNotExistRepository() throws IOException {
        MetricDto metricDto = getMetricDto();
        List<RepositoryGit> list=new ArrayList<>();
        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(Mockito.any(),Mockito.any())).thenReturn(list);
        Mockito.when(libraryValidationRepository.getLibraryValidationByRepositoryLogId(Mockito.any())).thenReturn(null);

        Assertions.assertThrows(NoResultsException.class, () -> librariesApi.createValidationLibrary("", metricDto) );
    }

    @Test
    public void shouldUpdateLibraryValidationRepository() throws IOException {
        MetricDto metricDto = getMetricDto();
        RepositoryGit repositoryGit=new RepositoryGit();
        List<RepositoryGit> list=new ArrayList<>();
        list.add(repositoryGit);
        LibraryValidation libraryValidation = new LibraryValidation();
        libraryValidation.setConfigurationContentFile("hello-world");
        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(Mockito.any(),Mockito.any())).thenReturn(list);
        Mockito.when(libraryValidationRepository.getLibraryValidationByRepositoryLogId(Mockito.any())).thenReturn(libraryValidation);

        Assertions.assertEquals(librariesApi.createValidationLibrary("", metricDto).getStatusCode(), HttpStatus.CREATED);
    }

    private static MetricDto getMetricDto() {
        MetricDto metricDto = new MetricDto();
        metricDto.setType(MetricDto.TypeEnum.NONE);
        metricDto.setContentFile("ewogICJuYW1lIjogImZybS1tc2EtbWV0cmljcy1jcmF3bGVyIiwKICAidmVyc2lvbiI6ICIxLjAuMCIsCiAgImRlc2NyaXB0aW9uIjogIlRPRE86IEdpdmUgYSBzaG9ydCBpbnRyb2R1Y3Rpb24gb2YgeW91ciBwcm9qZWN0LiBMZXQgdGhpcyBzZWN0aW9uIGV4cGxhaW4gdGhlIG9iamVjdGl2ZXMgb3IgdGhlIG1vdGl2YXRpb24gYmVoaW5kIHRoaXMgcHJvamVjdC4iLAogICJtYWluIjogImRpc3QvbWFpbi5qcyIsCiAgInR5cGUiOiAibW9kdWxlIiwKICAic2NyaXB0cyI6IHsKICAgICJzdGFydCI6ICJ0c2MgJiYgbm9kZSAgLS1leHBlcmltZW50YWwtc3BlY2lmaWVyLXJlc29sdXRpb249bm9kZSAgLi9kaXN0L21haW4uanMgIC0tZW52LWZpbGU9Li4vLmVudiIsCiAgICAiamF2YSI6ICJ0c2MgJiYgbm9kZSAgLS1leHBlcmltZW50YWwtc3BlY2lmaWVyLXJlc29sdXRpb249bm9kZSAgLi9kaXN0L2phdmEuanMiCiAgfSwKICAicmVwb3NpdG9yeSI6IHsKICAgICJ0eXBlIjogImdpdCIsCiAgICAidXJsIjogImh0dHBzOi8vQmFuY29QaWNoaW5jaGFFQ0BkZXYuYXp1cmUuY29tL0JhbmNvUGljaGluY2hhRUMvYXJxLWZyYW1ld29yay9fZ2l0L2ZybS1tc2EtbWV0cmljcy1jcmF3bGVyIgogIH0sCiAgImF1dGhvciI6ICIiLAogICJsaWNlbnNlIjogIklTQyIsCiAgImRldkRlcGVuZGVuY2llcyI6IHsKICAgICJ0cy1ub2RlIjogIl4xMC45LjEiCiAgfSwKICAiZGVwZW5kZW5jaWVzIjogewogICAgImRvdGVudiI6ICJeMTYuMy4xIiwKICAgICJub2RlLWZldGNoIjogIl4zLjMuMiIsCiAgICAibm9kZS13b3JrZXItdGhyZWFkcy1wb29sIjogIl4xLjUuMSIsCiAgICAicGF0aCI6ICJeMC4xMi43IiwKICAgICJwZyI6ICJeOC4xMS4zIiwKICAgICJxdWVyeXN0cmluZyI6ICJeMC4yLjEiLAogICAgInhtbDJqcyI6ICJeMC42LjIiCiAgfQp9Cg==");
        metricDto.setBranch("feature/test");
        metricDto.setRepositoryUri("https://repository");
        metricDto.setRepositoryName("stf-msa-frontend");
        metricDto.setFileName("package.json");
        return metricDto;
    }

}
