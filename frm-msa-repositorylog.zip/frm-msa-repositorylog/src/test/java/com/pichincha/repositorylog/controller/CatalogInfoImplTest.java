package com.pichincha.repositorylog.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.pichincha.repositorylog.domain.CatalogInfoMetric;
import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.repository.CatalogInfoRepository;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.service.models.CatalogDto;

@SpringBootTest
class CatalogInfoImplTest {
	
	@Autowired
	private CatalogInfoImpl catalogInfoApi;

	@MockBean
	private MetricUsageRepository metricUsageRepository;

	@MockBean
	private CatalogInfoRepository catalogInfoRepository;

	@MockBean
	private GovernmentMetricRepository governmentMetricRepository;
	
	private static final String CONTENT = "ieurtyeurt";
	private static final String BRANCH = "feature/develop";
	private static final String URI = "https://repo";
	private static final String REPO_NAME = "stf-msa-micro";

	@Test
	void shouldCreateCatalogInfoMetric() throws IOException {
		CatalogDto catalogDto = new CatalogDto();
		catalogDto.setContentFile(CONTENT);
		catalogDto.setBranch(BRANCH);
		catalogDto.setRepositoryUri(URI);
		catalogDto.setRepositoryName(REPO_NAME);
		RepositoryGit repositoryGit = new RepositoryGit();
		List<RepositoryGit> list = new ArrayList<>();
		list.add(repositoryGit);
		GovernmentMetric governmentMetric = new GovernmentMetric();
		governmentMetric.setIsOptimus(true);

		when(metricUsageRepository.getRepositoriesByCodeAndBranch(any(), any())).thenReturn(list);
		when(governmentMetricRepository.getGovernmentMetricByRepositoryLogId(any())).thenReturn(governmentMetric);
		when(catalogInfoRepository.getCatalogInfoMetricByRepositoryLogId(any())).thenReturn(null);

		Assertions.assertEquals(HttpStatus.CREATED, catalogInfoApi.createCatalogInfoMetricsUsage(catalogDto).getStatusCode());
		
		CatalogInfoMetric catalogInfoMetric = CatalogInfoMetric.builder()
				.id(2L)
				.creationDate(new Date())
				.recordStatus("ACTIVO")
				.build();
		
		when(catalogInfoRepository.getCatalogInfoMetricByRepositoryLogId(any())).thenReturn(catalogInfoMetric);
		
		Assertions.assertEquals(HttpStatus.CREATED, catalogInfoApi.createCatalogInfoMetricsUsage(catalogDto).getStatusCode());
	}
	
	@Test
	void shouldNotCreateCatalogInfoMetric() throws IOException {
		CatalogDto catalogDto = new CatalogDto();
		catalogDto.setContentFile(CONTENT);
		catalogDto.setBranch(BRANCH);
		catalogDto.setRepositoryUri(URI);
		catalogDto.setRepositoryName(REPO_NAME);

		List<RepositoryGit> list = new ArrayList<>();
		GovernmentMetric governmentMetric = new GovernmentMetric();
		governmentMetric.setIsOptimus(true);

		when(metricUsageRepository.getRepositoriesByCodeAndBranch(any(), any())).thenReturn(list);
		when(governmentMetricRepository.getGovernmentMetricByRepositoryLogId(any())).thenReturn(governmentMetric);
		when(catalogInfoRepository.getCatalogInfoMetricByRepositoryLogId(any())).thenReturn(null);

		Assertions.assertEquals(HttpStatus.NO_CONTENT, catalogInfoApi.createCatalogInfoMetricsUsage(catalogDto).getStatusCode());
	}
}