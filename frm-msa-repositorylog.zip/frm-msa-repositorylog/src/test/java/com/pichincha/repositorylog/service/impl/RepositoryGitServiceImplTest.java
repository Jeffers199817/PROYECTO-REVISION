package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.RepositoryGitRepository;
import com.pichincha.repositorylog.service.mapper.MapStructMapper;
import com.pichincha.repositorylog.service.models.RepositoryDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@SpringBootTest
public class RepositoryGitServiceImplTest {

    @InjectMocks
    private RepositoryGitServiceImpl repositoryGitServiceImpl;

    @Mock
    private RepositoryGitRepository repositoryGitRepository;

    @Mock
    private MapStructMapper mapper;

    @Test
    public void  shouldBeGetAllLogRepository(){
        List<RepositoryGit> logs=new ArrayList<>();
        logs.add(new RepositoryGit());
        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.findAll()).thenReturn(logs);
        Assertions.assertEquals(repositoryGitServiceImpl.getAllLogsRepository().size(),1);
    }
    
    @Test
    public void shouldBeGetLogRepositoryByName(){
        List<RepositoryGit> logs=new ArrayList<>();
        logs.add(new RepositoryGit());
        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.getRepositoryByName(Mockito.any())).thenReturn(logs);
        Assertions.assertNotNull(repositoryGitServiceImpl.getLogRepositoryByName("name"));
    }

    @Test
    public void shouldBeCreateLog(){
        Mockito.when(mapper.repositoryDTOTORepositoryGit(Mockito.any())).thenReturn(new RepositoryGit());
        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.save(Mockito.any())).thenReturn(new RepositoryGit());
        Assertions.assertNotNull(repositoryGitServiceImpl.createLogRepository(new RepositoryDTO()));
    }

    @Test
    public void shouldBeErrorOnGetLogRepositoryByName(){
        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.getRepositoryByName(Mockito.any())).thenReturn(new ArrayList<>());
        Assertions.assertThrows(NoResultsException.class,()->{repositoryGitServiceImpl.getLogRepositoryByName("name");});
    }

    @Test
    public void  shouldBeErrorOnGetAllLogRepository(){

        Mockito.when(mapper.repositoryGitToRepositoryDTO(Mockito.any())).thenReturn(new RepositoryDTO());
        Mockito.when(repositoryGitRepository.findAll()).thenReturn(new ArrayList<>());
        Assertions.assertThrows(NoResultsException.class,()->{repositoryGitServiceImpl.getAllLogsRepository();});
    }
}
