package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.RepositoryGitRepository;
import com.pichincha.repositorylog.service.mapper.GovernmentMetricMapper;
import com.pichincha.repositorylog.service.models.PostOptimusRegisterRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class OptimusApiImplTest {

    private static final String MOCK_REPOSITORY_NAME = "testName";
    private static final String MOCK_REPOSITORY_ID = "testId";
    private static final String MOCK_CREATE_DATE = "2024-02-02 00:00:00";


    @InjectMocks
    private OptimusServiceImpl optimusService;

    @Mock
    private RepositoryGitRepository repositoryGitRepository;

    @Mock
    private GovernmentMetricRepository governmentMetricRepository;

    @Mock
    private GovernmentMetricMapper governmentMetricMapper;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(optimusService, "limitDateString", "2024-01-01 00:00:00");
    }

    @Test
    public void shouldNotFoundRepository() {
        PostOptimusRegisterRequest request = new PostOptimusRegisterRequest();
        request.setIdRepository("1");
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull("1", MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.empty());

        Exception exception = assertThrows(Exception.class, () ->
                optimusService.postOptimusRegister(request)
        );
        assertEquals("Repository not found: testName", exception.getMessage());
    }

    @Test
    public void shouldNotSaveRegister() {
        PostOptimusRegisterRequest request = new PostOptimusRegisterRequest();
        request.setIdRepository("1");
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull("1", MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.empty());
        when(governmentMetricMapper.toGovernmentMetric(request, new RepositoryGit())).thenReturn(new GovernmentMetric());

        doThrow(new IllegalArgumentException()).when(governmentMetricRepository).save(new GovernmentMetric());

        Exception exception = assertThrows(Exception.class, () -> optimusService.postOptimusRegister(request));
        assertEquals("Repository not found: testName", exception.getMessage());
    }

    @Test
    void shouldThrowRuntimeExceptionWhenSaveFails() {
        // Given
        PostOptimusRegisterRequest request = new PostOptimusRegisterRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);
        RepositoryGit repositoryGit = new RepositoryGit();
        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(request.getIdRepository(), request.getNameRepository()))
                .thenReturn(Optional.of(repositoryGit));
        GovernmentMetric governmentMetric = new GovernmentMetric();
        when(governmentMetricMapper.toGovernmentMetric(request, repositoryGit)).thenReturn(governmentMetric);
        when(governmentMetricRepository.save(governmentMetric)).thenThrow(new IllegalArgumentException());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> optimusService.postOptimusRegister(request));
        assertEquals("Error when save government metric repository: testName", exception.getMessage());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when Repository is Not Found")
    public void shouldValidateRepositoryByCodeAndName() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.empty());

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertFalse(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when GovernmentMetric is Not Found")
    public void shouldValidatePostOptimusValidateGovernmentMetricNotFound() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(optimusService.getDateByString(MOCK_CREATE_DATE));

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Optional.of(repositoryGit));
        when(governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repositoryGit))
                .thenReturn(Optional.empty());

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertFalse(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when GovernmentMetric has isOptimus null")
    public void shouldValidatePostOptimusValidateIsOptimusNull() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(optimusService.getDateByString(MOCK_CREATE_DATE));

        GovernmentMetric governmentMetric = new GovernmentMetric();
        governmentMetric.setIsOptimus(null);
        governmentMetric.setWithOptimus(null);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.of(repositoryGit));
        when(governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repositoryGit))
                .thenReturn(Optional.of(governmentMetric));

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertFalse(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when GovernmentMetric has with isOptimus true and withOptimus null")
    public void shouldValidatePostOptimusValidateIsOptimusTrueAndWithOptimusNull() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(optimusService.getDateByString(MOCK_CREATE_DATE));

        GovernmentMetric governmentMetric = new GovernmentMetric();
        governmentMetric.setIsOptimus(true);
        governmentMetric.setWithOptimus(null);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.of(repositoryGit));
        when(governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repositoryGit))
                .thenReturn(Optional.of(governmentMetric));

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertFalse(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when createDate is before to limitDate")
    public void shouldValidatePostOptimusValidateIsBeforeDate() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(optimusService.getDateByString("2023-12-31 00:00:00"));

        GovernmentMetric governmentMetric = new GovernmentMetric();

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.of(repositoryGit));
        when(governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repositoryGit))
                .thenReturn(Optional.of(governmentMetric));

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertTrue(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when createDate is after to limitDate and isOptimus is true and withOptimus is true")
    public void shouldValidatePostOptimusValidate() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(optimusService.getDateByString(MOCK_CREATE_DATE));

        GovernmentMetric governmentMetric = new GovernmentMetric();
        governmentMetric.setIsOptimus(true);
        governmentMetric.setWithOptimus(true);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.of(repositoryGit));
        when(governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repositoryGit))
                .thenReturn(Optional.of(governmentMetric));

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertTrue(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when createDate is after to limitDate and isOptimus is false and withOptimus is false")
    public void shouldValidatePostOptimusValidateWhenIsAfterButIsNotOptimus() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(optimusService.getDateByString(MOCK_CREATE_DATE));

        GovernmentMetric governmentMetric = new GovernmentMetric();
        governmentMetric.setIsOptimus(false);
        governmentMetric.setWithOptimus(false);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.of(repositoryGit));
        when(governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repositoryGit))
                .thenReturn(Optional.of(governmentMetric));


        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertFalse(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when createDate is after to limitDate and isOptimus is true and withOptimus is false")
    public void shouldValidatePostOptimusValidateWhenIsAfterButIsNotWithOptimus() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(optimusService.getDateByString(MOCK_CREATE_DATE));

        GovernmentMetric governmentMetric = new GovernmentMetric();
        governmentMetric.setIsOptimus(true);
        governmentMetric.setWithOptimus(false);

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.of(repositoryGit));
        when(governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repositoryGit))
                .thenReturn(Optional.of(governmentMetric));

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertFalse(response.getValid());
    }

    @Test
    @DisplayName("Test PostOptimusValidate when comparing dates get error Optimus false")
    void shouldValidatePostOptimusValidateWhenComparingDates() {
        PostOptimusValidateRequest request = new PostOptimusValidateRequest();
        request.setIdRepository(MOCK_REPOSITORY_ID);
        request.setNameRepository(MOCK_REPOSITORY_NAME);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setCreateDate(new Date());

        when(repositoryGitRepository.findByRepositoryCodeAndRepositoryNameAndBranchIsNull(MOCK_REPOSITORY_ID, MOCK_REPOSITORY_NAME))
                .thenReturn(Optional.of(repositoryGit));

        PostOptimusValidateResponse response = optimusService.postOptimusValidate(request);

        assertFalse(response.getValid());
    }

    @Test
    @DisplayName("Test getDateByString when date is wrong")
    void shouldValidateGetDateByStringInvalidDate() {
        String invalidDateString = "invalid-date";
        assertThrows(RuntimeException.class, () -> optimusService.getDateByString(invalidDateString));
    }
}
