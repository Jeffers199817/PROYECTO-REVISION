package com.pichincha.repositorylog.service.impl;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.domain.StandardValidation;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.StandardValidationRepository;
import com.pichincha.repositorylog.service.StandardValidationService;
import com.pichincha.repositorylog.service.models.MetricDto;

class StandardValidationServiceImplTest {

	private StandardValidationRepository standardValidationRepository = Mockito.mock(StandardValidationRepository.class);

	private MetricUsageRepository metricUsageRepository = Mockito.mock(MetricUsageRepository.class);

	private GovernmentMetricRepository governmentMetricRepository = Mockito.mock(GovernmentMetricRepository.class);

	private StandardValidationService standardValidationService = new StandardValidationServiceImpl(standardValidationRepository,
			metricUsageRepository, governmentMetricRepository);
	
	private MetricDto metricDto;
	
	@BeforeEach
	void beforeEach() {
		metricDto = new MetricDto();
        metricDto.setIdRepository("testRepo");
        metricDto.setBranch("testBranch");
        metricDto.setContentFile("testContent");
	}
    

    @Test
    void shouldCreateNewStandardValidationWhenNoneExists() {

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setIdRepository(1L);

        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch()))
                .thenReturn(Collections.singletonList(repositoryGit));
        Mockito.when(standardValidationRepository.getStandardValidationByRepositoryLogId(repositoryGit.getIdRepository()))
                .thenReturn(null);

        standardValidationService.createStandardValidation(metricDto);

        Mockito.verify(standardValidationRepository, Mockito.times(1)).save(Mockito.any(StandardValidation.class));
    }

    @Test
    void shouldCreateNewStandardValidationWhenExistingValidationHasDifferentContent() {
        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setIdRepository(2L);

        StandardValidation existingValidation = new StandardValidation();
        existingValidation.setContractFileContent("differentContent");

        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch()))
                .thenReturn(Collections.singletonList(repositoryGit));
        Mockito.when(standardValidationRepository.getStandardValidationByRepositoryLogId(repositoryGit.getIdRepository()))
                .thenReturn(existingValidation);

        standardValidationService.createStandardValidation(metricDto);

        Mockito.verify(standardValidationRepository, Mockito.times(2)).save(Mockito.any(StandardValidation.class));
    }

    @Test
    void shouldNotCreateNewStandardValidationWhenExistingValidationHasSameContent() {

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setIdRepository(3L);

        StandardValidation existingValidation = new StandardValidation();
        existingValidation.setContractFileContent("testContent");

        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch()))
                .thenReturn(Collections.singletonList(repositoryGit));
        Mockito.when(standardValidationRepository.getStandardValidationByRepositoryLogId(repositoryGit.getIdRepository()))
                .thenReturn(existingValidation);

        standardValidationService.createStandardValidation(metricDto);

        Mockito.verify(standardValidationRepository, Mockito.never()).save(Mockito.any(StandardValidation.class));
    }
}
