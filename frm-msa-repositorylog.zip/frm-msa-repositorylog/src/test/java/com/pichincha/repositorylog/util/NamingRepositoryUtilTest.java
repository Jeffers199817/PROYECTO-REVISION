package com.pichincha.repositorylog.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class NamingRepositoryUtilTest {
    @Test
    public void shouldCheckCompliance(){

        Assertions.assertTrue(NamingRepositoryUtil.checkCompliance("frm-mfa-ux-test-naming"));
    }
}
