package com.pichincha.repositorylog.controller;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.service.LibraryValidationService;
import com.pichincha.repositorylog.service.models.LibraryDetailDTO;
import com.pichincha.repositorylog.service.models.MetricDto;

@SpringBootTest
class LibrariesApiImplTest {

    @Mock
    private LibraryValidationService libraryValidationService;

    @InjectMocks
    private LibrariesApiImpl librariesApi;
    
    private static final String AUTHORIZATION = "authorization";

    @Test
    void shouldCreateValidationLibrary() {
        MetricDto metricDto = new MetricDto();
        Mockito.doNothing().when(libraryValidationService).createLibraryValidation(metricDto, AUTHORIZATION);
        ResponseEntity<Void> response = librariesApi.createValidationLibrary(AUTHORIZATION, metricDto);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    void shouldThrowExceptionWhenCreateValidationLibraryFails() {
        MetricDto metricDto = new MetricDto();
        Mockito.doThrow(RuntimeException.class).when(libraryValidationService).createLibraryValidation(metricDto, AUTHORIZATION);
        Assertions.assertThrows(RuntimeException.class, () -> librariesApi.createValidationLibrary(AUTHORIZATION, metricDto));
    }

    @Test
    void shouldGetAllLibraries() {
        List<LibraryDetailDTO> libraryDetailDTOList = null;
        Mockito.when(libraryValidationService.getAllLibraries(1)).thenReturn(libraryDetailDTOList);
        ResponseEntity<List<LibraryDetailDTO>> response = librariesApi.getAllLibraries(1);
        Assertions.assertEquals(libraryDetailDTOList, response.getBody());
    }

    @Test
    void shouldReturnNoContentWhenNoLibraries() {
        Mockito.when(libraryValidationService.getAllLibraries(1)).thenThrow(NoResultsException.class);
        ResponseEntity<List<LibraryDetailDTO>> response = librariesApi.getAllLibraries(1);
        Assertions.assertEquals(HttpStatus.NOT_IMPLEMENTED, response.getStatusCode());
    }
}