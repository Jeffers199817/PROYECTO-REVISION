package com.pichincha.repositorylog.controller;

import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.pichincha.repositorylog.service.DesignSystemService;
import com.pichincha.repositorylog.service.models.DesignSystemDto;

@SpringBootTest
class DesignSystemApiImplTest {

    @Mock
    private DesignSystemService designSystemService;

    @InjectMocks
    private DesignSystemApiImpl designSystemApi;

    @Test
    void shouldCreateDesignSystemMetricsUsage() throws IOException {
        DesignSystemDto designSystemDto = new DesignSystemDto();
        Mockito.when(designSystemService.createDesignSystemMetricsUsage(designSystemDto)).thenReturn(designSystemDto);
        ResponseEntity<DesignSystemDto> response = designSystemApi.createDesignSystemMetricsUsage(designSystemDto);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
        Assertions.assertEquals(designSystemDto, response.getBody());
    }

    @Test
    void shouldReturnNoContentWhenIOExceptionOccurs() throws IOException {
        DesignSystemDto designSystemDto = new DesignSystemDto();
        Mockito.when(designSystemService.createDesignSystemMetricsUsage(designSystemDto)).thenThrow(IOException.class);
        ResponseEntity<DesignSystemDto> response = designSystemApi.createDesignSystemMetricsUsage(designSystemDto);
        Assertions.assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }
}