package com.pichincha.repositorylog.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.DesignSystemRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.service.models.DesignSystemComponentDto;
import com.pichincha.repositorylog.service.models.DesignSystemDto;
import com.pichincha.repositorylog.service.models.DesignSystemDto.TypeEnum;

@ExtendWith(MockitoExtension.class)
class DesignSystemServiceImplTest {

    @Mock
    private DesignSystemRepository designSystemRepository;

    @Mock
    private MetricUsageRepository metricUsageRepository;

    @InjectMocks
    private DesignSystemServiceImpl designSystemService;
    
    @Test
    void shouldThrowNoResultsExceptionGivenNoRepositoriesFound() {
        // Arrange
        DesignSystemDto designSystemDto = new DesignSystemDto();
        designSystemDto.setIdRepository("testId");
        designSystemDto.setBranch("testBranch");

        when(metricUsageRepository.getRepositoriesByCodeAndBranch(anyString(), anyString())).thenReturn(Collections.emptyList());

        // Act & Assert
        assertThrows(NoResultsException.class, () -> designSystemService.createDesignSystemMetricsUsage(designSystemDto));
    }
    
    @Test
    void shouldCreateDesignSystemMetricsUsageGivenRepositoriesFound() {
        // Arrange
        DesignSystemDto designSystemDto = new DesignSystemDto();
        designSystemDto.setIdRepository("testId");
        designSystemDto.setBranch("testBranch");
        designSystemDto.setComponents(List.of(new DesignSystemComponentDto().component("x").count(1)));
        designSystemDto.setType(TypeEnum.NEW);

        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setIdRepository(1L);

        when(metricUsageRepository.getRepositoriesByCodeAndBranch(anyString(), anyString())).thenReturn(Arrays.asList(repositoryGit));

        // Act
        DesignSystemDto result = designSystemService.createDesignSystemMetricsUsage(designSystemDto);

        // Assert
        assertEquals(designSystemDto, result);
    }
}