package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.StandardValidationRepository;
import com.pichincha.repositorylog.service.models.MetricDto;


import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class StandardValidationServiceTest {

    @InjectMocks
    private StandardValidationServiceImpl standardValidationService;

    @Mock
    private StandardValidationRepository standardValidationRepository;

    @Mock
    private MetricUsageRepository metricUsageRepository;

    @Mock
    private GovernmentMetricRepository governmentMetricRepository;




    @Test
    public void shouldBeCreateStandardValidation(){
        MetricDto metricDtoStandardValidation=new MetricDto();
        metricDtoStandardValidation.setType(MetricDto.TypeEnum.NONE);
        metricDtoStandardValidation.setContentFile("rtywerrtyy");
        metricDtoStandardValidation.setBranch("feature/validation");
        metricDtoStandardValidation.setRepositoryUri("https://repo1");
        metricDtoStandardValidation.setRepositoryName("stf-msa-microvalidation");
        metricDtoStandardValidation.setFileName("build.gradle");
        RepositoryGit repositoryGitLoad=new RepositoryGit();
        List<RepositoryGit> list=new ArrayList<>();
        list.add(repositoryGitLoad);
        GovernmentMetric governmentMetric = new GovernmentMetric();

        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(Mockito.any(),Mockito.any())).thenReturn(list);
        Mockito.when(standardValidationRepository.getStandardValidationByRepository(Mockito.any())).thenReturn(null);
        Mockito.when(governmentMetricRepository.getGovernmentMetricByRepositoryLogId(Mockito.any())).thenReturn(governmentMetric);
        standardValidationService.createStandardValidation(metricDtoStandardValidation);


    }
}
