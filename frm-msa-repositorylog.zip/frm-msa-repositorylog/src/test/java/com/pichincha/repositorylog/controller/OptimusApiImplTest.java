package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.service.OptimusService;
import com.pichincha.repositorylog.service.models.PostOptimusRegisterRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest
public class OptimusApiImplTest {

    @Mock
    private OptimusService optimusService;

    @InjectMocks
    OptimusApiImpl optimusApi;

    @Test
    void shouldRegister() {
        Mockito.doNothing().when(optimusService).postOptimusRegister(ArgumentMatchers.any());
        ResponseEntity<Void> response = optimusApi.postOptimusRegister(new PostOptimusRegisterRequest());
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }
}
