package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.LibraryValidation;
import com.pichincha.repositorylog.domain.LibraryValidationDetail;
import com.pichincha.repositorylog.domain.ProjectType;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.LibraryValidationDetailRepository;

import java.util.*;

import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.ProjectTypeRepository;
import com.pichincha.repositorylog.service.models.MetricDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.*;

@SpringBootTest
public class MetricsServiceImplTest {
    @Mock
    private MetricUsageRepository metricUsageRepository;

    @InjectMocks
    private MetricsServiceImpl metricsService;

    @Mock
    private GovernmentMetricRepository governmentMetricRepository;

    @Mock
    private ProjectTypeRepository projectTypeRepository;

    @Test
    public void testCreateMetricUsage() {
        MetricDto metricDto=new MetricDto();
        metricDto.setRepositoryName("frm-msa-test");
        metricDto.setIdRepository("48857885");
        metricDto.setIdProject("45885885");
        metricDto.setBranch("feature/develop");
        metricDto.setContentFile("eyAgInR5cGUiOiJNSE0iLCAgIm9wdGltdXNWZXJzaW9uIjoiMS4wLjEiLCAgImRhdGVPcHRpbXVzVmVyc2lvbiI6IjIwMjMtMDUtMjQiLCAgImNyZWF0ZWRCeUVtYWlsIjoic3JvYmxlc2RAcGljaGluY2hhLmNvbSIsICAidHJpYmUiOiJBUlFVSVRFQ1RVUkEgREUgREVTQVJST0xMTyIsICAiY2VsdWxhIjoiU1FVQUQgREUgQVJRVUlURUNUVVJBIiwgICJjcmVhdGVEYXRlIjoiMjAyMy0wNy0xMCJ9");
        metricDto.setRepositoryUri("http://duuufuuf/repo");
        metricDto.setType(MetricDto.TypeEnum.BACK);
        metricsService.createMetricUsage(metricDto);
        Mockito.verify(governmentMetricRepository, Mockito.times(1)).save(Mockito.any());

    }

    @Test
    public void shouldCreateMetricUsageAndUpdateMetricsWhenExist(){
        MetricDto metricDto=new MetricDto();
        metricDto.setRepositoryName("frm-msa-test1");
        metricDto.setIdRepository("488578851");
        metricDto.setIdProject("458858851");
        metricDto.setBranch("feature/develop1");
        metricDto.setContentFile("eyAgInR5cGUiOiJNSE0iLCAgIm9wdGltdXNWZXJzaW9uIjoiMS4wLjEiLCAgImRhdGVPcHRpbXVzVmVyc2lvbiI6IjIwMjMtMDUtMjQiLCAgImNyZWF0ZWRCeUVtYWlsIjoic3JvYmxlc2RAcGljaGluY2hhLmNvbSIsICAidHJpYmUiOiJBUlFVSVRFQ1RVUkEgREUgREVTQVJST0xMTyIsICAiY2VsdWxhIjoiU1FVQUQgREUgQVJRVUlURUNUVVJBIiwgICJjcmVhdGVEYXRlIjoiMjAyMy0wNy0xMCJ9");
        metricDto.setRepositoryUri("http://duuufuuf/repo1");
        metricDto.setType(MetricDto.TypeEnum.BACK);
        List<RepositoryGit> result=new ArrayList<>();
        result.add(new RepositoryGit());

        Mockito.when(metricUsageRepository.getRepositoriesByCodeAndBranch(Mockito.any(),Mockito.any())).thenReturn(result);
        metricsService.createMetricUsage(metricDto);
        Mockito.verify(governmentMetricRepository, Mockito.times(1)).save(Mockito.any());

    }


}
