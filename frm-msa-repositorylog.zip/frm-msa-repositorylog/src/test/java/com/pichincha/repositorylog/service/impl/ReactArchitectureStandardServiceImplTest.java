package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.LibraryValidation;
import com.pichincha.repositorylog.domain.LibraryValidationDetail;
import com.pichincha.repositorylog.domain.ProjectType;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.LibraryValidationDetailRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.*;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;


@SpringBootTest
class ReactArchitectureStandardServiceImplTest {

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;
    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;
    @Mock
    private WebClient.Builder webClientBuilderMock;
    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private WebClient webClientMockTest;

    @Test
    void shouldPostScan() {
        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setRepositoryCode("r1234");
        repositoryGit.setProjectCode("p1234");
        repositoryGit.setBranch("feature/hu");
        when(webClientBuilderMock.build()).thenReturn(webClientMockTest);
        when(webClientMockTest.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodySpec);
        when(requestBodySpec.header(any(), any())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("hello-world"));

        ReactArchitectureStandardServiceImpl reactArchitectureStandardService = new ReactArchitectureStandardServiceImpl(webClientBuilderMock);
        reactArchitectureStandardService.setReactArchitectureStandardUrl("url");
        Assertions.assertEquals(reactArchitectureStandardService.postScann("", repositoryGit),"hello-world");



    }

}