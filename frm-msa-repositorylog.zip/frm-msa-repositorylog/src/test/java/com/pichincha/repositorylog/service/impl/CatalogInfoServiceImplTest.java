package com.pichincha.repositorylog.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.pichincha.repositorylog.domain.CatalogInfoMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.CatalogInfoRepository;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.service.models.CatalogDto;

class CatalogInfoServiceImplTest {

    @Mock
    private CatalogInfoRepository catalogInfoRepository;

    @Mock
    private MetricUsageRepository metricUsageRepository;

    @Mock
    private GovernmentMetricRepository governmentMetricRepository;

    @InjectMocks
    private CatalogInfoServiceImpl catalogInfoService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void shouldCreateCatalogInfoMetricsUsageWhenRepositoryExists() {
        // Given
        CatalogDto catalogDto = new CatalogDto();
        catalogDto.setIdRepository("testId");
        catalogDto.setBranch("testBranch");
        RepositoryGit repositoryGit = new RepositoryGit();
        repositoryGit.setIdRepository(1L);
        List<RepositoryGit> repositoryGitList = Collections.singletonList(repositoryGit);
        when(metricUsageRepository.getRepositoriesByCodeAndBranch(catalogDto.getIdRepository(), catalogDto.getBranch())).thenReturn(repositoryGitList);

        // When
        CatalogDto result = catalogInfoService.createCatalogInfoMetricsUsage(catalogDto);

        // Then
        assertEquals(catalogDto, result);
        verify(catalogInfoRepository, times(1)).save(any(CatalogInfoMetric.class));
    }

    @Test
    void shouldThrowNoResultsExceptionWhenRepositoryDoesNotExist() {
        // Given
        CatalogDto catalogDto = new CatalogDto();
        catalogDto.setIdRepository("testId");
        catalogDto.setBranch("testBranch");
        when(metricUsageRepository.getRepositoriesByCodeAndBranch(catalogDto.getIdRepository(), catalogDto.getBranch())).thenReturn(Collections.emptyList());

        // When & Then
        assertThrows(NoResultsException.class, () -> catalogInfoService.createCatalogInfoMetricsUsage(catalogDto));
    }
}