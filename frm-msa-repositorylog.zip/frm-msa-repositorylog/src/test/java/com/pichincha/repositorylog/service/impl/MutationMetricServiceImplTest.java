package com.pichincha.repositorylog.service.impl;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.pichincha.repositorylog.service.models.MutationMetricDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.ConfigDataApplicationContextInitializer;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.pichincha.repositorylog.domain.MutationMetricEntity;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.MutationMetricRepository;
import com.pichincha.repositorylog.service.MutationMetricService;
import com.pichincha.repositorylog.service.mapper.MutationMetricMapper;

@ExtendWith({MockitoExtension.class, SpringExtension.class})
@ContextConfiguration(initializers = ConfigDataApplicationContextInitializer.class)
class MutationMetricServiceImplTest {

	private MetricUsageRepository metricUsageRepository = mock(MetricUsageRepository.class);

	private MutationMetricRepository mutationMetricRepository = mock(MutationMetricRepository.class);
	
	private MutationMetricMapper mutationMetricMapper = Mappers.getMapper(MutationMetricMapper.class);

	private MutationMetricService mutationMetricService = new MutationMetricServiceImpl(metricUsageRepository, mutationMetricRepository, mutationMetricMapper);
	
	private MutationMetricDto mutationMetricDto;
	
	private RepositoryGit repositoryGit;
	
	private List<RepositoryGit> repositoryGitList;
	
	private MutationMetricEntity mutationMetricEntity;
	
	private Optional<MutationMetricEntity> optional;
	
	@BeforeEach
	void before() {
		LocalDateTime now = LocalDateTime.of(2024, 1, 1, 0, 0);
		
		mutationMetricDto = new MutationMetricDto()
				.branch("header/master")
				.idRepository(UUID.randomUUID().toString())
				.mutationRate(BigDecimal.valueOf(60.0))
				.coverageRate(BigDecimal.valueOf(75.0));

		repositoryGit = RepositoryGit.builder()
				.idRepository(1L)
				.build();

		repositoryGitList = List.of(repositoryGit);

		mutationMetricEntity = MutationMetricEntity.builder()
				.id(1L)
				.repositoryLog(RepositoryGit.builder().build())
				.modificationDate(now)
				.creationDate(now)
				.build();

		optional = Optional.of(mutationMetricEntity);		
	}

	@Test
	void shouldSaveMetricWhenRepositoryGitExist() {
		mutationMetricEntity.setModificationDate(LocalDateTime.now());
		
		when(metricUsageRepository.getRepositoriesByCodeAndBranch(mutationMetricDto.getIdRepository(), mutationMetricDto.getBranch())).thenReturn(repositoryGitList);
		when(mutationMetricRepository.findByRepositoryLogId(repositoryGit.getIdRepository())).thenReturn(optional);
		when(mutationMetricRepository.save(any())).thenReturn(mutationMetricEntity);
		
		MutationMetricDto response = mutationMetricService.save(mutationMetricDto);
		assertNotNull(response);
		assertTrue(response.getUpdated());
	}
	
	@Test
	void shouldSaveMetricWhenRepositoryGitNotExist() {
		when(metricUsageRepository.getRepositoriesByCodeAndBranch(mutationMetricDto.getIdRepository(), mutationMetricDto.getBranch())).thenReturn(repositoryGitList);
		when(mutationMetricRepository.findByRepositoryLogId(repositoryGit.getIdRepository())).thenReturn(Optional.empty());
		when(mutationMetricRepository.save(any())).thenReturn(mutationMetricEntity);
		
		MutationMetricDto response = mutationMetricService.save(mutationMetricDto);
		assertNotNull(response);
		assertFalse(response.getUpdated());
	}

	@Test
	void shouldThrowNoResultException() {
		when(metricUsageRepository.getRepositoriesByCodeAndBranch(mutationMetricDto.getIdRepository(), mutationMetricDto.getBranch())).thenReturn(new ArrayList<>());
		assertThrows(NoResultsException.class, () -> mutationMetricService.save(mutationMetricDto));
	}
}