package com.pichincha.repositorylog.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.pichincha.repositorylog.service.MetricsService;
import com.pichincha.repositorylog.service.models.MetricDto;

@SpringBootTest
class MetricsApiImplOtherTest {

    @Mock
    private MetricsService metricsService;

    @InjectMocks
    private MetricsApiImpl metricsApi;

    @Test
    void shouldCreateMetricsUsage() throws IOException {
        MetricDto metricDto = new MetricDto();
        Mockito.when(metricsService.createMetricUsage(metricDto)).thenReturn(metricDto);
        ResponseEntity<MetricDto> response = metricsApi.createMetricsUsage(metricDto);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
        Assertions.assertEquals(metricDto, response.getBody());
    }

    @Test
    void shouldReturnNoContentWhenCreateMetricsUsageFails() throws IOException {
        MetricDto metricDto = new MetricDto();
        Mockito.when(metricsService.createMetricUsage(metricDto)).thenThrow(IOException.class);
        ResponseEntity<MetricDto> response = metricsApi.createMetricsUsage(metricDto);
        Assertions.assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Test
    void shouldGetAllMetrics() {
        List<MetricDto> metricDtoList = Collections.singletonList(new MetricDto());
        Mockito.when(metricsService.getAllMetricsUsage()).thenReturn(metricDtoList);
        ResponseEntity<List<MetricDto>> response = metricsApi.getAllMetrics();
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals(metricDtoList, response.getBody());
    }

    @Test
    void shouldReturnEmptyListWhenNoMetrics() {
        Mockito.when(metricsService.getAllMetricsUsage()).thenReturn(Collections.emptyList());
        ResponseEntity<List<MetricDto>> response = metricsApi.getAllMetrics();
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertTrue(response.getBody().isEmpty());
    }
}

