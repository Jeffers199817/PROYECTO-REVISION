package com.pichincha.repositorylog.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.pichincha.repositorylog.service.StandardValidationService;
import com.pichincha.repositorylog.service.models.MetricDto;

@SpringBootTest
class StandarsApiImplTest {

    @Mock
    private StandardValidationService standardValidationService;

    @InjectMocks
    private StandarsApiImpl standarsApi;

    @Test
    void shouldCreateValidationStandard() {
        MetricDto metricDto = new MetricDto();
        Mockito.doNothing().when(standardValidationService).createStandardValidation(metricDto);
        ResponseEntity<Void> response = standarsApi.createValidationStandard(metricDto);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    void shouldThrowExceptionWhenCreateValidationStandardFails() {
        MetricDto metricDto = new MetricDto();
        Mockito.doThrow(RuntimeException.class).when(standardValidationService).createStandardValidation(metricDto);
        Assertions.assertThrows(RuntimeException.class, () -> standarsApi.createValidationStandard(metricDto));
    }
}