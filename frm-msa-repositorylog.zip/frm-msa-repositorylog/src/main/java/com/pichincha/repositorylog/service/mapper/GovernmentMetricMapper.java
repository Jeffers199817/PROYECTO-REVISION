package com.pichincha.repositorylog.service.mapper;

import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.service.models.PostOptimusRegisterRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.Instant;
import java.util.Date;

@Mapper
public interface GovernmentMetricMapper {

    @Mapping(source = "repository", target = "repositoryLog")
    @Mapping(source = "request.hasNamingRepository", target = "namingRepository")
    @Mapping(source = "request.withOptimusRepository", target = "withOptimus")
    @Mapping(source = "request.hasOpenApi", target = "hasOpenApi")
    @Mapping(source = "request.hasCatalog", target = "hasCatalog")
    @Mapping(source = "request.status", target = "recordStatus")
    @Mapping(constant = "true", target = "isOptimus")
    @Mapping(expression = "java(getCurrentDate())", target = "creationDate")
    GovernmentMetric toGovernmentMetric(PostOptimusRegisterRequest request, RepositoryGit repository);

    default Date getCurrentDate() {
        return Date.from(Instant.now());
    }
}
