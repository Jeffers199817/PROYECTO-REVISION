package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.service.ReactArchitectureStandardService;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@Slf4j
public class ReactArchitectureStandardServiceImpl implements ReactArchitectureStandardService {

    @Setter
    @Getter
    @Value("${urls.react-architecture-standard}")
    private String reactArchitectureStandardUrl;

    private final WebClient.Builder webClientBuilder;

    public ReactArchitectureStandardServiceImpl(WebClient.Builder webClientBuilder) {
        this.webClientBuilder = webClientBuilder;
    }

    @Async
    public String postScann(String authorization, RepositoryGit repositoryGit) {
        String payload = "{\"project_id\": \""+ repositoryGit.getProjectCode() + "\", \"repository_id\": \""+ repositoryGit.getRepositoryCode() + "\", \"branch\": \"" + repositoryGit.getBranch().replace("refs/heads/", "") + "\" }";
        log.info("SENDING SCAN TO SCANNER WITH PAYLOAD {}", payload);
        String resultScanner = webClientBuilder.build()
                .post()
                .uri(reactArchitectureStandardUrl)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", authorization)
                .body(BodyInserters.fromValue(payload))
                .retrieve()
                .bodyToMono(String.class)
                .block();
        log.info("SCAN WITH RESPONSE {}", resultScanner);
        return resultScanner;
    }
}
