package com.pichincha.repositorylog.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "opt_project_type")
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProjectType {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id_type")
    private Long idProjectType;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

}
