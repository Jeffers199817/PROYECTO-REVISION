package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.domain.RepositoryGit;

public interface ReactArchitectureStandardService {
     String postScann(String authorization, RepositoryGit repositoryGit);
}
