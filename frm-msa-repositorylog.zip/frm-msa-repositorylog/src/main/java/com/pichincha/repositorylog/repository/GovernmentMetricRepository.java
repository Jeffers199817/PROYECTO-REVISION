
package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface GovernmentMetricRepository extends JpaRepository<GovernmentMetric,Long> {

    @Query(value = "select s from GovernmentMetric s where s.repositoryLog.idRepository=?1 and s.recordStatus='ACTIVO'",nativeQuery = false)
    GovernmentMetric getGovernmentMetricByRepositoryLogId(Long repositoryCode);

    Optional<GovernmentMetric> findTopByRepositoryLogOrderByCreationDateDesc(RepositoryGit repositoryGit);

}