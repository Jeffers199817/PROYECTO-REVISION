package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.domain.StandardValidation;
import com.pichincha.repositorylog.domain.enums.ValidationStateEnum;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.StandardValidationRepository;
import com.pichincha.repositorylog.service.StandardValidationService;
import com.pichincha.repositorylog.service.models.MetricDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@Service
public class StandardValidationServiceImpl implements StandardValidationService {

    private StandardValidationRepository standardValidationRepository;
    private MetricUsageRepository metricUsageRepository;
    private GovernmentMetricRepository governmentMetricRepository;

    private static final String ACTIVO="ACTIVO";

    private static final String INACTIVO="INACTIVO";

    @Transactional
    @Override
    public void createStandardValidation(MetricDto metricDto) {

        List<RepositoryGit> repositoryGitList = metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch());
        if (repositoryGitList.isEmpty()) {
            throw new NoResultsException("NO SE ENCONTRÓ REPOSITORIOS CON EL CODIGO: " + metricDto.getIdRepository());
        } else {
            StandardValidation standardValidation = standardValidationRepository.getStandardValidationByRepositoryLogId(repositoryGitList.get(0).getIdRepository());
            if(standardValidation==null){
                createNewStandardValidation(metricDto, repositoryGitList);
            }else{
                String hashContentFile=metricDto.getContentFile();
                String hashContentFileSaved=standardValidation.getContractFileContent();
                if(!hashContentFile.equals(hashContentFileSaved)){
                    standardValidation.setRecordStatus(INACTIVO);
                    standardValidationRepository.save(standardValidation);
                    createNewStandardValidation(metricDto, repositoryGitList);
                }

            }
            if (!metricDto.getContentFile().isEmpty()) {
                GovernmentMetric governmentMetric = governmentMetricRepository.getGovernmentMetricByRepositoryLogId(repositoryGitList.get(0).getIdRepository());
                if (governmentMetric != null) {
                    governmentMetric.setHasOpenApi(true);
                    governmentMetricRepository.save(governmentMetric);
                }
            }


        }


    }

    private void createNewStandardValidation(MetricDto metricDto, List<RepositoryGit> repositoryGitList) {
        StandardValidation standardValidation=new StandardValidation();
        standardValidation.setValidationDate(new Date());
        standardValidation.setValidationState(ValidationStateEnum.NO_VALIDADO);
        standardValidation.setCreationDate(new Date());
        standardValidation.setMeetsNamed(false);
        standardValidation.setContractFileContent(metricDto.getContentFile());
        standardValidation.setRepositoryLog(repositoryGitList.get(0));
        standardValidation.setRecordStatus(ACTIVO);
        standardValidationRepository.save(standardValidation);
    }
}
