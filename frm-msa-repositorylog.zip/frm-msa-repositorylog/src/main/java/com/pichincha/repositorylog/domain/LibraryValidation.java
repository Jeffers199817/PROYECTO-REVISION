package com.pichincha.repositorylog.domain;

import com.pichincha.repositorylog.domain.enums.ValidationStateEnum;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "opt_library_validation")
public class LibraryValidation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_library_validation")
    private Long idLibraryValidation;

    @Column(name="state")
    @Enumerated(EnumType.STRING)
    private ValidationStateEnum validationState;

    @Column(name="validation_date")
    private Date validationDate;

    @Column(name="creation_date")
    private Date creationDate;

    @Column(name="file_name")
    private String fileName;

    @Column(name="configuration_content_file")
    private String configurationContentFile;

    @Column(name="sub_technology")
    private String subTechnology;

    @ManyToOne
    @JoinColumn(name = "id_repositorylog")
    private RepositoryGit repositoryLog;

    @Column(name="record_status")
    private String recordStatus;

    @OneToMany(mappedBy = "libraryValidation",cascade = {CascadeType.PERSIST})
    private List<LibraryValidationDetail> details;

    @Column(name="version")
    private String version;


}
