package com.pichincha.repositorylog.service.mapper;

import com.pichincha.repositorylog.domain.MutationMetricEntity;
import com.pichincha.repositorylog.service.models.MutationMetricDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface MutationMetricMapper {

	@Mapping(expression = "java(entity.getRepositoryLog().getRepositoryCode())", target = "idRepository")
	@Mapping(expression = "java(entity.getRepositoryLog().getBranch())", target = "branch")
	@Mapping(expression = "java(entity.getRepositoryLog().getRepositoryName())", target = "repositoryName")
	@Mapping(expression = "java(entity.getRepositoryLog().getProjectCode())", target = "idProject")
	@Mapping(expression = "java(entity.isUpdated())", target = "updated")
	MutationMetricDto toMutationMetricDto(MutationMetricEntity entity);

	MutationMetricEntity toMutationMetricEntity(MutationMetricDto dto);
}