package com.pichincha.repositorylog.util;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class NamingRepositoryUtil {
    private static List<String> owners = new ArrayList<>();
    private static List<String> appTypes = new ArrayList<>();
    private static List<String> dddTypes = new ArrayList<>();
    private static List<String> bianTypes = new ArrayList<>();

    private NamingRepositoryUtil() {
        throw new IllegalStateException("Utility class");
    }
    public static void start() {
        // owner - type app - nombre
        // owner - tpe app - ddd type - nombre

        // bbe-msa-ux-client-auth
        // bbe-msa-dm-pprd-client-auth
        if (bianTypes.isEmpty()) {
            log.info("Setting bianTypes");
            bianTypes.add("buld");
            bianTypes.add("eqad");
            bianTypes.add("eqmt");
            bianTypes.add("ppro");
            bianTypes.add("sadm");
            bianTypes.add("sops");
            bianTypes.add("uadm");
            bianTypes.add("buac");
            bianTypes.add("budi");
            bianTypes.add("bufo");
            bianTypes.add("bufs");
            bianTypes.add("bumg");
            bianTypes.add("ordi");
            bianTypes.add("conp");
            bianTypes.add("cpol");
            bianTypes.add("cstr");
            bianTypes.add("enar");
            bianTypes.add("prda");
            bianTypes.add("casa");
            bianTypes.add("ccom");
            bianTypes.add("crel");
            bianTypes.add("invr");
            bianTypes.add("rlab");
            bianTypes.add("arcs");
            bianTypes.add("corr");
            bianTypes.add("doli");
            bianTypes.add("dodi");
            bianTypes.add("dosv");
            bianTypes.add("etad");
            bianTypes.add("fcom");
            bianTypes.add("fctl");
            bianTypes.add("fstm");
            bianTypes.add("emac");
            bianTypes.add("ecco");
            bianTypes.add("emas");
            bianTypes.add("embe");
            bianTypes.add("emcp");
            bianTypes.add("edma");
            bianTypes.add("eeva");
            bianTypes.add("epas");
            bianTypes.add("hrdi");
            bianTypes.add("recr");
            bianTypes.add("trex");
            bianTypes.add("wotr");
            bianTypes.add("denv");
            bianTypes.add("inop");
            bianTypes.add("istg");
            bianTypes.add("itsd");
            bianTypes.add("opgw");
            bianTypes.add("plop");
            bianTypes.add("prls");
            bianTypes.add("sydp");
            bianTypes.add("sydv");
            bianTypes.add("syad");
            bianTypes.add("syas");
            bianTypes.add("syhd");
            bianTypes.add("syop");
            bianTypes.add("ippo");
            bianTypes.add("kexc");
            bianTypes.add("mama");
            bianTypes.add("asdr");
            bianTypes.add("cbap");
            bianTypes.add("farq");
            bianTypes.add("iacc");
            bianTypes.add("llco");
            bianTypes.add("proc");
            bianTypes.add("sead");
            bianTypes.add("seas");
            bianTypes.add("accr");
            bianTypes.add("asre");
            bianTypes.add("cprk");
            bianTypes.add("cpos");
            bianTypes.add("frdi");
            bianTypes.add("frev");
            bianTypes.add("posk");
            bianTypes.add("poma");
            bianTypes.add("pcom");
            bianTypes.add("rpta");
            bianTypes.add("spkt");
            bianTypes.add("teng");
            bianTypes.add("caml");
            bianTypes.add("caad");
            bianTypes.add("coll");
            bianTypes.add("ccol");
            bianTypes.add("ctsw");
            bianTypes.add("caan");
            bianTypes.add("cahi");
            bianTypes.add("cbil");
            bianTypes.add("daha");
            bianTypes.add("disb");
            bianTypes.add("ibac");
            bianTypes.add("idas");
            bianTypes.add("idtk");
            bianTypes.add("lian");
            bianTypes.add("oima");
            bianTypes.add("rpar");
            bianTypes.add("acho");
            bianTypes.add("cclr");
            bianTypes.add("cegt");
            bianTypes.add("cfsm");
            bianTypes.add("cchd");
            bianTypes.add("chpr");
            bianTypes.add("cbop");
            bianTypes.add("fgat");
            bianTypes.add("fman");
            bianTypes.add("prcm");
            bianTypes.add("pinm");
            bianTypes.add("paor");
            bianTypes.add("paio");
            bianTypes.add("caut");
            bianTypes.add("ccap");
            bianTypes.add("cnpf");
            bianTypes.add("ccrd");
            bianTypes.add("ccpk");
            bianTypes.add("maaf");
            bianTypes.add("mrel");
            bianTypes.add("bdrf");
            bianTypes.add("brpd");
            bianTypes.add("casy");
            bianTypes.add("cinv");
            bianTypes.add("ctse");
            bianTypes.add("crro");
            bianTypes.add("ctxh");
            bianTypes.add("tres");
            bianTypes.add("cfin");
            bianTypes.add("ctax");
            bianTypes.add("maad");
            bianTypes.add("prpl");
            bianTypes.add("puof");
            bianTypes.add("etrw");
            bianTypes.add("ivac");
            bianTypes.add("ipan");
            bianTypes.add("ipma");
            bianTypes.add("ippl");
            bianTypes.add("cloa");
            bianTypes.add("ccua");
            bianTypes.add("cles");
            bianTypes.add("crln");
            bianTypes.add("cura");
            bianTypes.add("fidu");
            bianTypes.add("leas");
            bianTypes.add("lean");
            bianTypes.add("mloa");
            bianTypes.add("mort");
            bianTypes.add("sava");
            bianTypes.add("stdo");
            bianTypes.add("tmde");
            bianTypes.add("vacc");
            bianTypes.add("cact");
            bianTypes.add("cust");
            bianTypes.add("fiva");
            bianTypes.add("hfad");
            bianTypes.add("mfan");
            bianTypes.add("oall");
            bianTypes.add("sfpr");
            bianTypes.add("tprr");
            bianTypes.add("tclr");
            bianTypes.add("tcfm");
            bianTypes.add("utad");
            bianTypes.add("bkgu");
            bianTypes.add("ccon");
            bianTypes.add("cmas");
            bianTypes.add("chlb");
            bianTypes.add("cpas");
            bianTypes.add("cfac");
            bianTypes.add("cred");
            bianTypes.add("ddbc");
            bianTypes.add("ddmd");
            bianTypes.add("fact");
            bianTypes.add("loct");
            bianTypes.add("leml");
            bianTypes.add("ntpg");
            bianTypes.add("prfn");
            bianTypes.add("syln");
            bianTypes.add("trbf");
            bianTypes.add("crdo");
            bianTypes.add("ddsk");
            bianTypes.add("ecmd");
            bianTypes.add("mkin");
            bianTypes.add("mkor");
            bianTypes.add("mkex");
            bianTypes.add("prtr");
            bianTypes.add("quma");
            bianTypes.add("schk");
            bianTypes.add("tpos");
            bianTypes.add("tbos");
            bianTypes.add("tmod");
            bianTypes.add("csaa");
            bianTypes.add("cbdo");
            bianTypes.add("cbrm");
            bianTypes.add("ipad");
            bianTypes.add("irm");
            bianTypes.add("pbaa");
            bianTypes.add("psag");
            bianTypes.add("scag");
            bianTypes.add("synm");
            bianTypes.add("cpad");
            bianTypes.add("fird");
            bianTypes.add("fmar");
            bianTypes.add("fmre");
            bianTypes.add("ipop");
            bianTypes.add("locm");
            bianTypes.add("mdas");
            bianTypes.add("mdos");
            bianTypes.add("mimm");
            bianTypes.add("prdm");
            bianTypes.add("qmod");
            bianTypes.add("ledy");
            bianTypes.add("prpr");
            bianTypes.add("dprc");
            bianTypes.add("pdep");
            bianTypes.add("pdes");
            bianTypes.add("pdct");
            bianTypes.add("pqas");
            bianTypes.add("ptra");
            bianTypes.add("sprc");
            bianTypes.add("alam");
            bianTypes.add("asse");
            bianTypes.add("bpoa");
            bianTypes.add("bpas");
            bianTypes.add("ctrs");
            bianTypes.add("ctra");
            bianTypes.add("slrp");
            bianTypes.add("bptf");
            bianTypes.add("cptf");
            bianTypes.add("cana");
            bianTypes.add("cnan");
            bianTypes.add("cpor");
            bianTypes.add("mark");
            bianTypes.add("mkre");
            bianTypes.add("ppor");
            bianTypes.add("sgmt");
            bianTypes.add("brmd");
            bianTypes.add("cnmd");
            bianTypes.add("cmam");
            bianTypes.add("crmd");
            bianTypes.add("cbmd");
            bianTypes.add("ecap");
            bianTypes.add("fivm");
            bianTypes.add("frmd");
            bianTypes.add("gapa");
            bianTypes.add("lrms");
            bianTypes.add("mris");
            bianTypes.add("ormo");
            bianTypes.add("prrm");
            bianTypes.add("cprp");
            bianTypes.add("fiac");
            bianTypes.add("fsta");
            bianTypes.add("fres");
            bianTypes.add("glcp");
            bianTypes.add("rcom");
            bianTypes.add("rpre");
            bianTypes.add("avsm");
            bianTypes.add("avso");
            bianTypes.add("atnm");
            bianTypes.add("atno");
            bianTypes.add("bcdi");
            bianTypes.add("bcmg");
            bianTypes.add("blmg");
            bianTypes.add("blop");
            bianTypes.add("bnmg");
            bianTypes.add("ctad");
            bianTypes.add("ctop");
            bianTypes.add("ccen");
            bianTypes.add("ccop");
            bianTypes.add("ebrm");
            bianTypes.add("ebro");
            bianTypes.add("pidi");
            bianTypes.add("piim");
            bianTypes.add("chdl");
            bianTypes.add("crte");
            bianTypes.add("cwbh");
            bianTypes.add("ihel");
            bianTypes.add("paut");
            bianTypes.add("poss");
            bianTypes.add("sdir");
            bianTypes.add("sana");
            bianTypes.add("sehi");
            bianTypes.add("sdia");
            bianTypes.add("taut");
            bianTypes.add("acrv");
            bianTypes.add("caen");
            bianTypes.add("cagr");
            bianTypes.add("cbin");
            bianTypes.add("ccra");
            bianTypes.add("ceve");
            bianTypes.add("cprc");
            bianTypes.add("cpse");
            bianTypes.add("cpro");
            bianTypes.add("cppn");
            bianTypes.add("crms");
            bianTypes.add("prdd");
            bianTypes.add("spat");
            bianTypes.add("advt");
            bianTypes.add("bman");
            bianTypes.add("bdev");
            bianTypes.add("ccdm");
            bianTypes.add("ccmg");
            bianTypes.add("csur");
            bianTypes.add("peve");
            bianTypes.add("pcdm");
            bianTypes.add("cmag");
            bianTypes.add("cmss");
            bianTypes.add("ccex");
            bianTypes.add("coff");
            bianTypes.add("loam");
            bianTypes.add("plma");
            bianTypes.add("psas");
            bianTypes.add("pmat");
            bianTypes.add("pssa");
            bianTypes.add("pcex");
            bianTypes.add("spla");
            bianTypes.add("sprd");
            bianTypes.add("unde");
            bianTypes.add("ccse");
            bianTypes.add("crca");
            bianTypes.add("ccas");
            bianTypes.add("ccsm");
            bianTypes.add("pain");
            bianTypes.add("sisr");
            bianTypes.add("sman");
            bianTypes.add("sord");
            bianTypes.add("pcmg");
            bianTypes.add("tset");
        }
        if (dddTypes.isEmpty()) {
            log.info("Setting dddTypes");
            dddTypes.add("ux");
            dddTypes.add("bs");
            dddTypes.add("sp");
            dddTypes.add("dm");
            dddTypes.add("ob");
            dddTypes.add("pt");
        }
        if (appTypes.isEmpty()) {
            log.info("Setting appTypes");
            appTypes.add("spa");
            appTypes.add("msa");
            appTypes.add("aut");
            appTypes.add("app");
            appTypes.add("lib");
            appTypes.add("iac");
            appTypes.add("mfa");
            appTypes.add("cfg");
            appTypes.add("tpl");
            appTypes.add("doc");
            appTypes.add("dba");
            appTypes.add("bzg");
            appTypes.add("rpa");
            appTypes.add("shl");
            appTypes.add("gtw");
            appTypes.add("mna");
            appTypes.add("xen");
            appTypes.add("frs");
            appTypes.add("shb");
            appTypes.add("api");
        }
        if (owners.isEmpty()) {
            log.info("Setting owners");
            owners.add("ach");
            owners.add("onb");
            owners.add("aho");
            owners.add("cta");
            owners.add("inv");
            owners.add("sge");
            owners.add("lnk");
            owners.add("bde");
            owners.add("bbe");
            owners.add("cidn");
            owners.add("fal");
            owners.add("ppu");
            owners.add("dab");
            owners.add("sda");
            owners.add("bmo");
            owners.add("pcd");
            owners.add("omn");
            owners.add("cce");
            owners.add("hrm");
            owners.add("bdp");
            owners.add("cds");
            owners.add("chf");
            owners.add("frm");
            owners.add("mam");
            owners.add("mdo");
            owners.add("ntf");
            owners.add("cpp");
            owners.add("stf");
            owners.add("cbf");
            owners.add("cid");
            owners.add("cia");
            owners.add("sqb");
            owners.add("gba");
            owners.add("tna");
            owners.add("tin");
            owners.add("ays");
            owners.add("via");
            owners.add("aas");
            owners.add("inc");
            owners.add("bzp");
            owners.add("chw");
            owners.add("ryr");
            owners.add("orj");
            owners.add("tjd");
            owners.add("bmn");
            owners.add("roe");
            owners.add("cmr");
            owners.add("cau");
            owners.add("smt");
            owners.add("rte");
            owners.add("tcp");
            owners.add("tkn");
            owners.add("tdd");
            owners.add("tra");
            owners.add("rms");
            owners.add("ptd");
            owners.add("cim");
            owners.add("fda");
            owners.add("cyf");
            owners.add("wac");
            owners.add("tes");
            owners.add("sad");
            owners.add("apr");
            owners.add("una");
            owners.add("idt");
            owners.add("mfi");
            owners.add("mfg");
            owners.add("mht");
            owners.add("mkc");
            owners.add("spl");
            owners.add("mtd");
            owners.add("mdm");
            owners.add("crm");
            owners.add("sec");
            owners.add("dvs");
            owners.add("liq");
            owners.add("cdv");
            owners.add("cso");
            owners.add("rem");
            owners.add("csm");
            owners.add("css");
            owners.add("cnb");
            owners.add("cyc");
            owners.add("one");
            owners.add("ase");
            owners.add("sto");
            owners.add("sqm");
            owners.add("mdw");
            owners.add("rel");

        }
    }
    public static Boolean checkCompliance(String repositoryName)  {
        Boolean isOwnerCorrect;
        Boolean isAppTypeCorrect;
        Boolean isDDDTypeCorrect = true;
        Boolean isBIANCorrect = true;

        start();
        String[] namingPieces = repositoryName.split("-");
        if (namingPieces.length <= 2) {
            return false;
        } else {
            isOwnerCorrect = checkOwner(namingPieces[0]);
            isAppTypeCorrect = checkAppType(namingPieces[1]);
            if (namingPieces[1].equals("msa")) {
                isDDDTypeCorrect = checkDDDType(namingPieces[2]);
                if (namingPieces[2].equals("dm")) {
                    if (namingPieces.length <= 4) {
                        return false;
                    } else {
                        isBIANCorrect = checkBIANType(namingPieces[3]);
                    }
                }
            }

        }
        return (isOwnerCorrect && isAppTypeCorrect && isDDDTypeCorrect && isBIANCorrect);
    }
    public static Boolean checkOwner(String ownerPiece)  {
        for (String owner : owners) {
            if (owner.equals(ownerPiece)) {
                return true;
            }
        }
        return false;
    }
    public static Boolean checkAppType(String appTypePiece)  {
        for (String appType : appTypes) {
            if (appType.equals(appTypePiece)) {
                return true;
            }
        }
        return false;
    }
    public static Boolean checkDDDType(String dddTypePiece)  {
        for (String dddType : dddTypes) {
            if (dddType.equals(dddTypePiece)) {
                return true;
            }
        }
        return false;
    }
    public static Boolean checkBIANType(String bianTypePiece)  {
        for (String BIANType : bianTypes) {
            if (BIANType.equals(bianTypePiece)) {
                return true;
            }
        }
        return false;
    }
}
