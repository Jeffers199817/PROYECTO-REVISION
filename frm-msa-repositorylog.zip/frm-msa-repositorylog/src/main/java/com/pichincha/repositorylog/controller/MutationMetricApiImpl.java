package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.service.MutationMetricService;
import com.pichincha.repositorylog.service.models.MutationMetricDto;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@AllArgsConstructor
@RestController
public class MutationMetricApiImpl implements MutationMetricsApi {

	private final MutationMetricService mutationMetricService;

	@Override
	public ResponseEntity<MutationMetricDto> saveMutationMetric(MutationMetricDto mutationMetricDto) {

		MutationMetricDto response = mutationMetricService.save(mutationMetricDto);

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}
}