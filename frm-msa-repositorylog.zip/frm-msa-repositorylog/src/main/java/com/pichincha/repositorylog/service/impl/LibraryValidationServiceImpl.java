package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.LibraryValidation;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.domain.enums.ValidationStateEnum;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.LibraryValidationRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.service.DetailLibraryValidationService;
import com.pichincha.repositorylog.service.LibraryValidationService;
import com.pichincha.repositorylog.service.models.LibraryDetailDTO;
import com.pichincha.repositorylog.service.models.MetricDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Base64;
import java.util.Date;
import java.util.List;

//@AllArgsConstructor
@Service
@Slf4j
public class LibraryValidationServiceImpl implements LibraryValidationService {


    @Autowired
    private DetailLibraryValidationService detailLibraryValidationService;
    @Autowired
    private LibraryValidationRepository libraryValidationRepository;
    @Autowired
    private MetricUsageRepository metricUsageRepository;


    private static final String ACTIVO = "ACTIVO";

    private static final String INACTIVO = "INACTIVO";

    private static final String REACT_LIB = "react\"";
    private static final String ANGULAR_LIB = "@angular/core";

    private static final String REACT = "react";
    private static final String ANGULAR = "angular";

    private static final String POM = "pom-xml";

    private static final String BUILD_GRADLE = "build-gradle";

    private static final String CSPROJECT = "csproj";

    private static final String JAVA = "java";

    private static final String NET = "net";

    private static final String UNDEFINED="undefined";


    @Transactional
    @Override
    public void createLibraryValidation(MetricDto metricDto, String authorization) {


        List<RepositoryGit> repositoryGitList = metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch());
        if (repositoryGitList.isEmpty()) {
            throw new NoResultsException("NO SE ENCONTRÓ REPOSITORIOS CON EL CODIGO: " + metricDto.getIdRepository());
        } else {
            LibraryValidation libraryValidation = libraryValidationRepository.getLibraryValidationByRepositoryLogId(repositoryGitList.get(0).getIdRepository());

            if (libraryValidation == null) {
                libraryValidation = this.getInstanceLibraryValidation(metricDto, repositoryGitList.get(0));
                libraryValidation.setRecordStatus(ACTIVO);

                detailLibraryValidationService.validation(libraryValidationRepository.save(libraryValidation), repositoryGitList.get(0), authorization);
            } else {

                detailLibraryValidationService.validation(createHistoryLibraryValidation(metricDto, repositoryGitList.get(0), libraryValidation), repositoryGitList.get(0), authorization);

            }

        }


    }


    private LibraryValidation createHistoryLibraryValidation(MetricDto metricDto, RepositoryGit repositoryGit, LibraryValidation libraryValidation) {

        libraryValidation.setRecordStatus(INACTIVO);
        libraryValidationRepository.save(libraryValidation);
        detailLibraryValidationService.inactivateLibraryDetails(libraryValidation);

        libraryValidation = this.getInstanceLibraryValidation(metricDto, repositoryGit);
        libraryValidation.setRecordStatus(ACTIVO);

        return libraryValidationRepository.save(libraryValidation);
    }

    private LibraryValidation getInstanceLibraryValidation(MetricDto metricDto, RepositoryGit repositoryGit) {
        LibraryValidation libraryValidation = new LibraryValidation();
        setVariablesLibrary(metricDto, repositoryGit, libraryValidation);


        return libraryValidation;
    }

    private void setVariablesLibrary(MetricDto metricDto, RepositoryGit repositoryGit, LibraryValidation libraryValidation) {
        libraryValidation.setValidationDate(new Date());
        libraryValidation.setValidationState(ValidationStateEnum.NO_VALIDADO);
        libraryValidation.setCreationDate(new Date());
        libraryValidation.setFileName(metricDto.getFileName());
        libraryValidation.setRepositoryLog(repositoryGit);
        libraryValidation.setConfigurationContentFile(metricDto.getContentFile());

        byte[] decodedBytes = Base64.getDecoder().decode(metricDto.getContentFile());
        String content = new String(decodedBytes);
        if (content.contains(REACT_LIB)) {
            libraryValidation.setSubTechnology(REACT);

        }
        if (content.contains(ANGULAR_LIB)) {
            libraryValidation.setSubTechnology(ANGULAR);
        }
        if (libraryValidation.getFileName().equals(POM) || libraryValidation.getFileName().equals(BUILD_GRADLE)) {
            libraryValidation.setSubTechnology(JAVA);
        }
        if (libraryValidation.getFileName().equals(CSPROJECT)) {
            libraryValidation.setSubTechnology(NET);
        }
        libraryValidation.setVersion(this.getVersion(content, libraryValidation));
    }

    public List<LibraryDetailDTO> getAllLibraries(Integer page) {
        return detailLibraryValidationService.getAllLibraries(page);
    }

    private String getVersion(String content, LibraryValidation libraryValidation) {
        String version = UNDEFINED;
        try{
            if (libraryValidation.getSubTechnology() != null && libraryValidation.getSubTechnology().equals(REACT) && content.contains(REACT_LIB)) {
                version = content.
                        split(REACT_LIB)[1].
                        split(",")[0].
                        replace(":", "").
                        replace("\"", "").trim();

            }
            if (libraryValidation.getSubTechnology() != null && libraryValidation.getSubTechnology().equals(ANGULAR)) {
                version = content.split(ANGULAR_LIB)[1].
                        split(",")[0].
                        replace(":", "").
                        replace("\"", "");
            }

            if (libraryValidation.getSubTechnology() != null && libraryValidation.getSubTechnology().equals(JAVA) && libraryValidation.getFileName().equals(POM) && content.contains("<java.version>")) {
                version = content.split("<java.version>")[1].split("</")[0];
            }
            if (libraryValidation.getSubTechnology() != null && libraryValidation.getSubTechnology().equals(JAVA) && libraryValidation.getFileName().equals(BUILD_GRADLE) && content.contains("sourceCompatibility")) {
                String source = content.split("sourceCompatibility")[1].split("=")[1];
                if(source.trim().charAt(0)=='\''){
                    version = source.split("'")[1].split("'")[0];
                }else{
                    version = source.split("\"")[1].split("\"")[0];
                }



            }
            if (libraryValidation.getSubTechnology() != null && libraryValidation.getSubTechnology().equals(NET)) {

                if(content.contains("<TargetFrameworkVersion>")){
                    version = content.split("<TargetFrameworkVersion>")[1].split("</")[0];
                } else if (content.contains("<TargetFramework>")) {
                    version = content.split("<TargetFramework>")[1].split("</")[0];
                }else{
                    version=UNDEFINED;
                }
            }
        }catch (ArrayIndexOutOfBoundsException e){
            log.error(e.toString());
            version="ERROR IN CONTENT FILE";
        }

        return version;
    }


    @Async
    public void updateAllLibraries(Integer initValidation,Integer endValidation) {
        List<LibraryValidation> libraries = libraryValidationRepository.getListLibrariesValidationActive(Long.valueOf(initValidation),Long.valueOf(endValidation));
        log.info("number libraries for process: {}",libraries.size());
        libraries.forEach(library -> {
            saveLibrary(library);
        });
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    private void saveLibrary(LibraryValidation library) {
        log.info("id library process: {}", library.getIdLibraryValidation());
        MetricDto metricDto = new MetricDto();
        metricDto.setFileName(library.getFileName());
        metricDto.setContentFile(library.getConfigurationContentFile());
        setVariablesLibrary(metricDto, library.getRepositoryLog(), library);

        libraryValidationRepository.save(library);
    }


}
