package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.RepositoryGit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface RepositoryGitRepository extends JpaRepository<RepositoryGit,Long> {
    @Query(value = "select r from RepositoryGit r where r.repositoryName=?1",nativeQuery = false)
    List<RepositoryGit> getRepositoryByName(String name);

    Optional<RepositoryGit> findByRepositoryCodeAndRepositoryNameAndBranchIsNull(String repositoryCode, String repositoryName);
}
