package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.CatalogInfoMetric;
import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.CatalogInfoRepository;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.service.CatalogInfoService;
import com.pichincha.repositorylog.service.models.CatalogDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@Service
public class CatalogInfoServiceImpl implements CatalogInfoService {

	private CatalogInfoRepository catalogInfoRepository;
	private MetricUsageRepository metricUsageRepository;

	private GovernmentMetricRepository governmentMetricRepository;

	@Override
	public CatalogDto createCatalogInfoMetricsUsage(CatalogDto catalogDto) {
		List<RepositoryGit> repositoryGitList = metricUsageRepository.getRepositoriesByCodeAndBranch(catalogDto.getIdRepository(), catalogDto.getBranch());
		if (repositoryGitList.isEmpty()) {
			throw new NoResultsException("NO SE ENCONTRÓ REPOSITORIOS CON EL CODIGO: " + catalogDto.getIdRepository());
		} else {

			CatalogInfoMetric catalogInfoMetric = catalogInfoRepository.getCatalogInfoMetricByRepositoryLogId(repositoryGitList.get(0).getIdRepository());

			if (catalogInfoMetric != null) {
				catalogInfoMetric = catalogInfoMetric.toBuilder()
						.recordStatus("INACTIVO")
						.build();
				
				catalogInfoRepository.save(catalogInfoMetric);
			}

			CatalogInfoMetric newCatalogInfoMetric = CatalogInfoMetric.builder()
					.repositoryLog(repositoryGitList.get(0))
					.fileContent(catalogDto.getContentFile())
					.recordStatus("ACTIVO")
					.creationDate(new Date())
					.build();
			
			catalogInfoRepository.save(newCatalogInfoMetric);

			GovernmentMetric governmentMetric = governmentMetricRepository.getGovernmentMetricByRepositoryLogId(newCatalogInfoMetric.getRepositoryLog().getIdRepository());

			if (governmentMetric != null) {
				governmentMetric = governmentMetric.toBuilder()
						.hasCatalog(true)
						.build();
				governmentMetricRepository.save(governmentMetric);
			}
		}
		
		return catalogDto;
	}
}