package com.pichincha.repositorylog.domain;

import com.pichincha.repositorylog.domain.enums.ValidationStateEnum;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;


@Entity
@Table(name="opt_standard_validation")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StandardValidation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_standard_validation")
    private Long idStandardValidation;

    @Column(name="meets_named")
    private boolean meetsNamed;

    @Column(name = "contract_file_content")
    private String contractFileContent;

    @Column(name="state")
    @Enumerated(EnumType.STRING)
    private ValidationStateEnum validationState;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="validation_date")
    private Date validationDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "creation_date")
    private Date creationDate;

    @ManyToOne
    @JoinColumn(name = "id_repositorylog")
    private RepositoryGit repositoryLog;

    @Column(name="record_status")
    private String recordStatus;
}
