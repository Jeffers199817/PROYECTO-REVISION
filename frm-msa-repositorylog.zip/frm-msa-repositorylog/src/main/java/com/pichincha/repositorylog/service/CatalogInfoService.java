package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.service.models.CatalogDto;

public interface CatalogInfoService {
    CatalogDto createCatalogInfoMetricsUsage(CatalogDto catalogDto) throws NoResultsException;
}
