package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.service.CatalogInfoService;
import com.pichincha.repositorylog.service.models.CatalogDto;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@AllArgsConstructor
@RestController
public class CatalogInfoImpl implements CatalogInfoApi {

    private CatalogInfoService catalogInfoService;
    @Override
    public ResponseEntity<CatalogDto> createCatalogInfoMetricsUsage(CatalogDto catalogDto) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(catalogInfoService.createCatalogInfoMetricsUsage(catalogDto));
        } catch (NoResultsException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
    }
}
