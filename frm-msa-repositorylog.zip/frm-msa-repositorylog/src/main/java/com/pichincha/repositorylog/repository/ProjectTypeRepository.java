package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.ProjectType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectTypeRepository extends JpaRepository<ProjectType, Long> {
    ProjectType findProjectTypeByName(String name);
}
