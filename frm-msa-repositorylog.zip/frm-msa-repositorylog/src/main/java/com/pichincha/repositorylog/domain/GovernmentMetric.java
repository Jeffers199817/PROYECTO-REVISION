package com.pichincha.repositorylog.domain;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "opt_government_metrics")
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder(toBuilder = true)
public class GovernmentMetric {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	Long id;

	@ManyToOne
	@JoinColumn(name = "id_repositorylog")
	RepositoryGit repositoryLog;

	@Column(name = "naming_repository")
	Boolean namingRepository;

	@Column(name = "has_openapi")
	Boolean hasOpenApi;

	@Column(name = "is_optimus")
	Boolean isOptimus;

	@Column(name = "has_catalog")
	Boolean hasCatalog;

	@Column(name = "record_status")
	String recordStatus;

	@Column(name = "creation_date")
	Date creationDate;

	@Column(name = "with_optimus")
	Boolean withOptimus;
}