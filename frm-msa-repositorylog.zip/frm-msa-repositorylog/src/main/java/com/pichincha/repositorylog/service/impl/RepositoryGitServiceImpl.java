package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.RepositoryGitRepository;
import com.pichincha.repositorylog.service.RepositoryGitService;
import com.pichincha.repositorylog.service.mapper.MapStructMapper;
import com.pichincha.repositorylog.service.models.RepositoryDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@AllArgsConstructor
@Service
public class RepositoryGitServiceImpl implements RepositoryGitService {

    private RepositoryGitRepository repositoryGitRepository;
    private MapStructMapper mapper;

    @Override
    public List<RepositoryDTO> getLogRepositoryByName(String name) {
        List<RepositoryGit> resultList=repositoryGitRepository.getRepositoryByName(name);
        if(resultList.isEmpty()){
            throw new NoResultsException("NO SE ENCONTRO RESPOSITORIOS");
        }else{
            List<RepositoryDTO> repositoryDTOList=new ArrayList<>();

            resultList.stream().forEach(r->{
                repositoryDTOList.add(mapper.repositoryGitToRepositoryDTO(r));
            });
            return repositoryDTOList;
        }
    }

    @Override
    public RepositoryDTO createLogRepository(RepositoryDTO repositoryDTO) {
        RepositoryGit repositoryGit=mapper.repositoryDTOTORepositoryGit(repositoryDTO);
        repositoryGit.setCreateDate(new Date());
        RepositoryGit repoLog=this.repositoryGitRepository.save(repositoryGit);

        return mapper.repositoryGitToRepositoryDTO(repoLog);
    }

    @Override
    public List<RepositoryDTO> getAllLogsRepository() {
        List<RepositoryGit> resultList=this.repositoryGitRepository.findAll();
        if(resultList.isEmpty()){
            throw new NoResultsException("NO SE ENCONTRO RESPOSITORIOS");
        }else{
            List<RepositoryDTO> repositoryDTOList=new ArrayList<>();

            resultList.stream().forEach(r->{
                repositoryDTOList.add(mapper.repositoryGitToRepositoryDTO(r));
            });
            return repositoryDTOList;
        }
    }
}
