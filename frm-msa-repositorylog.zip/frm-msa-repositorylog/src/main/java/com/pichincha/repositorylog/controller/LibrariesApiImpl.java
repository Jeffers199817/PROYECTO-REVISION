package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.service.LibraryValidationService;
import com.pichincha.repositorylog.service.models.LibraryDetailDTO;
import com.pichincha.repositorylog.service.models.MetricDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@AllArgsConstructor
@Slf4j
@RestController
public class LibrariesApiImpl implements LibrariesApi {

    private LibraryValidationService libraryValidationService;

    @Override
    public ResponseEntity<Void> createValidationLibrary(String authorization, MetricDto metricDto) {
        libraryValidationService.createLibraryValidation(metricDto, authorization);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @Override
    public ResponseEntity<List<LibraryDetailDTO>> getAllLibraries(Integer pageNumber) {
        return LibrariesApi.super.getAllLibraries(pageNumber);
    }
}
