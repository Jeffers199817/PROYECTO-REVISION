package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.RepositoryGit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MetricUsageRepository extends JpaRepository<RepositoryGit,Long> {
    @Query(value = "select r from RepositoryGit r where r.repositoryName=?1 and r.repositoryCode=?2",nativeQuery = false)
    List<RepositoryGit> getRepositoriesByNameAndCode(String name,String code);

    @Query(value = "select r from RepositoryGit r where r.repositoryCode=?1 and r.branch=?2",nativeQuery = false)
    List<RepositoryGit> getRepositoriesByCodeAndBranch(String code,String branch);


}
