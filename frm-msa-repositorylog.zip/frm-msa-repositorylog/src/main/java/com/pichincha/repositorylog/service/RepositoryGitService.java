package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.service.models.RepositoryDTO;

import java.util.List;

public interface RepositoryGitService {

    List<RepositoryDTO> getLogRepositoryByName(String name);

    RepositoryDTO createLogRepository(RepositoryDTO repositoryDTO);

    List<RepositoryDTO> getAllLogsRepository();

}
