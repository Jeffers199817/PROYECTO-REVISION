package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.service.OptimusService;
import com.pichincha.repositorylog.service.models.PostOptimusRegisterRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@AllArgsConstructor
@RestController
public class OptimusApiImpl implements OptimusApi {

    private final OptimusService optimusService;

    @Override
    public ResponseEntity<Void> postOptimusRegister(PostOptimusRegisterRequest postOptimusRegisterRequest) {
        try {
            optimusService.postOptimusRegister(postOptimusRegisterRequest);
            return ResponseEntity.status(HttpStatus.CREATED).build();
        } catch (NoResultsException e)  {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<PostOptimusValidateResponse> postOptimusValidate(PostOptimusValidateRequest postOptimusValidateRequest) {
        PostOptimusValidateResponse responseOptimusValidate = optimusService.postOptimusValidate(postOptimusValidateRequest);
        return ResponseEntity.status(HttpStatus.OK).body(responseOptimusValidate);
    }
}
