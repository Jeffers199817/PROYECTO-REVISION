package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.service.models.DesignSystemDto;

import java.io.IOException;

public interface DesignSystemService {

    DesignSystemDto createDesignSystemMetricsUsage(DesignSystemDto designSystemDto) throws IOException;
}
