package com.pichincha.repositorylog.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "OPT_MUTATION_METRIC")
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder(toBuilder = true)
public class MutationMetricEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	Long id;

	@NotNull
	@ManyToOne
	@JoinColumn(name = "ID_REPOSITORYLOG")
	RepositoryGit repositoryLog;

	@NotNull
	@Column(name = "COVERAGE_RATE")
	BigDecimal coverageRate;

	@NotNull
	@Column(name = "MUTATION_RATE")
	BigDecimal mutationRate;

	@NotNull
	@Column(name = "STATUS")
	String status;

	@NotNull
	@Column(name = "CREATION_DATE")
	LocalDateTime creationDate;

	@NotNull
	@Column(name = "MODIFICATION_DATE")
	LocalDateTime modificationDate;
	
	@Transient
	public Boolean isUpdated() {
		return !creationDate.equals(modificationDate);
	}

	@PrePersist
	void prePersist() {
		
		LocalDateTime now = LocalDateTime.now();
		
		if (creationDate == null) {
			creationDate = now;
		}

		if (modificationDate == null) {
			modificationDate = now;
		}

		if (status == null) {
			status = "ACTIVO";
		}
	}
}