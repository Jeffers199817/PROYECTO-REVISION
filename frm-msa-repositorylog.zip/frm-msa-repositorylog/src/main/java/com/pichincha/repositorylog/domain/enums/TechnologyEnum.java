package com.pichincha.repositorylog.domain.enums;

public enum TechnologyEnum {

	JAVA, 
	NET, 
	NODE, 
	UNKNOW
}