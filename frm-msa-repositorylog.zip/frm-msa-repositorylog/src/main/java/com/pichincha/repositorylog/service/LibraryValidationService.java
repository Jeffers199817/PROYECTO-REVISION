package com.pichincha.repositorylog.service;


import com.pichincha.repositorylog.service.models.LibraryDetailDTO;
import com.pichincha.repositorylog.service.models.MetricDto;

import java.util.List;

public interface LibraryValidationService {
    void createLibraryValidation(MetricDto metricDto, String authorization);
   List<LibraryDetailDTO> getAllLibraries(Integer page);
    void updateAllLibraries(Integer initValidation,Integer endValidation);
}
