package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.DesignSystemMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.DesignSystemRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.service.DesignSystemService;
import com.pichincha.repositorylog.service.models.DesignSystemComponentDto;
import com.pichincha.repositorylog.service.models.DesignSystemDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Slf4j
@AllArgsConstructor
@Service
public class DesignSystemServiceImpl implements DesignSystemService {

    private DesignSystemRepository designSystemRepository;
    private MetricUsageRepository metricUsageRepository;
    @Override
    public DesignSystemDto createDesignSystemMetricsUsage(DesignSystemDto designSystemDto) {

        List<RepositoryGit> repositoryGitList = metricUsageRepository.getRepositoriesByCodeAndBranch(designSystemDto.getIdRepository(), designSystemDto.getBranch());
        if (repositoryGitList.isEmpty()) {
            throw new NoResultsException("NO SE ENCONTRÓ REPOSITORIOS CON EL CODIGO: " + designSystemDto.getIdRepository());
        } else {
            List<DesignSystemMetric> designSystemMetrics = designSystemRepository.getDesignSystemMetricsByRepositoryLogId(repositoryGitList.get(0).getIdRepository());
            for (DesignSystemMetric designSystemMetric: designSystemMetrics) {
                designSystemMetric.setRecordStatus("INACTIVO");
                designSystemRepository.save(designSystemMetric);
            }
            for (DesignSystemComponentDto designSystemComponentDto: designSystemDto.getComponents()) {
                DesignSystemMetric newDesignSystemMetric = new DesignSystemMetric();
                newDesignSystemMetric.setRepositoryLog(repositoryGitList.get(0));
                newDesignSystemMetric.setUsing(designSystemDto.getUsing());
                newDesignSystemMetric.setType(designSystemDto.getType().getValue());
                newDesignSystemMetric.setCount(designSystemComponentDto.getCount().longValue());
                newDesignSystemMetric.setComponent(designSystemComponentDto.getComponent());
                newDesignSystemMetric.setRecordStatus("ACTIVO");
                newDesignSystemMetric.setCreationDate(new Date());
                designSystemRepository.save(newDesignSystemMetric);
            }
        }
        return designSystemDto;
    }
}
