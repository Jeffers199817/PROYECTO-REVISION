package com.pichincha.repositorylog.service.impl;

import com.nimbusds.jose.shaded.gson.Gson;
import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.RepositoryGitRepository;
import com.pichincha.repositorylog.service.OptimusService;
import com.pichincha.repositorylog.service.mapper.GovernmentMetricMapper;
import com.pichincha.repositorylog.service.models.PostOptimusRegisterRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateResponse;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class OptimusServiceImpl implements OptimusService {

    private final RepositoryGitRepository repositoryGitRepository;
    private final GovernmentMetricRepository governmentMetricRepository;
    private final GovernmentMetricMapper governmentMetricMapper;

    @Value("${config.limit-date-to-verify}")
    public String limitDateString;

    private final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Transactional
    @Override
    public void postOptimusRegister(PostOptimusRegisterRequest postOptimusRegisterRequest) {
        log.debug("new request: {}", new Gson().toJson(postOptimusRegisterRequest));

        Optional<RepositoryGit> repository = getRepositoryGit(postOptimusRegisterRequest.getIdRepository(),
                postOptimusRegisterRequest.getNameRepository());

        if (repository.isEmpty()) {
            throw new NoSuchElementException("Repository not found: " + postOptimusRegisterRequest.getNameRepository());
        }

        try {
            governmentMetricRepository.save(governmentMetricMapper.toGovernmentMetric(postOptimusRegisterRequest, repository.get()));
            log.info("Repository register successful: {}", postOptimusRegisterRequest.getNameRepository());
        } catch (IllegalArgumentException e) {
            throw new DataIntegrityViolationException("Error when save government metric repository: " + postOptimusRegisterRequest.getNameRepository());
        }
    }

    @Override
    public PostOptimusValidateResponse postOptimusValidate(PostOptimusValidateRequest postOptimusValidateRequest) {
        log.info("Data to search -->: {}", new Gson().toJson(postOptimusValidateRequest));

        String repositoryCode = postOptimusValidateRequest.getIdRepository();
        String repositoryName = postOptimusValidateRequest.getNameRepository();

        Optional<RepositoryGit> repository = getRepositoryGit(repositoryCode, repositoryName);
        if (repository.isEmpty()) {
            return new PostOptimusValidateResponse().valid(false);
        }
        log.info("Repository found -->: {}", new Gson().toJson(repository.get()));

        RepositoryGit repositoryGit = repository.get();
        try {
            log.info("Limit date -->: {}", limitDateString);
            Date limitDate = getDateByString(limitDateString);
            boolean isBefore = repositoryGit.getCreateDate().before(limitDate);
            log.info("Repository Git is before that limit date -->: {}", isBefore);

            if(isBefore){
                return new PostOptimusValidateResponse().valid(true);
            }
        } catch (Exception e) {
            log.error("Error when compare date of repositoryGit with the limit date: {}", e.getMessage());
            return new PostOptimusValidateResponse().valid(false);
        }

        Optional<GovernmentMetric> governmentMetricFound = governmentMetricRepository.findTopByRepositoryLogOrderByCreationDateDesc(repository.get());
        if (governmentMetricFound.isEmpty()) {
            return new PostOptimusValidateResponse().valid(false);
        }
        log.info("GovernmentMetricFound found -->: {}", new Gson().toJson(governmentMetricFound.get()));

        Boolean isOptimus = governmentMetricFound.get().getIsOptimus();
        Boolean withOptimus = governmentMetricFound.get().getWithOptimus();

        if (isOptimus == null || withOptimus == null) {
            return new PostOptimusValidateResponse().valid(false);
        }

        Boolean isOptimusRepository = isOptimus && withOptimus;

        return new PostOptimusValidateResponse().valid(isOptimusRepository);
    }

    private Optional<RepositoryGit> getRepositoryGit(String idRepository, String nameRepository) {
        return repositoryGitRepository
                .findByRepositoryCodeAndRepositoryNameAndBranchIsNull(idRepository, nameRepository);
    }


    public Date getDateByString(String dateToConvert) {
        try {
            log.info("Date to convert: {}", dateToConvert);
            return formatter.parse(dateToConvert);
        } catch (ParseException e) {
            throw new DateTimeParseException("Error parsing date", dateToConvert, 1);
        }
    }
}
