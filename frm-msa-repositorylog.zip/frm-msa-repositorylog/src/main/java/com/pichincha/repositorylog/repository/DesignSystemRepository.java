package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.DesignSystemMetric;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DesignSystemRepository extends JpaRepository<DesignSystemMetric,Long> {

    @Query(value = "select s from DesignSystemMetric s where s.repositoryLog.idRepository=?1 and s.recordStatus='ACTIVO'",nativeQuery = false)
    List<DesignSystemMetric> getDesignSystemMetricsByRepositoryLogId(Long repositoryCode);


}
