package com.pichincha.repositorylog.configuration;


import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

@Configuration
@Order(-1)
public class AadOAuth2ResourceServerSecurityConfig extends OncePerRequestFilter {

    @Value("${spring.cloud.azure.active-directory.credential.client-id}")
    private String clientId;

    @Value("${spring.cloud.azure.active-directory.credential.tenant-id}")
    private String tenantId;

    @Value("${spring.cloud.azure.active-directory.exclusion.uri}")
    private String exclusionUri;




    @SneakyThrows
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        if(isValidUrlRequest(request)){
            String accessToken=request.getHeader("Authorization").replaceAll("Bearer","").trim();
            URL jwkSetURL = new URL("https://login.microsoftonline.com/" + tenantId + "/discovery/v2.0/keys");
            JWKSet jwkSet = JWKSet.load(jwkSetURL);
            SignedJWT signedJWT = SignedJWT.parse(accessToken);
            String keyId = signedJWT.getHeader().getKeyID();
            JWK rsaKey = jwkSet.getKeyByKeyId(keyId);
            RSASSAVerifier verifier = new RSASSAVerifier(rsaKey.toRSAKey());
            boolean isInvalidValidVerify = signedJWT.verify( verifier);
            JWTClaimsSet claimsSet = signedJWT.getJWTClaimsSet();
            Date expirationTime = claimsSet.getExpirationTime();
            String appId = claimsSet.getStringClaim("appid");
            URI url = new URI("https://graph.microsoft.com/v1.0/applicationTemplates?$top=1");
            HttpRequest requestGraph = HttpRequest.newBuilder()
                    .uri(url)
                    .headers("Content-Type", "application/json8")
                    .headers("Authorization", "Bearer "+ accessToken)
                    .GET()
                    .build();
            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> responseGraph = client.send(requestGraph, HttpResponse.BodyHandlers.ofString());
            boolean isInvalid = responseGraph.body().contains("\"error\":");
            boolean isExpired = expirationTime.before(new Date());
            if (!isInvalidValidVerify && !isInvalid && !isExpired && clientId.equals(appId)) {
                filterChain.doFilter(request,response);
            }else{
                response.setStatus(HttpStatus.UNAUTHORIZED.value());
                filterChain.doFilter(request,response);

            }
        }else{
            filterChain.doFilter(request,response);
        }


    }

    /**
     * This method valid uris not in tracerExclusionUri
     * @param request is the httpRequest
     * @return return true if not exist in tracerExclusionUri
     */
    private boolean isValidUrlRequest(HttpServletRequest request){
        return Optional.of(exclusionUri).isPresent() && Arrays.stream(exclusionUri.split(",")).
                filter(exclusionUrls->request.getRequestURI().contains(exclusionUrls)).findFirst().isEmpty();

    }
}
