package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.LibraryValidation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LibraryValidationRepository extends JpaRepository<LibraryValidation,Long> {
    @Query(value = "select s from LibraryValidation s where s.repositoryLog.repositoryCode=?1 and s.recordStatus='ACTIVO'",nativeQuery = false)
    LibraryValidation getLibraryValidationByRepository(String repositoryCode);

    @Query(value = "select s from LibraryValidation s where s.repositoryLog.idRepository=?1 and s.recordStatus='ACTIVO'",nativeQuery = false)
    LibraryValidation getLibraryValidationByRepositoryLogId(Long repositoryCode);

    @Query(value = "select s from LibraryValidation s where s.recordStatus='ACTIVO' and s.idLibraryValidation>=?1 and s.idLibraryValidation<=?2 ",nativeQuery = false)
    List<LibraryValidation> getListLibrariesValidationActive(Long initValidation,Long endValidation);


}
