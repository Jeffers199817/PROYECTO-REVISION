package com.pichincha.repositorylog.service.impl;

import com.pichincha.repositorylog.domain.MutationMetricEntity;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.MutationMetricRepository;
import com.pichincha.repositorylog.service.MutationMetricService;
import com.pichincha.repositorylog.service.mapper.MutationMetricMapper;
import com.pichincha.repositorylog.service.models.MutationMetricDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class MutationMetricServiceImpl implements MutationMetricService {

	private final MetricUsageRepository metricUsageRepository;

	private final MutationMetricRepository mutationTestRepository;

	private final MutationMetricMapper mutationMetricMapper;

	@Override
	public MutationMetricDto save(MutationMetricDto mutationMetricDto) {

		List<RepositoryGit> repositoryGitList = metricUsageRepository.getRepositoriesByCodeAndBranch(mutationMetricDto.getIdRepository(),
				mutationMetricDto.getBranch());

		if (repositoryGitList.isEmpty()) {
			throw new NoResultsException("No se encontr\u00F3 repositorios con el cu00F3digo: " + mutationMetricDto.getIdRepository());
		}

		RepositoryGit repositoryGit = repositoryGitList.get(0);

		Optional<MutationMetricEntity> optional = mutationTestRepository.findByRepositoryLogId(repositoryGit.getIdRepository());

		MutationMetricEntity mutationMetricEntity = null;

		if (optional.isPresent()) {
			mutationMetricEntity = optional.get().toBuilder()
					.mutationRate(mutationMetricDto.getMutationRate())
					.coverageRate(mutationMetricDto.getCoverageRate())
					.modificationDate(LocalDateTime.now())
					.build();
		} else {
			mutationMetricEntity = mutationMetricMapper.toMutationMetricEntity(mutationMetricDto)
					.toBuilder()
					.repositoryLog(repositoryGit)
					.build();
		}

		mutationMetricEntity = mutationTestRepository.save(mutationMetricEntity);

		return mutationMetricMapper.toMutationMetricDto(mutationMetricEntity);
	}
}