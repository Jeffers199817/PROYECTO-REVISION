package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.service.StandardValidationService;
import com.pichincha.repositorylog.service.models.MetricDto;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@AllArgsConstructor
@RestController
public class StandarsApiImpl implements StandarsApi {

    private StandardValidationService standardValidationService;

    @Override
    public ResponseEntity<Void> createValidationStandard(MetricDto metricDto) {
        standardValidationService.createStandardValidation(metricDto);
        return ResponseEntity.status(HttpStatus.CREATED).build();

    }
}
