package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.StandardValidation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface StandardValidationRepository extends JpaRepository<StandardValidation,Long> {

    @Query(value = "select s from StandardValidation s where s.repositoryLog.repositoryCode=?1 and s.recordStatus='ACTIVO'",nativeQuery = false)
    StandardValidation getStandardValidationByRepository(String repositoryCode);

    @Query(value = "select s from StandardValidation s where s.repositoryLog.idRepository=?1 and s.recordStatus='ACTIVO'",nativeQuery = false)
    StandardValidation getStandardValidationByRepositoryLogId(Long repositoryCode);
}
