
package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.service.DesignSystemService;
import com.pichincha.repositorylog.service.models.DesignSystemDto;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@AllArgsConstructor
@RestController
public class DesignSystemApiImpl implements DesignSystemApi {

    private DesignSystemService designSystemService;
    @Override
    public ResponseEntity<DesignSystemDto> createDesignSystemMetricsUsage(DesignSystemDto designSystemDto) {

        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(designSystemService.createDesignSystemMetricsUsage(designSystemDto));
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
    }

}
