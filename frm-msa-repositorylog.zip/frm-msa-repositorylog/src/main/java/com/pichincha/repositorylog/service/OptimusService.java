package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.service.models.PostOptimusRegisterRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateRequest;
import com.pichincha.repositorylog.service.models.PostOptimusValidateResponse;

public interface OptimusService {
    void postOptimusRegister(PostOptimusRegisterRequest postOptimusRegisterRequest);
    PostOptimusValidateResponse postOptimusValidate(PostOptimusValidateRequest postOptimusValidateRequest);
}
