package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.service.LibraryValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProcessLibrariesAllApiImpl implements ProcessAllLibrariesApi {

    @Autowired
    private LibraryValidationService libraryValidationService;

    @Override
    public ResponseEntity<String> processAllLibraries(Integer initValidation, Integer endValidation) {
        libraryValidationService.updateAllLibraries(initValidation,endValidation);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body("Accepted process libraries from "+initValidation+" to "+endValidation);
    }
}
