package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.service.models.MetricDto;

import java.io.IOException;
import java.util.List;

public interface MetricsService {
    MetricDto createMetricUsage(MetricDto metricDto) throws IOException;
    List<MetricDto> getAllMetricsUsage();
}
