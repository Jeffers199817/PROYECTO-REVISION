package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.service.models.MetricDto;

public interface StandardValidationService {
    void createStandardValidation(MetricDto metricDto);
}
