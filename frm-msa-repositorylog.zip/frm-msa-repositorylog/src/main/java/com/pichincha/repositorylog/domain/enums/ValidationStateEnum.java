package com.pichincha.repositorylog.domain.enums;

public enum ValidationStateEnum {

    VALIDADO,NO_VALIDADO
}
