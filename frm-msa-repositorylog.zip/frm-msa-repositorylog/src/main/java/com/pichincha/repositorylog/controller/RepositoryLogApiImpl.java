package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.service.RepositoryGitService;
import com.pichincha.repositorylog.service.models.RepositoryDTO;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@AllArgsConstructor
@RestController
@CrossOrigin(origins = "*")
public class RepositoryLogApiImpl implements RepositoryApi {

    private RepositoryGitService repositoryGitService;

    @Override
    public ResponseEntity<RepositoryDTO> createLogRepo(RepositoryDTO repositoryDTO) {
        return ResponseEntity.status(HttpStatus.CREATED).body(repositoryGitService.createLogRepository(repositoryDTO));
    }

    @Override
    public ResponseEntity<List<RepositoryDTO>> findRepositoryByName(String repositoryName) {
        try{
            return ResponseEntity.ok(repositoryGitService.getLogRepositoryByName(repositoryName));
        }catch (NoResultsException e){
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
    }

    @Override
    public ResponseEntity<List<RepositoryDTO>> getAllRepository() {
        try{
            return ResponseEntity.ok(repositoryGitService.getAllLogsRepository());
        }catch (NoResultsException e){
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
    }
}
