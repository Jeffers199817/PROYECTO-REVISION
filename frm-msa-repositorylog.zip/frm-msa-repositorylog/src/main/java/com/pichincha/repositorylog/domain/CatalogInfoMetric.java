package com.pichincha.repositorylog.domain;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "opt_catalog_info_metrics")
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder(toBuilder = true)
public class CatalogInfoMetric {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	Long id;

	@ManyToOne
	@JoinColumn(name = "id_repositorylog")
	RepositoryGit repositoryLog;

	@Column(name = "file_content")
	String fileContent;

	@Column(name = "record_status")
	String recordStatus;

	@Column(name = "creation_date")
	Date creationDate;
}