package com.pichincha.repositorylog.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.LibraryValidation;
import com.pichincha.repositorylog.domain.LibraryValidationDetail;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.domain.enums.TechnologyEnum;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.LibraryValidationDetailRepository;
import com.pichincha.repositorylog.service.DetailLibraryValidationService;
import com.pichincha.repositorylog.service.ReactArchitectureStandardService;
import com.pichincha.repositorylog.service.models.LibraryDTO;
import com.pichincha.repositorylog.service.models.LibraryDetailDTO;
import com.pichincha.repositorylog.service.models.ProjectTypeDTO;
import com.pichincha.repositorylog.service.models.RepositoryDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;
import java.io.StringReader;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

@AllArgsConstructor
@Service
@Slf4j
public class DetailLibraryValidationServiceImpl implements DetailLibraryValidationService {

	private static final String ACTIVO = "ACTIVO";
	private static final String TYPESCRIPT_SDK = "@pichincha/typescript-sdk";

	private static final String REACT_LIB_NAME = "react";
	private static final String BB_COMMONS = "@pichincha/bb-commons";
	private static final String GROUP = "group:";
	private static final String VERSION = "version:";
	private static final String NAME = "name:";
	private static final String OPTIMUS_SPRING_ADAPTER_WEB = "com.pichincha.optimus.adapters:optimus-spring-adapters-web";
	private static final String OPTIMUS_SPRING_ADAPTERS_HTTP_CLIENT = "com.pichincha.optimus.adapters:optimus-spring-adapters-http-client";
	private static final String OPTIMUS_SPRING_CUSTOM_SESSION_B2C = "com.pichincha.business.banking.services:optimus-spring-custom-session-b2c";

	private static final String OPTIMUS_MAIN="OptimusMainApplication";

	private static final String OPTIMUS_MAVEN="Framework/maven";

	private ReactArchitectureStandardService reactArchitectureStandarService;

	private LibraryValidationDetailRepository libraryValidationDetailRepository;

	private GovernmentMetricRepository governmentMetricRepository;

	public void validation(LibraryValidation libraryValidation, RepositoryGit repositoryGit, String authorization) {
		log.info("Libraries validations async started {}", libraryValidation.getFileName());
		if (libraryValidation.getFileName().equals("build-gradle")) {
			parseGradleDependencies(libraryValidation.getConfigurationContentFile(), libraryValidation);
		}

		if (libraryValidation.getFileName().equals("package-json")) {
			parseNPMDependencies(libraryValidation.getConfigurationContentFile(), libraryValidation, repositoryGit, authorization);
		}

		if (libraryValidation.getFileName().equals("pom-xml")) {
			parsePOMDependencies(libraryValidation.getConfigurationContentFile(), libraryValidation);
		}

		if (libraryValidation.getFileName().equals("csproj")) {
			parseCSProjDependencies(libraryValidation.getConfigurationContentFile(), libraryValidation);
		}

		log.info("Libraries validations async is finished");
	}

	private static LibraryValidationDetail parseGradleLine(String implementationBlock, LibraryValidation libraryValidation) {
		implementationBlock=implementationBlock.replace("\"","'");
		int newImplementationStart = implementationBlock.indexOf("'") + "'".length();

		int secondImplementationStart = implementationBlock.indexOf("'", newImplementationStart);
		String newImplementationDependency = implementationBlock.substring(newImplementationStart, secondImplementationStart);
		String group = "";
		String name = "";
		String version = "latest";

		String subStringVerify = implementationBlock.substring(0, secondImplementationStart);
		
		if (subStringVerify.contains(GROUP)) {

			if (implementationBlock.indexOf(GROUP) > -1) {
				int groupStart = implementationBlock.indexOf(GROUP) + GROUP.length();
				int newImplGroupStart = implementationBlock.indexOf("'", groupStart) + "'".length();
				int newImplGroupEnd = implementationBlock.indexOf("'", newImplGroupStart);
				group = implementationBlock.substring(newImplGroupStart, newImplGroupEnd);
			}

			if (implementationBlock.indexOf(NAME) > -1) {
				int nameStart = implementationBlock.indexOf(NAME) + NAME.length();
				int newImplNameStart = implementationBlock.indexOf("'", nameStart) + "'".length();
				int newImplNameEnd = implementationBlock.indexOf("'", newImplNameStart);
				name = implementationBlock.substring(newImplNameStart, newImplNameEnd);
			}

			if (implementationBlock.indexOf(VERSION) > -1) {
				int versionStart = implementationBlock.indexOf(VERSION) + VERSION.length();
				int newImplVersionStart = implementationBlock.indexOf("'", versionStart) + "'".length();
				int newImplVersionEnd = implementationBlock.indexOf("'", newImplVersionStart);
				version = implementationBlock.substring(newImplVersionStart, newImplVersionEnd);
			}
		} else {
			String[] dependencyPieces = newImplementationDependency.split(":");
			group = dependencyPieces.length > 0 ? dependencyPieces[0] : "";
			name = dependencyPieces.length > 1 ? dependencyPieces[1] : "";
			version = dependencyPieces.length > 2 ? dependencyPieces[2] : "latest";
		}

		LibraryValidationDetail libraryValidationDetail = new LibraryValidationDetail();
		libraryValidationDetail.setLibraryName(group + ":" + name);
		libraryValidationDetail.setVersion(version);
		libraryValidationDetail.setCreationDate(new Date());
		libraryValidationDetail.setLibraryValidation(libraryValidation);
		libraryValidationDetail.setRecordStatus(ACTIVO);

		return libraryValidationDetail;
	}

	private void parseGradleDependencies(String contentFile, LibraryValidation libraryValidation) {

		byte[] decodedBytes = Base64.getDecoder().decode(contentFile);
		String content = new String(decodedBytes);

		saveGradleDependencies(content, "implementation", libraryValidation);
		saveGradleDependencies(content, "compileOnly", libraryValidation);
		saveGradleDependencies(content, "developmentOnly", libraryValidation);
		saveGradleDependencies(content, "testImplementation", libraryValidation);
	}

	private void saveGradleDependencies(String content, String compileOnly, LibraryValidation libraryValidation) {
		String[] compileOnlyBlocksSample = content.split(compileOnly);
		String[] compileOnlyBlocks = new String[compileOnlyBlocksSample.length - 1];

		System.arraycopy(compileOnlyBlocksSample, 1, compileOnlyBlocks, 0, compileOnlyBlocks.length);

		for (String implementationBlock : compileOnlyBlocks) {

			LibraryValidationDetail libraryValidationDetail = parseGradleLine(implementationBlock, libraryValidation);

			libraryValidationDetailRepository.save(libraryValidationDetail);

			if (libraryValidationDetail.getLibraryName().equals(OPTIMUS_SPRING_ADAPTER_WEB)
					|| libraryValidationDetail.getLibraryName().equals(OPTIMUS_SPRING_ADAPTERS_HTTP_CLIENT)
					|| libraryValidationDetail.getLibraryName().equals(OPTIMUS_SPRING_CUSTOM_SESSION_B2C)
					|| content.contains(OPTIMUS_MAIN))
			{

				GovernmentMetric governmentMetric = governmentMetricRepository.getGovernmentMetricByRepositoryLogId(libraryValidation.getRepositoryLog().getIdRepository());
				if (governmentMetric != null && !governmentMetric.getIsOptimus()) {
					governmentMetric.setIsOptimus(true);
					governmentMetricRepository.save(governmentMetric);
				}
			}
		}
	}

	public void parseNPMDependencies(String contentFile, LibraryValidation libraryValidation, RepositoryGit repositoryGit, String authorization) {
		log.info("START PARSING NPM DEPENDENCIES");
		byte[] decodedBytes = Base64.getDecoder().decode(contentFile);
		String content = new String(decodedBytes);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode rootNode = objectMapper.readTree(content);

			Iterator<Map.Entry<String, JsonNode>> fields = rootNode.path("dependencies").fields();
			while (fields.hasNext()) {
				Map.Entry<String, JsonNode> entry = fields.next();
				LibraryValidationDetail libraryValidationDetail = new LibraryValidationDetail();
				libraryValidationDetail.setLibraryName(entry.getKey());
				libraryValidationDetail.setVersion(entry.getValue().asText());
				libraryValidationDetail.setCreationDate(new Date());
				libraryValidationDetail.setLibraryValidation(libraryValidation);
				libraryValidationDetail.setRecordStatus(ACTIVO);
				libraryValidationDetailRepository.save(libraryValidationDetail);
				if (libraryValidationDetail.getLibraryName().equals(TYPESCRIPT_SDK) || libraryValidationDetail.getLibraryName().equals(BB_COMMONS)) {

					GovernmentMetric governmentMetric = governmentMetricRepository.getGovernmentMetricByRepositoryLogId(libraryValidation.getRepositoryLog().getIdRepository());
					if (governmentMetric != null && !governmentMetric.getIsOptimus()) {
						governmentMetric.setIsOptimus(true);
						governmentMetricRepository.save(governmentMetric);
					}
				}
				if (libraryValidationDetail.getLibraryName().equals(REACT_LIB_NAME)) {
					log.info("START SCANNING REACT ARCHITECTURE STANDARD");
					reactArchitectureStandarService.postScann(authorization, repositoryGit);
					log.info("END SCANNING REACT ARCHITECTURE STANDARD");
				}

			}
			Iterator<Map.Entry<String, JsonNode>> fieldsDev = rootNode.path("devDependencies").fields();
			while (fieldsDev.hasNext()) {
				Map.Entry<String, JsonNode> entry = fieldsDev.next();
				LibraryValidationDetail libraryValidationDetail = new LibraryValidationDetail();
				libraryValidationDetail.setLibraryName(entry.getKey());
				libraryValidationDetail.setVersion(entry.getValue().asText());
				libraryValidationDetail.setCreationDate(new Date());
				libraryValidationDetail.setLibraryValidation(libraryValidation);
				libraryValidationDetail.setRecordStatus(ACTIVO);
				libraryValidationDetailRepository.save(libraryValidationDetail);
				if (libraryValidationDetail.getLibraryName().equals(REACT_LIB_NAME)) {
					log.info("START SCANNING REACT ARCHITECTURE STANDARD");
					reactArchitectureStandarService.postScann(authorization, repositoryGit);
					log.info("END SCANNING REACT ARCHITECTURE STANDARD");
				}
			}

		} catch (IOException e) {
			log.debug("Error parsing npm packages: ", e.getMessage());
		}

	}

	private void parsePOMDependencies(String contentFile, LibraryValidation libraryValidation) {
		byte[] decodedBytes = Base64.getDecoder().decode(contentFile);
		String content = new String(decodedBytes);




		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			InputSource inputSource = new InputSource(new StringReader(content));
			Document doc = dBuilder.parse(inputSource);

			doc.getDocumentElement().normalize();

			NodeList dependencyNodes = doc.getElementsByTagName("dependency");

			for (int i = 0; i < dependencyNodes.getLength(); i++) {
				Node dependencyNode = dependencyNodes.item(i);

				if (dependencyNode.getNodeType() == Node.ELEMENT_NODE) {
					Element dependencyElement = (Element) dependencyNode;
					String groupId = dependencyElement.getElementsByTagName("groupId").item(0).getTextContent();
					String artifactId = dependencyElement.getElementsByTagName("artifactId").item(0).getTextContent();
					String version ="";
					if(dependencyElement.getElementsByTagName("version").item(0)!=null){
						version=dependencyElement.getElementsByTagName("version").item(0).getTextContent();
					}
					LibraryValidationDetail libraryValidationDetail = new LibraryValidationDetail();
					libraryValidationDetail.setLibraryName(groupId + ":" + artifactId);
					libraryValidationDetail.setVersion(version);
					libraryValidationDetail.setCreationDate(new Date());
					libraryValidationDetail.setLibraryValidation(libraryValidation);
					libraryValidationDetail.setRecordStatus(ACTIVO);
					libraryValidationDetailRepository.save(libraryValidationDetail);
				}
			}

			if(content.contains(OPTIMUS_MAVEN)){
				GovernmentMetric governmentMetric = governmentMetricRepository.getGovernmentMetricByRepositoryLogId(libraryValidation.getRepositoryLog().getIdRepository());
				if (governmentMetric != null && !governmentMetric.getIsOptimus()) {
					governmentMetric.setIsOptimus(true);
					governmentMetricRepository.save(governmentMetric);
				}
			}

		} catch (Exception e) {
			log.debug("Error parsing pom dependencies: " + e.getMessage());
		}

	}

	private void parseCSProjDependencies(String contentFile, LibraryValidation libraryValidation) {

		byte[] decodedBytes = Base64.getDecoder().decode(contentFile);
		String content = new String(decodedBytes);

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			InputSource inputSource = new InputSource(new StringReader(content));
			Document doc = dBuilder.parse(inputSource);

			doc.getDocumentElement().normalize();

			NodeList packageReferenceNodes = doc.getElementsByTagName("PackageReference");

			for (int i = 0; i < packageReferenceNodes.getLength(); i++) {
				Node packageReferenceNode = packageReferenceNodes.item(i);

				if (packageReferenceNode.getNodeType() == Node.ELEMENT_NODE) {
					Element packageReferenceElement = (Element) packageReferenceNode;
					String packageName = packageReferenceElement.getAttribute("Include");
					String version = packageReferenceElement.getAttribute("Version");

					LibraryValidationDetail libraryValidationDetail = new LibraryValidationDetail();
					libraryValidationDetail.setLibraryName(packageName);
					libraryValidationDetail.setVersion(version);
					libraryValidationDetail.setCreationDate(new Date());
					libraryValidationDetail.setLibraryValidation(libraryValidation);
					libraryValidationDetail.setRecordStatus(ACTIVO);
					libraryValidationDetailRepository.save(libraryValidationDetail);

				}
			}
		} catch (Exception e) {
			log.debug("Error parsing pom dependencies: " + e.getMessage());
		}

	}

	public void inactivateLibraryDetails(LibraryValidation libraryValidation) {
		libraryValidationDetailRepository.inactivatedDetailsByLibrary(libraryValidation.getIdLibraryValidation());
	}

	public List<LibraryDetailDTO> getAllLibraries(int page) {
		List<LibraryDetailDTO> ret = new ArrayList<>();

		Pageable pageable = PageRequest.of(0, 20, Sort.Direction.ASC, "idLibraryValidationDetail");

		libraryValidationDetailRepository.getAllLibraryValidationDetails(pageable).stream().forEach(libraryValidationDetail -> {
			LibraryDetailDTO libraryDetailDTO = new LibraryDetailDTO();
			libraryDetailDTO.setLibraryName(libraryValidationDetail.getLibraryName());
			libraryDetailDTO.setVersion(libraryValidationDetail.getVersion());
			libraryDetailDTO.setRecordStatus(libraryValidationDetail.getRecordStatus());
			libraryDetailDTO.setCreationDate(libraryValidationDetail.getCreationDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
			libraryDetailDTO.setIdLibraryValidationDetail(libraryValidationDetail.getIdLibraryValidationDetail());
			libraryDetailDTO.setLibraryDTO(new LibraryDTO());

			libraryDetailDTO.getLibraryDTO().setCreationDate(LocalDate.ofInstant(libraryValidationDetail.getLibraryValidation().getCreationDate().toInstant(), ZoneId.systemDefault()));
			libraryDetailDTO.getLibraryDTO().setValidationDate(LocalDate.ofInstant(libraryValidationDetail.getLibraryValidation().getValidationDate().toInstant(), ZoneId.systemDefault()));
			libraryDetailDTO.getLibraryDTO().setRecordStatus(libraryValidationDetail.getLibraryValidation().getRecordStatus());
			libraryDetailDTO.getLibraryDTO().setRepositoryDTO(new RepositoryDTO());
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setCelula(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getCelula());
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setCreateDate(LocalDate.ofInstant(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getCreateDate().toInstant(), ZoneId.systemDefault()));
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setEmailCreator(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getEmailCreator());
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setProjectCode(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getProjectCode());
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setRepositoryCode(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getRepositoryCode());

			if (libraryValidationDetail.getLibraryValidation().getFileName().equals("build-gradle") || libraryValidationDetail.getLibraryValidation().getFileName().equals("pom-xml")) {
				libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setTechnology(TechnologyEnum.JAVA.name());
			} else if (libraryValidationDetail.getLibraryValidation().getFileName().equals("package-json")) {
				libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setTechnology(TechnologyEnum.NODE.name());
			} else if (libraryValidationDetail.getLibraryValidation().getFileName().equals("csproject")) {
				libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setTechnology(TechnologyEnum.NET.name());
			} else {
				libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setTechnology(TechnologyEnum.UNKNOW.name());
			}

			if (libraryValidationDetail.getLibraryValidation().getRepositoryLog().getProjectType() != null) {
				ProjectTypeDTO projectTypeDTO = new ProjectTypeDTO();
				projectTypeDTO.setName(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getProjectType().getName());
				projectTypeDTO.setDescription(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getProjectType().getDescription());
				libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setProjectType(projectTypeDTO);
			}

			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setRepositoryName(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getRepositoryName());
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setTribe(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getTribe());
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setType(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getType());
			libraryDetailDTO.getLibraryDTO().getRepositoryDTO().setVersion(libraryValidationDetail.getLibraryValidation().getRepositoryLog().getVersion());

			ret.add(libraryDetailDTO);
		});

		return ret;
	}
}