package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.LibraryValidationDetail;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LibraryValidationDetailRepository extends JpaRepository<LibraryValidationDetail,Long> {

    @Modifying
    @Query(value = "update opt_library_validation_details set record_status='INACTIVO' where id_library_validation= :idLibrary",nativeQuery = true)
    void inactivatedDetailsByLibrary(@Param("idLibrary")Long idLibrary);

    @Query(value = "select d from LibraryValidationDetail d where d.libraryValidation.idLibraryValidation=:idLibrary and d.recordStatus='ACTIVO'",nativeQuery = false)
    List<LibraryValidationDetail> getLibraryValidationDetails(@Param("idLibrary")Long idLibrary);

    @Query(value = "select d from LibraryValidationDetail d",countQuery = "select count(d) from LibraryValidationDetail d",nativeQuery = false)
    Page<LibraryValidationDetail> getAllLibraryValidationDetails(Pageable pageable);


}
