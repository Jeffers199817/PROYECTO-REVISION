package com.pichincha.repositorylog.domain.enums;

public enum RepositoryTypeEnum {

        MF,SHELL,MTM,MTW,MHM,MHW

}
