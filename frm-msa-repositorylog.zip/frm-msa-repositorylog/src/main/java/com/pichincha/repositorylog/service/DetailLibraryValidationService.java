package com.pichincha.repositorylog.service;


import com.pichincha.repositorylog.domain.LibraryValidation;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.service.models.LibraryDetailDTO;

import java.util.List;

public interface DetailLibraryValidationService {
    void validation(LibraryValidation libraryValidation , RepositoryGit metricDto, String authorization);

    void inactivateLibraryDetails(LibraryValidation libraryValidation);

    List<LibraryDetailDTO> getAllLibraries(int page);

}
