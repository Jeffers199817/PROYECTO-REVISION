package com.pichincha.repositorylog.controller;

import com.pichincha.repositorylog.service.MetricsService;
import com.pichincha.repositorylog.service.models.MetricDto;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@AllArgsConstructor
@RestController
public class MetricsApiImpl implements MetricsApi {

    private MetricsService metricsService;
    @Override
    public ResponseEntity<MetricDto> createMetricsUsage(MetricDto metricDto) {

        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(metricsService.createMetricUsage(metricDto));
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
    }

    @Override
    public ResponseEntity<List<MetricDto>> getAllMetrics() {

        return ResponseEntity.ok(metricsService.getAllMetricsUsage());
    }
}
