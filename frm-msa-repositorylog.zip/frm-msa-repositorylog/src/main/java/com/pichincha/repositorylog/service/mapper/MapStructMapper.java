package com.pichincha.repositorylog.service.mapper;

import com.pichincha.repositorylog.domain.ProjectType;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.service.models.ProjectTypeDTO;
import com.pichincha.repositorylog.service.models.RepositoryDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MapStructMapper {
    RepositoryDTO repositoryGitToRepositoryDTO(RepositoryGit repositoryGit);

    RepositoryGit repositoryDTOTORepositoryGit(RepositoryDTO repositoryDTO);
    ProjectTypeDTO projectTypeToProjectTypeDTO(ProjectType projectType);
}
