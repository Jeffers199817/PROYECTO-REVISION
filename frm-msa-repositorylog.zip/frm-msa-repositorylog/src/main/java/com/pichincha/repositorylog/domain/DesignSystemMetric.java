package com.pichincha.repositorylog.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "opt_design_system_metrics")
public class DesignSystemMetric {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ds_metric")
    private Long idDSMetric;

    @ManyToOne
    @JoinColumn(name = "id_repositorylog")
    private RepositoryGit repositoryLog;

    @Column(name="p_using")
    private Boolean using;

    @Column(name="p_type")
    private String type;

    @Column(name="component")
    private String component;

    @Column(name="p_count")
    private Long count;

    @Column(name="record_status")
    private String recordStatus;

    @Column(name="creation_date")
    private Date creationDate;


}


