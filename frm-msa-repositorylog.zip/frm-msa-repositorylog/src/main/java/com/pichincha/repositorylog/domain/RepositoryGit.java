package com.pichincha.repositorylog.domain;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "opt_repositorylog")
@Entity
public class RepositoryGit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_repository")
    private Long idRepository;

    @Column(name="repository_name")
    private String repositoryName;

    @Column(name = "tribe")
    private String tribe;

    @Column(name = "celula")
    private String celula;

    @ManyToOne
    @JoinColumn(name = "project_type")
    private ProjectType projectType;

    @Column(name = "version")
    private String version;

    @Column(name="email_creator")
    private String emailCreator;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "creation_date")
    private Date createDate;

    @Column(name="repository_azure_code")
    private String  repositoryCode;

    @Column(name="project_azure_code")
    private String  projectCode;

    @Column(name="branch")
    private String branch;

    @Column(name="repository_uri")
    private String repositoryUri;

    @Column(name="type")
    private String type;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "repository_creation_date")
    private Date repositoryCreateDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "repository_modification_date")
    private Date repositoryModificationDate;

    @Column(name="committer_email_creation")
    private String committerEmailCreation;

    @Column(name="committer_email_modification")
    private String committerEmailModification;


}
