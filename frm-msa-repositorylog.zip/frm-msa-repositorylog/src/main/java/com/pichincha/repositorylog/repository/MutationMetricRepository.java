package com.pichincha.repositorylog.repository;

import com.pichincha.repositorylog.domain.MutationMetricEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface MutationMetricRepository extends JpaRepository<MutationMetricEntity, Long> {

	@Query(value = "SELECT m FROM MutationMetricEntity m WHERE m.repositoryLog.idRepository = :idRepository AND m.status = 'ACTIVO'")
	Optional<MutationMetricEntity> findByRepositoryLogId(@Param("idRepository") Long idRepository);

}