package com.pichincha.repositorylog.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "opt_library_validation_details")
public class LibraryValidationDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_library_validation_details")
    private Long idLibraryValidationDetail;

    @Column(name="library_name")
    private String libraryName;

    @Column(name="version")
    private String version;

    @Column(name="creation_date")
    private Date creationDate;

    @ManyToOne()
    @JoinColumn(name = "id_library_validation")
    private LibraryValidation libraryValidation;

    @Column(name="record_status")
    private String recordStatus;

}
