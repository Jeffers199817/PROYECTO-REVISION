package com.pichincha.repositorylog.service.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.pichincha.repositorylog.domain.GovernmentMetric;
import com.pichincha.repositorylog.domain.ProjectType;
import com.pichincha.repositorylog.domain.RepositoryGit;
import com.pichincha.repositorylog.exception.NoResultsException;
import com.pichincha.repositorylog.repository.GovernmentMetricRepository;
import com.pichincha.repositorylog.repository.MetricUsageRepository;
import com.pichincha.repositorylog.repository.ProjectTypeRepository;
import com.pichincha.repositorylog.service.MetricsService;
import com.pichincha.repositorylog.util.NamingRepositoryUtil;
import com.pichincha.repositorylog.service.models.MetricDto;
import com.pichincha.repositorylog.service.models.RepositoryPropertiesDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@AllArgsConstructor
@Service
public class MetricsServiceImpl implements MetricsService {

    private MetricUsageRepository metricUsageRepository;

    private ProjectTypeRepository projectTypeRepository;

    private GovernmentMetricRepository governmentMetricRepository;


    @Override
    public MetricDto createMetricUsage(MetricDto metricDto)  {

        MetricDto metricDtoResult = new MetricDto();
        RepositoryGit repositoryGitSave = new RepositoryGit();

        List<RepositoryGit> result=metricUsageRepository.getRepositoriesByCodeAndBranch(metricDto.getIdRepository(), metricDto.getBranch());
        if(result.isEmpty()){
            repositoryGitSave = createMetricWhenNotExist(metricDto, repositoryGitSave);
        }else{
            repositoryGitSave = updateMetricsWhenExist(metricDto, result);
        }
        GovernmentMetric governmentMetric = governmentMetricRepository.getGovernmentMetricByRepositoryLogId(repositoryGitSave.getIdRepository());
        GovernmentMetric newGovernmentMetric = new GovernmentMetric();
        newGovernmentMetric.setIsOptimus(false);
        if (governmentMetric != null) {
            governmentMetric.setRecordStatus("INACTIVO");
            governmentMetricRepository.save(governmentMetric);
            newGovernmentMetric.setIsOptimus(governmentMetric.getIsOptimus());
        }
        newGovernmentMetric.setCreationDate(new Date());
        newGovernmentMetric.setHasOpenApi(false);
        newGovernmentMetric.setHasCatalog(false);
        if (!newGovernmentMetric.getIsOptimus()) {
            newGovernmentMetric.setIsOptimus(metricDto.getType().getValue() == "FRONT" || metricDto.getType().getValue() == "BACK");
        }
        newGovernmentMetric.setNamingRepository(NamingRepositoryUtil.checkCompliance(repositoryGitSave.getRepositoryName()));
        newGovernmentMetric.setRecordStatus("ACTIVO");
        newGovernmentMetric.setRepositoryLog(repositoryGitSave);
        governmentMetricRepository.save(newGovernmentMetric);

        metricDtoResult.setBranch(repositoryGitSave.getBranch());
        metricDtoResult.setContentFile(metricDto.getContentFile());
        metricDtoResult.setIdProject(repositoryGitSave.getProjectCode());
        metricDtoResult.setIdRepository(repositoryGitSave.getRepositoryCode());
        metricDtoResult.setRepositoryName(repositoryGitSave.getRepositoryName());

        return metricDtoResult;
    }

    private RepositoryGit updateMetricsWhenExist(MetricDto metricDto, List<RepositoryGit> result) {
        RepositoryGit repositoryGitSave;
        repositoryGitSave= result.get(0);
        repositoryGitSave.setType(metricDto.getType().getValue());
        repositoryGitSave.setRepositoryName(metricDto.getRepositoryName());
        if(metricDto.getRepositoryCreateDate()!=null){
            ZoneId defaultZoneId = ZoneId.systemDefault();
            repositoryGitSave.setRepositoryCreateDate(Date.from(metricDto.getRepositoryCreateDate().atStartOfDay(defaultZoneId).toInstant()));
        }
        if(metricDto.getRepositoryModificationDate()!=null){
            ZoneId defaultZoneId = ZoneId.systemDefault();
            repositoryGitSave.setRepositoryModificationDate(Date.from(metricDto.getRepositoryModificationDate().atStartOfDay(defaultZoneId).toInstant()));
        } else {
            repositoryGitSave.setRepositoryModificationDate(new Date());
        }
        if(metricDto.getCommitterEmailCreation()!=null){
            repositoryGitSave.setCommitterEmailCreation(metricDto.getCommitterEmailCreation());
        }
        if(metricDto.getCommitterEmailModification()!=null){
            repositoryGitSave.setCommitterEmailModification(metricDto.getCommitterEmailModification());
        }
        metricUsageRepository.save(repositoryGitSave);
        return repositoryGitSave;
    }

    private RepositoryGit createMetricWhenNotExist(MetricDto metricDto, RepositoryGit repositoryGitSave) {
        repositoryGitSave.setRepositoryCode(metricDto.getIdRepository());
        repositoryGitSave.setRepositoryName(metricDto.getRepositoryName());
        repositoryGitSave.setProjectCode(metricDto.getIdProject());
        repositoryGitSave.setBranch(metricDto.getBranch());
        repositoryGitSave.setRepositoryUri(metricDto.getRepositoryUri());
        repositoryGitSave.setType(metricDto.getType().getValue());
        repositoryGitSave.setCreateDate(new Date());
        if(metricDto.getRepositoryCreateDate()!=null){
            ZoneId defaultZoneId = ZoneId.systemDefault();
            repositoryGitSave.setRepositoryCreateDate(Date.from(metricDto.getRepositoryCreateDate().atStartOfDay(defaultZoneId).toInstant()));
        }else{
            repositoryGitSave.setRepositoryCreateDate(new Date());
        }
        if(metricDto.getRepositoryModificationDate()!=null){
            ZoneId defaultZoneId = ZoneId.systemDefault();
            repositoryGitSave.setRepositoryModificationDate(Date.from(metricDto.getRepositoryModificationDate().atStartOfDay(defaultZoneId).toInstant()));
        }else{
            repositoryGitSave.setRepositoryModificationDate(new Date());
        }

        if(metricDto.getCommitterEmailCreation()!=null){
            repositoryGitSave.setCommitterEmailCreation(metricDto.getCommitterEmailCreation());
        }
        if(metricDto.getCommitterEmailModification()!=null){
            repositoryGitSave.setCommitterEmailModification(metricDto.getCommitterEmailModification());
        }


        if(!metricDto.getType().equals(MetricDto.TypeEnum.NONE)){
            byte[] contentFile = Base64.decodeBase64(metricDto.getContentFile());
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            String jsonString = new String(contentFile, StandardCharsets.UTF_8);
            JsonFactory factory = objectMapper.getFactory();

            try{
                JsonParser parser = factory.createParser(jsonString);
                JsonNode actualObj = objectMapper.readTree(parser);
                RepositoryPropertiesDto repositoryPropertiesDto = objectMapper.convertValue(actualObj, RepositoryPropertiesDto.class);
                repositoryGitSave.setCelula(repositoryPropertiesDto.getCelula());
                repositoryGitSave.setTribe(repositoryPropertiesDto.getTribe());
                repositoryGitSave.setEmailCreator(repositoryPropertiesDto.getCreatedByEmail());
                if(repositoryPropertiesDto.getType()!=null){
                    ProjectType projectType = projectTypeRepository.findProjectTypeByName(repositoryPropertiesDto.getType().name().toUpperCase());
                    repositoryGitSave.setProjectType(projectType);
                }
                repositoryGitSave.setVersion(repositoryPropertiesDto.getOptimusVersion());
            }catch(IllegalArgumentException | IOException e){
                log.error(e.getMessage());
            }

        }

        metricUsageRepository.save(repositoryGitSave);
        return repositoryGitSave;
    }

    public List<MetricDto> getAllMetricsUsage(){

        List<RepositoryGit> result=metricUsageRepository.findAll();

        if(result.isEmpty()){
            throw  new NoResultsException("NO SE ENCONTRARON RESULTADOS DE METRICAS");
        }else{
            List<MetricDto> metrics=new ArrayList<>();
            for (RepositoryGit repositoryGit : result) {
                MetricDto metricDto=new MetricDto();
                metricDto.setBranch(repositoryGit.getBranch());
                metricDto.setRepositoryName(repositoryGit.getRepositoryName());
                metricDto.setIdRepository(repositoryGit.getRepositoryCode());
                metricDto.setIdProject(repositoryGit.getProjectCode());
                if(repositoryGit.getType()==null){
                    metricDto.setType(MetricDto.TypeEnum.NONE);
                }else{
                    metricDto.setType(MetricDto.TypeEnum.valueOf(repositoryGit.getType()));
                }

                metricDto.setRepositoryUri(repositoryGit.getRepositoryUri());
                metricDto.setRepositoryPropertiesDto(new RepositoryPropertiesDto());
                metricDto.getRepositoryPropertiesDto().setCelula(repositoryGit.getCelula());
                metricDto.getRepositoryPropertiesDto().setTribe(repositoryGit.getTribe());

                if(repositoryGit.getProjectType()!=null && repositoryGit.getProjectType().getName()!=null){
                    metricDto.getRepositoryPropertiesDto().setType(RepositoryPropertiesDto.TypeEnum.valueOf(repositoryGit.getProjectType().getName()));
                }

                metricDto.getRepositoryPropertiesDto().setOptimusVersion(repositoryGit.getVersion());
                metricDto.getRepositoryPropertiesDto().setCreateDate(repositoryGit.getCreateDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
                metrics.add(metricDto);

            }
            return metrics;
        }

    }


}
