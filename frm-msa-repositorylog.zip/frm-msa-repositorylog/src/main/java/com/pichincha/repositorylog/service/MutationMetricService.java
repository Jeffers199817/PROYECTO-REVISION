package com.pichincha.repositorylog.service;

import com.pichincha.repositorylog.service.models.MutationMetricDto;

public interface MutationMetricService {
	public MutationMetricDto save(MutationMetricDto dto);
}
