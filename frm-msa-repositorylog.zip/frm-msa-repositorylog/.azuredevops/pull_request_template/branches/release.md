# Información general del cambio a Release:

Para poder aprobar el proceso llenar los datos adjuntos.

1. Tribu:  "ingresar Tribu"
2. Célula: "ingresar Célula" 
3. Producto/Servicio: "ingresar Producto/Servicio"
4. Sprint: "ingresar Sprint"
5. Release: "ingresar Release"
6. Descripción de los cambios: Implementación del nuevo Template
7. HU o Ticket en Jira: "ingresar #Jira"

DEV

1. [ ] Pruebas unitarias superadas - (Cobertura > 75%)
2. [ ] Pruebas unitarias de Arquitectura - (Cobertura > 80%)
3. [ ] Code Review entre Pares finalizado sin errores 
4. [ ] Cumplimiento Quality Gate en Sonarcloud. (SonarCloud sin alertas)


QA

1. [ ] Calidad de código superado (SonarCloud sin alertas)
2. [ ] Criterios de entrada superados (DoR).
3. [ ] Revisión manual de código superado. 
4. [ ] Pruebas de seguridad superadas

# Requerimiento Control de cambios: 

1. Aplicativo impactado: "Detalla el impacto en el proyecto"