package com.pichincha.sp.cycle.time.metric.tasklet.curada.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CurDataFilterRepository extends JpaRepository<DataFilter, Integer> {

  @Query("SELECT f FROM DataFilter f WHERE f.stage = :stage AND f.tasklet = :tasklet and f.enabled = true")
  List<DataFilter> findByStageAndTasklet(@Param("stage") String stage, @Param("tasklet") String tasklet);

}
