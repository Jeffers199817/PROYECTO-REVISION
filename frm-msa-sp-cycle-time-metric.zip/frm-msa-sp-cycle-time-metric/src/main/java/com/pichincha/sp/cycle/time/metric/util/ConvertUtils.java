package com.pichincha.sp.cycle.time.metric.util;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class ConvertUtils {

  private ConvertUtils() {
    throw new IllegalStateException("Utility class");
  }

  public static LocalDateTime convertToUTC(String dateString) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    ZonedDateTime zonedDateTime = ZonedDateTime.parse(dateString, formatter);
    return zonedDateTime.withZoneSameInstant(ZoneId.of("UTC")).toLocalDateTime();
  }

}
