package com.pichincha.sp.cycle.time.metric.tasklet.master.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimAssignee;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DimAssigneeRepository extends JpaRepository<DimAssignee, Long> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE MST.CYCLE_TIME_DIM_ASSIGNEE", nativeQuery = true)
  void truncateTable();
}