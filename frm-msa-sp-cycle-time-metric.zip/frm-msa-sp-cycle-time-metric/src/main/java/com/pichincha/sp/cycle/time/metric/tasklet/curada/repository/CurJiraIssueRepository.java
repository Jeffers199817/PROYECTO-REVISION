package com.pichincha.sp.cycle.time.metric.tasklet.curada.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraIssue;
import jakarta.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CurJiraIssueRepository extends JpaRepository<CurJiraIssue, Integer> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE CUR.JIRA_ISSUES", nativeQuery = true)
  void truncateTable();


  @Query(value = """
    SELECT issue_key
    FROM CUR.JIRA_ISSUES
    WHERE process_date = :processDate
    ORDER BY id
    OFFSET :offset ROWS
    FETCH NEXT :batchSize ROWS ONLY
""", nativeQuery = true)
  List<String> findIssueKeysAndProcessDateNow(
      @Param("offset") int offset,
      @Param("batchSize") int batchSize,
      @Param("processDate") LocalDate processDate
  );


  List<CurJiraIssue> findByProcessDate(LocalDate processDate);


  CurJiraIssue findByIssueKey(String issueKey);

}
