package com.pichincha.sp.cycle.time.metric.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class JobCompletionNotificationListener implements JobExecutionListener {

  private final RestTemplate restTemplate;
  private final ObjectMapper objectMapper = new ObjectMapper();

  private final ApplicationProperties applicationProperties;

  @Override
  public void afterJob(@NonNull JobExecution jobExecution) {

    if (applicationProperties.environment().equals("production")) {
      if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
        sendNotificationToTeams(jobExecution, "✅", "Éxito", "El job ha finalizado correctamente.");
      }
      if (jobExecution.getStatus() == BatchStatus.FAILED) {
        sendNotificationToTeams(jobExecution, "❌", "Error", "El job ha fallado.");
      }
    } else {
      if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
        log.info("Job finished with status: {}", jobExecution.getStatus());
      }
      if (jobExecution.getStatus() == BatchStatus.FAILED) {
        log.error("Job finished with status: {}", jobExecution.getStatus());
      }
    }

  }

  private void sendNotificationToTeams(JobExecution jobExecution, String icon, String title, String message) {
    try {
      String teamsMessage = createAdaptiveCard(jobExecution, icon, title, message);
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      HttpEntity<String> request = new HttpEntity<>(teamsMessage, headers);

      restTemplate.postForEntity(applicationProperties.teamsWebhook(), request, String.class);
      log.info("Send notification to Teams");
    } catch (Exception e) {
      log.error("Error sending notification to Teams: ", e);
    }
  }

  private String createAdaptiveCard(JobExecution jobExecution, String icon, String title, String message) {
    try {
      Map<String, Object> card = new HashMap<>();
      card.put("type", "MessageCard");
      card.put("themeColor", jobExecution.getStatus() == BatchStatus.FAILED ? "FF0000" : "008000");
      card.put("title", icon + " " + title);
      card.put("text", message + "\n\n**Job ID:** " + jobExecution.getJobId() +
        "\n**Estado:** " + jobExecution.getStatus() +
        "\n**Inicio:** " + jobExecution.getStartTime() +
        "\n**Fin:** " + jobExecution.getEndTime() +
        (jobExecution.getStatus() == BatchStatus.FAILED ? "\n**Error:** " + jobExecution.getAllFailureExceptions() : ""));

      return objectMapper.writeValueAsString(card);
    } catch (Exception e) {
      log.error("Error creating adaptive card: ", e);
      return "{}";
    }
  }
}
