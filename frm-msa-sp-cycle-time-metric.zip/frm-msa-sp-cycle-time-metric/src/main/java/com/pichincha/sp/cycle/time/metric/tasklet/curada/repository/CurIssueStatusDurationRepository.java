package com.pichincha.sp.cycle.time.metric.tasklet.curada.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurIssueStatusDuration;
import jakarta.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CurIssueStatusDurationRepository extends JpaRepository<CurIssueStatusDuration, Long> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE CUR.JIRA_ISSUE_STATUS_DURATION", nativeQuery = true)
  void truncateTable();

  CurIssueStatusDuration findByIssueKey(String issueKey);

  List<CurIssueStatusDuration> findByProjectKey(String projectKey);

  List<CurIssueStatusDuration> findByProcessDate(LocalDate processDate);

  List<CurIssueStatusDuration> findByEndDateBetween(LocalDate startDate, LocalDate endDate);

}