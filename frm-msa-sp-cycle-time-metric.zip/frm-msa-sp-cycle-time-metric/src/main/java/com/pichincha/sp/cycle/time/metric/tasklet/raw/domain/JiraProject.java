package com.pichincha.sp.cycle.time.metric.tasklet.raw.domain;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraProject;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.annotation.processing.Generated;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Generated("lombok")
@Getter
@Setter
@ToString
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@Entity
@Table(name = "\"JIRA_PROJECTS\"", schema = "RAW")
@AllArgsConstructor
public class JiraProject {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private Boolean archived;

  @Column(length = 11)
  private String archivedBy;
  private LocalDateTime archivedDate;

  private Boolean deleted;
  @Column(length = 51)
  private String deletedBy;
  private LocalDateTime deletedDate;

  @Column(length = 501)
  private String description;

  private Boolean isPrivate;

  @Column(length = 21)
  private String style;


  @Column(length = 101)
  private String name;

  @Column(length = 11)
  private String projectKey;

  @Column(length = 11)
  private String projectId;

  @Column(length = 21)
  private String projectType;

  @Column(length = 11)
  private String projectCategoryId;
  @Column(length = 101)
  private String projectCategoryName;
  private LocalDateTime createdAt;
  private LocalDate processDate;

  @Column(length = 11)
  private String cellId;
  @Column(length = 11)
  private String tribeId;


}