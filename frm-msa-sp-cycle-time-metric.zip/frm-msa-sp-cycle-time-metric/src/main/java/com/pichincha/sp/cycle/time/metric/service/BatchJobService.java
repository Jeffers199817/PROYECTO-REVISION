package com.pichincha.sp.cycle.time.metric.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class BatchJobService {

  private final JobLauncher jobLauncher;
  private final Job batchJob;
  private final Job batchJobRaw;
  private final Job batchJobCurada;
  private final Job batchJobMaster;

  @Async
  public void runJobAsync(String stage) {
    try {
      JobParameters jobParameters = new JobParametersBuilder()
          .addLong("time", System.currentTimeMillis())
          .toJobParameters();

      switch (stage) {
        case "RAW":
          jobLauncher.run(batchJobRaw, jobParameters);
          break;
        case "CURADA":
          jobLauncher.run(batchJobCurada, jobParameters);
          break;
        case "MASTER":
          jobLauncher.run(batchJobMaster, jobParameters);
          break;
        default:
          jobLauncher.run(batchJob, jobParameters);
          break;
      }
      log.info("Job executed successfully for stage: {}", stage);
    } catch (Exception e) {
      log.error("Error executing job for stage: {}", stage, e);
    }
  }
}