package com.pichincha.sp.cycle.time.metric.tasklet.raw.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraProject;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RawJiraProjectRepository extends JpaRepository<JiraProject, Integer> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE RAW.JIRA_PROJECTS", nativeQuery = true)
  void truncateTable();

  @Query(value = """
          SELECT *
          FROM RAW.JIRA_PROJECTS
          ORDER BY id
          OFFSET :offset ROWS
          FETCH NEXT :batchSize ROWS ONLY
      """, nativeQuery = true)
  List<JiraProject> findByOffsetAndBatchSize(@Param("offset") int offset,
      @Param("batchSize") int batchSize);

}

