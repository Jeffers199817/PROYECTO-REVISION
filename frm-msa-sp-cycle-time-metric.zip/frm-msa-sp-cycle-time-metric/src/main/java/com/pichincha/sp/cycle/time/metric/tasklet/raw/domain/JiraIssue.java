package com.pichincha.sp.cycle.time.metric.tasklet.raw.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import javax.annotation.processing.Generated;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Generated("lombok")
@Entity
@Table(name = "JIRA_ISSUES", schema = "RAW")
public class JiraIssue {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "project_key", nullable = false)
  private String projectKey;

  @Column(name = "issue_id", nullable = false)
  private Long issueId;

  @Column(name = "issue_key", nullable = false)
  private String issueKey;

  @Column(name = "summary", nullable = false)
  private String summary;

  @Column(name = "issue_type_name", nullable = false)
  private String issueTypeName;

  @Column(name = "issue_type_subtask", nullable = false)
  private Boolean issueTypeSubtask;

  @Column(name = "issue_type_id", nullable = false)
  private String issueTypeId;


  @Column(name = "reporter_email")
  private String reporterEmail;

  @Column(name = "reporter_name")
  private String reporterName;

  @Column(name = "reporter_active")
  private Boolean reporterActive;

  @Column(name = "assignee_email")
  private String assigneeEmail;

  @Column(name = "assignee_name")
  private String assigneeName;

  @Column(name = "assignee_active")
  private Boolean assigneeActive;

  @Column(name = "issue_partner")
  private String issuePartner;

  @Column(name = "status_name", nullable = false)
  private String statusName;

  @Column(name = "status_id", nullable = false)
  private Long statusId;

  @Column(name = "issue_created", nullable = false, updatable = false)
  private java.time.LocalDateTime issueCreated;
}
