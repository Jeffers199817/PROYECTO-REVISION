package com.pichincha.sp.cycle.time.metric.tasklet.raw.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraIssue;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RawJiraIssueRepository extends JpaRepository<JiraIssue, String> {

  @Query(value = """
          SELECT issue_key
          FROM RAW.JIRA_ISSUES
          ORDER BY id
          OFFSET :offset ROWS
          FETCH NEXT :batchSize ROWS ONLY
      """, nativeQuery = true)
  List<String> findIssueKeys(@Param("offset") int offset, @Param("batchSize") int batchSize);

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE RAW.JIRA_ISSUES", nativeQuery = true)
  void truncateTable();

  List<JiraIssue> findByProjectKey(String projectKey);


}
