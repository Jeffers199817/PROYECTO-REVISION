package com.pichincha.sp.cycle.time.metric.tasklet.curada;


import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;


@Component
@RequiredArgsConstructor
@Slf4j
public class FilterJiraIssueTasklet implements Tasklet {

  private static final int THREAD_POOL_SIZE = 20;

  private final CurJiraProjectRepository curProjectRepository;
  private final RawJiraIssueRepository rawIssueRepository;
  private final CurJiraIssueRepository repository;
  private final CurDataFilterRepository dataFilterRepository;

  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution,
    @NonNull ChunkContext chunkContext)
    throws Exception {

    log.info("Starting FilterJiraIssueTasklet");

    int offset = 0;
    int batchSize = 300;

    List<DataFilter> filters = dataFilterRepository.findByStageAndTasklet(
      "CUR",
      FilterJiraIssueTasklet.class.getSimpleName());

    ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);

    List<CurJiraProject> curJiraProjects = curProjectRepository.findByOffsetAndBatchSizeProcessDateNow(
      offset, batchSize, LocalDate.now());

    while (!curJiraProjects.isEmpty()) {
      List<CompletableFuture<Void>> futures = curJiraProjects.stream()
        .map(curJiraProject -> CompletableFuture.runAsync(
          () -> processProject(curJiraProject, filters), executorService)
        ).toList();

      CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

      offset += batchSize;
      curJiraProjects = curProjectRepository.findByOffsetAndBatchSizeProcessDateNow(offset,
        batchSize, LocalDate.now());
    }

    executorService.shutdown();

    log.info("Finished FilterJiraIssueTasklet");

    return RepeatStatus.FINISHED;
  }

  private void processProject(CurJiraProject curJiraProject, List<DataFilter> filters) {
    List<CurJiraIssue> curJiraIssues = rawIssueRepository
      .findByProjectKey(curJiraProject.getProjectKey())
      .stream()
      .map(issue -> mapToCurJiraIssue(issue, curJiraProject))
      .filter(c -> FiltersUtils.evaluateFilters(c, filters))
      .toList();

    if (!curJiraIssues.isEmpty()) {
      repository.saveAllAndFlush(curJiraIssues);
    }
  }

  private CurJiraIssue mapToCurJiraIssue(JiraIssue issue, CurJiraProject curJiraProject) {

    if (issue == null) {
      return null;
    }

    CurJiraIssue data = this.repository.findByIssueKey(issue.getIssueKey());

    CurJiraIssue curJiraIssue = new CurJiraIssue();

    if (data != null) {
      curJiraIssue = data;
    }

    return curJiraIssue.toBuilder()
      .projectKey(issue.getProjectKey())
      .issueKey(issue.getIssueKey())
      .issueTypeName(issue.getIssueTypeName().toUpperCase())
      .assigneeEmail(issue.getAssigneeEmail())
      .assigneeName(Optional.ofNullable(issue.getAssigneeName()).orElse("").toUpperCase())
      .issuePartner(issue.getIssuePartner())
      .statusName(issue.getStatusName().toUpperCase())
      .statusId(issue.getStatusId())
      .issueCreated(issue.getIssueCreated())
      .processDate(LocalDate.now())
      .cellId(curJiraProject.getCellId())
      .cellName(Optional.ofNullable(curJiraProject.getCellName()).orElse("UNKNOWN").toUpperCase())
      .tribeId(curJiraProject.getTribeId())
      .tribeName(Optional.ofNullable(curJiraProject.getTribeName()).orElse("UNKNOWN").toUpperCase())
      .build();
  }

}
