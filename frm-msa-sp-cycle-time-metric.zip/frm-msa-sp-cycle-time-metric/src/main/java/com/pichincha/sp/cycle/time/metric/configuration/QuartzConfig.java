package com.pichincha.sp.cycle.time.metric.configuration;

import com.pichincha.sp.cycle.time.metric.job.CycleTimeQuartzJob;
import lombok.AllArgsConstructor;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@AllArgsConstructor
public class QuartzConfig {

  private final ApplicationProperties applicationProperties;

  @Bean
  public JobDetail jobDetail() {
    return JobBuilder.newJob(CycleTimeQuartzJob.class)
        .withIdentity("batchJob")
        .storeDurably()
        .build();
  }

  @Bean
  public Trigger trigger() {

    return TriggerBuilder.newTrigger()
        .forJob(jobDetail())
        .withIdentity("batchJobTrigger")
        .withSchedule(CronScheduleBuilder.cronSchedule(applicationProperties.startTimeCron()))
        .build();
  }
}
