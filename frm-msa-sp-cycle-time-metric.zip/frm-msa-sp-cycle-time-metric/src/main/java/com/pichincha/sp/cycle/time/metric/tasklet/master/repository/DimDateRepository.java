package com.pichincha.sp.cycle.time.metric.tasklet.master.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimDate;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DimDateRepository extends JpaRepository<DimDate, Long> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE MST.CYCLE_TIME_DIM_DATE", nativeQuery = true)
  void truncateTable();
}