package com.pichincha.sp.cycle.time.metric.tasklet.curada.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraChangelog;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CurJiraChangelogRepository extends JpaRepository<CurJiraChangelog, Integer> {


  CurJiraChangelog findByChangelogId(Long changelogId);

  List<CurJiraChangelog> findByIssueKey(String issueKey);

}


