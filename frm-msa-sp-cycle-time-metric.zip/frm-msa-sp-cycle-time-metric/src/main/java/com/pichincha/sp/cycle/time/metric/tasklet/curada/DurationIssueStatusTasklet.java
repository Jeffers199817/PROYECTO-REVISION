package com.pichincha.sp.cycle.time.metric.tasklet.curada;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pichincha.sp.cycle.time.metric.exception.CustomException;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurIssueStatusDuration;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraChangelog;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DurationFilterStatus;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurIssueStatusDurationRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class DurationIssueStatusTasklet implements Tasklet {

  private final CurJiraChangelogRepository changelogRepository;
  private final CurJiraIssueRepository issueRepository;
  private final CurDataFilterRepository dataFilterRepository;
  private final CurIssueStatusDurationRepository issueStatusDurationRepository;
  private final ObjectMapper objectMapper = new ObjectMapper();
  private final ExecutorService executorService = Executors.newFixedThreadPool(
    Runtime.getRuntime().availableProcessors());

  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution,
    @NonNull ChunkContext chunkContext) throws Exception {

    log.info("Starting DurationIssueStatusTasklet");

    List<CurJiraIssue> issues = issueRepository.findByProcessDate(
      LocalDateTime.now().toLocalDate());

    List<DataFilter> filters = dataFilterRepository.findByStageAndTasklet("CUR",
      DurationIssueStatusTasklet.class.getSimpleName());

    List<CompletableFuture<CurIssueStatusDuration>> futures = issues.stream()
      .map(issue -> CompletableFuture.supplyAsync(() -> {
        try {
          return processIssue(issue, filters);
        } catch (JsonProcessingException e) {
          throw new CustomException("Error processing issue: " + issue.getIssueKey(), e);
        }
      }, executorService))
      .toList();

    List<CurIssueStatusDuration> issueStatusDurations = futures.stream()
      .map(CompletableFuture::join)
      .filter(Objects::nonNull)
      .toList();

    if (!issueStatusDurations.isEmpty()) {
      issueStatusDurationRepository.saveAllAndFlush(issueStatusDurations);
    }

    log.info("Finishing DurationIssueStatusTasklet");

    return RepeatStatus.FINISHED;
  }

  private CurIssueStatusDuration processIssue(CurJiraIssue issue, List<DataFilter> filters)
    throws JsonProcessingException {

    var response = this.issueStatusDurationRepository.findByIssueKey(issue.getIssueKey());

    if (response != null) {
      return response;
    }

    Map<String, Duration> statusDurations = new LinkedHashMap<>();
    LocalDateTime lastChangeTime = null;
    String lastStatus = null;

    List<CurJiraChangelog> changes = changelogRepository.findByIssueKey(issue.getIssueKey())
      .stream()
      .sorted(Comparator.comparing(CurJiraChangelog::getChangelogCreated))
      .toList();

    for (int i = 0; i < changes.size(); i++) {
      CurJiraChangelog current = changes.get(i);
      if (current.getItemToString() == null || current.getItemToString().isEmpty()) {
        continue;
      }

      LocalDateTime changeTime = current.getChangelogCreated();
      if (i < changes.size() - 1) {
        Duration duration = Duration.between(changeTime, changes.get(i + 1).getChangelogCreated());
        statusDurations.merge(current.getItemToString(), duration, Duration::plus);
      }
      lastChangeTime = changeTime;
      lastStatus = current.getItemToString();
    }

    if (lastChangeTime != null) {
      Duration finalDuration = Duration.between(lastChangeTime, LocalDateTime.now());
      statusDurations.merge(lastStatus, finalDuration, Duration::plus);
    }

    Map<String, Long> durationInSeconds = statusDurations.entrySet().stream()
      .filter(entry -> FiltersUtils.evaluateFilters(DurationFilterStatus.builder()
        .status(entry.getKey())
        .build(), filters))
      .collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getSeconds()));

    String jsonDurations = objectMapper.writeValueAsString(durationInSeconds);

    return CurIssueStatusDuration.builder()
      .issueKey(issue.getIssueKey())
      .projectKey(issue.getProjectKey())
      .statusDurations(jsonDurations)
      .processDate(LocalDateTime.now().toLocalDate())
      .endDate(
        lastChangeTime != null ? lastChangeTime.toLocalDate() : LocalDateTime.now().toLocalDate())
      .build();
  }
}