package com.pichincha.sp.cycle.time.metric.repository.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import javax.annotation.processing.Generated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IssueResponse {

  private int startAt;
  private int maxResults;
  private int total;
  private List<Issue> issues;

  @Generated("lombok")
  @Setter
  @Getter
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Issue {
    private String id;
    private String key;

    @JsonProperty("fields")
    private Fields fields;

    @Generated("lombok")
    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Fields {
      private String summary;

      @JsonProperty("issuetype")
      private IssueType issueType;

      @JsonProperty("reporter")
      private User reporter;

      @JsonProperty("assignee")
      private User assignee;

      @JsonProperty("customfield_10014")
      private String customField10014;

      private Status status;

      private String created;



      @Generated("lombok")
      @Setter
      @Getter
      @AllArgsConstructor
      @NoArgsConstructor
      public static class IssueType {
        private String name;
        private boolean subtask;
        private String id;
      }

      @Generated("lombok")
      @Setter
      @Getter
      @AllArgsConstructor
      @NoArgsConstructor
      public static class User {
        private String emailAddress;
        private String displayName;
        private boolean active;
      }

      @Data
      public static class Status {
        private String name;
        private Long id;
      }
    }
  }
}