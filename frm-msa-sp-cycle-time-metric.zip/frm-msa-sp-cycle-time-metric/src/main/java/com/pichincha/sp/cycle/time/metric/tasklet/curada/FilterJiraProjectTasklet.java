package com.pichincha.sp.cycle.time.metric.tasklet.curada;


import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.BmcCell;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.BmcTribe;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.BmcCellRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.BmcTribeRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraProjectRepository;

import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;

import java.time.LocalDate;
import java.util.List;

import java.util.Optional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;


@Component
@RequiredArgsConstructor
@Slf4j
public class FilterJiraProjectTasklet implements Tasklet {

  private final RawJiraProjectRepository projectRepository;
  private final CurJiraProjectRepository repository;
  private final CurDataFilterRepository dataFilterRepository;
  private final BmcCellRepository cellRepository;
  private final BmcTribeRepository tribeRepository;

  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution,
    @NonNull ChunkContext chunkContext)
    throws Exception {

    log.info("Starting FilterJiraProjectTasklet");

    int offset = 0;
    int batchSize = 300;

    List<DataFilter> filters = dataFilterRepository.findByStageAndTasklet(
      "CUR",
      FilterJiraProjectTasklet.class.getSimpleName());

    List<JiraProject> rawJiraProjects = projectRepository.findByOffsetAndBatchSize(offset,
      batchSize);

    while (!rawJiraProjects.isEmpty()) {

      List<CurJiraProject> curJiraProjects = rawJiraProjects.stream()
        .map(this::mapToCurJiraProject)
        .filter(curJiraProject -> FiltersUtils.evaluateFilters(curJiraProject, filters))
        .toList();

      if (!curJiraProjects.isEmpty()) {
        repository.saveAllAndFlush(curJiraProjects);
      }

      offset += batchSize;
      rawJiraProjects = projectRepository.findByOffsetAndBatchSize(offset, batchSize);
    }

    log.info("Finished FilterJiraProjectTasklet");

    return RepeatStatus.FINISHED;
  }

  private CurJiraProject mapToCurJiraProject(JiraProject project) {

    if (project == null) {
      return null;
    }

    CurJiraProject data = this.repository.findByProjectKey(project.getProjectKey());

    CurJiraProject curJiraProject = new CurJiraProject();

    if (data != null) {
      curJiraProject = data;
    }

    Optional<BmcCell> cell = Optional.ofNullable(this.cellRepository.findByIdCell(
      Integer.valueOf(Optional.ofNullable(project.getCellId()).orElse("-1"))));

    Optional<BmcTribe> tribe = Optional.ofNullable(this.tribeRepository.findByIdTribe(
      Integer.valueOf(Optional.ofNullable(project.getTribeId()).orElse("-1"))));

    return curJiraProject.toBuilder()
      .description(project.getDescription())
      .name(project.getName())
      .projectKey(project.getProjectKey())
      .projectId(project.getProjectId())
      .projectType(project.getProjectType())
      .projectCategoryId(project.getProjectCategoryId())
      .projectCategoryName(project.getProjectCategoryName())
      .createdAt(project.getCreatedAt())
      .processDate(LocalDate.now())
      .cellName(
        cell.orElse(BmcCell.builder().cellName("Unknown").build()).getCellName().toUpperCase())
      .tribeName(
        tribe.orElse(BmcTribe.builder().tribeName("Unknown").build()).getTribeName().toUpperCase())
      .tribeId(tribe.orElse(BmcTribe.builder().idTribe(0).build()).getIdTribe())
      .cellId(cell.orElse(BmcCell.builder().idCell(0).build()).getIdCell())
      .build();
  }


}
