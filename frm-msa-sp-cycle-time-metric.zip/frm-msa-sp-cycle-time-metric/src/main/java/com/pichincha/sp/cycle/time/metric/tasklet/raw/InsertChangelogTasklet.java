package com.pichincha.sp.cycle.time.metric.tasklet.raw;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import com.pichincha.sp.cycle.time.metric.repository.dto.ChangelogResponse.Changelog.Author;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.repository.JiraRepository;
import com.pichincha.sp.cycle.time.metric.repository.dto.ChangelogResponse;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraChangelog;
import com.pichincha.sp.cycle.time.metric.util.ConvertUtils;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class InsertChangelogTasklet implements Tasklet {

  private final JiraRepository jiraRepository;
  private final RawJiraChangelogRepository changelogRepository;
  private final RawJiraIssueRepository issueRepository;
  private final CurDataFilterRepository dataFilterRepository;
  private final ApplicationProperties applicationProperties;


  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution,@NonNull ChunkContext chunkContext) {

    log.info("Starting InsertChangelogTasklet");

    int offset = 0;
    int batchSize = 500;

    changelogRepository.truncateTable();

    List<DataFilter> filters = dataFilterRepository.findByStageAndTasklet(
      "RAW",
      InsertChangelogTasklet.class.getSimpleName());

    List<String> issueKeys = issueRepository.findIssueKeys(offset, batchSize);

    while (!issueKeys.isEmpty()) {

      List<List<String>> batches = partitionList(issueKeys, applicationProperties.threads().partitionInsertJiraChangelog());
      batches.forEach(batch -> {
        ExecutorService executor = Executors.newFixedThreadPool(applicationProperties.threads().insertJiraChangelog());
        List<CompletableFuture<Void>> futures = batch.stream()
            .map(issueKey -> CompletableFuture.runAsync(() -> processIssue(issueKey, filters), executor))
            .toList();

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        executor.shutdown();
      });

      offset += batchSize;
      issueKeys = issueRepository.findIssueKeys(offset, batchSize);
    }
    log.info("Finished InsertChangelogTasklet");
    return RepeatStatus.FINISHED;
  }

  private void processIssue(String issueKey, List<DataFilter> filters) {
    log.info("Processing issue: {}", issueKey);
    int startAt = 0;
    int maxResults = 100;
    boolean isLast;

    do {
      ChangelogResponse response = jiraRepository.getChangelog(issueKey, startAt, maxResults);

      if (response != null && response.getValues() != null) {
        List<JiraChangelog> changelogs = response.getValues().stream()
            .flatMap(changelog -> changelog.getItems().stream()
                .map(item -> mapToJiraChangelog(changelog, item, issueKey)))
          .filter(issue -> FiltersUtils.evaluateFilters(issue, filters))
          .toList();

        changelogRepository.saveAllAndFlush(changelogs);

        startAt += maxResults;
        isLast = response.getIsLast();
      } else {
        isLast = true;
      }
    } while (!isLast);
  }

  private static JiraChangelog mapToJiraChangelog(ChangelogResponse.Changelog changelog, ChangelogResponse.Changelog.Item item, String issueKey) {
    JiraChangelog jiraChangelog = new JiraChangelog();

    if (changelog.getAuthor() == null) {
      changelog.setAuthor(Author.builder()
          .displayName("UNKNOWN")
          .emailAddress("UNKNOWN")
          .active(false)
          .build());
    }

    jiraChangelog.setIssueKey(issueKey);
    jiraChangelog.setChangelogId(Long.parseLong(changelog.getId()));
    jiraChangelog.setAuthorEmail(changelog.getAuthor().getEmailAddress());
    jiraChangelog.setAuthorName(changelog.getAuthor().getDisplayName().toUpperCase());
    jiraChangelog.setAuthorActive(changelog.getAuthor().isActive());
    jiraChangelog.setItemField(item.getField().toUpperCase());
    jiraChangelog.setItemFieldType(item.getFieldType());
    jiraChangelog.setItemFieldId(item.getFieldId());
    jiraChangelog.setItemFrom(item.getFrom());
    jiraChangelog.setItemFromString(Optional.ofNullable(item.getFromString()).orElse("").toUpperCase());
    jiraChangelog.setItemTo(item.getTo());
    jiraChangelog.setItemToString(Optional.ofNullable(item.getToString()).orElse("").toUpperCase());

    jiraChangelog.setChangelogCreated(ConvertUtils.convertToUTC(changelog.getCreated()));
    return jiraChangelog;
  }


  private static  <T> List<List<T>> partitionList(List<T> list, int size) {
    List<List<T>> partitions = new ArrayList<>();
    for (int i = 0; i < list.size(); i += size) {
      partitions.add(list.subList(i, Math.min(i + size, list.size())));
    }
    return partitions;
  }
}