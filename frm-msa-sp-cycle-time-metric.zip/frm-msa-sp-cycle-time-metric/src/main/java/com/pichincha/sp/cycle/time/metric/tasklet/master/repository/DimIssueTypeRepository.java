package com.pichincha.sp.cycle.time.metric.tasklet.master.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimIssueType;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DimIssueTypeRepository extends JpaRepository<DimIssueType, Long> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE MST.CYCLE_TIME_DIM_ISSUE_TYPE", nativeQuery = true)
  void truncateTable();
}
