package com.pichincha.sp.cycle.time.metric.tasklet.curada.domain;

import javax.annotation.processing.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "BMC_CELL", schema = "CUR")
public class BmcCell {

    @Id
    @Column(name = "ID_CELL", nullable = false)
    private Integer idCell;

    @Column(name = "STATE", nullable = false, length = 8)
    private String state;

    @Column(name = "USER_AUDIT", length = 8)
    private String userAudit;

    @Column(name = "FINISH_DATE")
    private Date finishDate;

    @Column(name = "CELL_NAME", nullable = false, length = 80)
    private String cellName;

    @Column(name = "SQUAD", length = 80)
    private String squad;

    @Column(name = "ID_TRIBE", nullable = false)
    private Integer idTribe;

    @Column(name = "DESCRIPTION", length = 128)
    private String description;

    @Column(name = "PRODUCT_PREFIX", length = 4)
    private String productPrefix;

    @Column(name = "CELL_TYPE_ID")
    private Integer cellTypeId;

    @Column(name = "CREATION_DATE_CELL", length = 32)
    private String creationDateCell;

    @Column(name = "CREATION_DATE")
    private LocalDateTime creationDate;

    @Column(name = "MODIFICATION_DATE")
    private LocalDateTime modificationDate;

    @Column(name = "TAGS", length = 96)
    private String tags;

    @Column(name = "CELL_NAME_BU", length = 80)
    private String cellNameBu;

    @Column(name = "ID_TRIBE_BU")
    private Integer idTribeBu;

}
