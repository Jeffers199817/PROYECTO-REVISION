package com.pichincha.sp.cycle.time.metric.tasklet.master.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.Objects;
import javax.annotation.processing.Generated;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "CYCLE_TIME_DIM_ISSUE_TYPE", schema = "MST")
public class DimIssueType {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "issue_type_name", nullable = false, unique = true)
  private String issueTypeName;

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    DimIssueType that = (DimIssueType) o;
    return Objects.equals(issueTypeName, that.issueTypeName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(issueTypeName);
  }
}
