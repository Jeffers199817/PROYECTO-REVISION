package com.pichincha.sp.cycle.time.metric.util;

public class  ConstantsUtils {

  private ConstantsUtils() {
    throw new IllegalStateException("Utility class");
  }

  public static final String JOB_EXECUTION_ID = "jobExecutionId";
  public static final String RETRY_COUNT = "retryCount";

}
