package com.pichincha.sp.cycle.time.metric.tasklet.curada.domain;

import javax.annotation.processing.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Setter
@Getter
@Entity
@Builder(toBuilder = true)
@Table(name = "JIRA_ISSUES", schema = "CUR")
@NoArgsConstructor
@AllArgsConstructor
public class CurJiraIssue {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "project_key", nullable = false)
  private String projectKey;

  @Column(name = "issue_key", nullable = false)
  private String issueKey;

  @Column(name = "issue_type_name", nullable = false)
  private String issueTypeName;

  @Column(name = "assignee_email")
  private String assigneeEmail;

  @Column(name = "assignee_name")
  private String assigneeName;

  @Column(name = "issue_partner")
  private String issuePartner;

  @Column(name = "status_name", nullable = false)
  private String statusName;

  @Column(name = "status_id", nullable = false)
  private Long statusId;

  @Column(name = "issue_created", nullable = false, updatable = false)
  private LocalDateTime issueCreated;

  private LocalDate processDate;

  @Column(length = 10)
  private Integer cellId;
  @Column(length = 10)
  private Integer tribeId;

  @Column(length = 150)
  private String cellName;
  @Column(length = 150)
  private String tribeName;
}
