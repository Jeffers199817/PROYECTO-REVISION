package com.pichincha.sp.cycle.time.metric.tasklet.raw;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.repository.JiraRepository;
import com.pichincha.sp.cycle.time.metric.repository.dto.JiraProjectResponse;
import com.pichincha.sp.cycle.time.metric.repository.dto.JiraProjectResponse.Project.User;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraProject;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class InsertProjectJiraTasklet implements Tasklet {

  private final JiraRepository jiraRepository;
  private final RawJiraProjectRepository repository;
  private final CurDataFilterRepository dataFilterRepository;

  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution, @NonNull ChunkContext chunkContext) {

    log.info("Starting InsertProjectJiraTasklet");

    int startAt = 0;
    int maxResults = 50;
    boolean isLast = false;

    repository.truncateTable();

    List<DataFilter> filters = dataFilterRepository.findByStageAndTasklet(
        "RAW",
        InsertProjectJiraTasklet.class.getSimpleName());

    while (!isLast) {
      JiraProjectResponse response = jiraRepository.getProjects(startAt, maxResults,
          "pp-staff.cell_id,pp-staff.tribe_id", "description,url");

      if (response != null && response.getValues() != null) {

        log.info("processing projects = {}", response.getValues().size());
        List<JiraProject> projects = response.getValues().stream()
            .map(InsertProjectJiraTasklet::mapToJiraProject)
            .filter(project -> FiltersUtils.evaluateFilters(project, filters))
            .toList();

        if (!projects.isEmpty()) {
          repository.saveAllAndFlush(projects);
        }
        startAt += maxResults;

        isLast = response.getIsLast();

      } else {
        break;
      }
    }

    log.info("finish InsertProjectJiraTasklet");

    return RepeatStatus.FINISHED;
  }

  private static JiraProject mapToJiraProject(JiraProjectResponse.Project project) {
    JiraProject jiraProject = new JiraProject();

    jiraProject.setDescription(project.getDescription().substring(0, Math.min(project.getDescription().length(), 500)));
    jiraProject.setIsPrivate(project.getIsPrivate());
    jiraProject.setName(project.getName());
    jiraProject.setProjectKey(project.getKey());
    jiraProject.setProjectId(project.getId());

    if (Objects.nonNull(project.getProjectCategory())) {
      jiraProject.setProjectCategoryId(project.getProjectCategory().getId());
      jiraProject.setProjectCategoryName(project.getProjectCategory().getName());
    }

    if (!project.getProperties().isEmpty()) {
      jiraProject.setCellId(project.getProperties().get("pp-staff.cell_id"));
      jiraProject.setTribeId(project.getProperties().get("pp-staff.tribe_id"));
    }

    jiraProject.setCreatedAt(LocalDateTime.now());
    jiraProject.setProcessDate(LocalDate.now());

    jiraProject.setDeleted(project.getDeleted());
    jiraProject.setDeletedBy(Optional.ofNullable(project.getDeletedBy()).orElse(User.builder()
        .build()).getDisplayName());

    if (project.getDeletedDate() != null) {
      jiraProject.setDeletedDate(LocalDateTime.parse(project.getDeletedDate()));
    }

    jiraProject.setArchived(project.getArchived());
    jiraProject.setArchivedBy(Optional.ofNullable(project.getArchivedBy()).orElse(User.builder()
        .build()).getDisplayName());

    if (project.getArchivedDate() != null) {
      jiraProject.setArchivedDate(LocalDateTime.parse(project.getArchivedDate()));
    }

    jiraProject.setStyle(project.getStyle());


    return jiraProject;
  }
}