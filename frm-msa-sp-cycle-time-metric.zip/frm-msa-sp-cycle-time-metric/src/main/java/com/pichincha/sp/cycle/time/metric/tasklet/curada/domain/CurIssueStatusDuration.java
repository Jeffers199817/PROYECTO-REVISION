package com.pichincha.sp.cycle.time.metric.tasklet.curada.domain;

import javax.annotation.processing.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Getter
@Setter
@Builder(toBuilder = true)
@Entity
@Table(name = "JIRA_ISSUE_STATUS_DURATION", schema = "CUR",
    indexes = {@Index(name = "IDX_PROJECT_KEY", columnList = "project_key")}) // Índice en projectKey
@NoArgsConstructor
@AllArgsConstructor
public class CurIssueStatusDuration {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "issue_key", nullable = false)
  private String issueKey;

  @Column(name = "project_key", nullable = false)
  private String projectKey;

  private LocalDate endDate;

  private LocalDate processDate;

  @Column(name = "status_durations", nullable = false, columnDefinition = "NVARCHAR(MAX)")
  private String statusDurations;
}
