package com.pichincha.sp.cycle.time.metric.tasklet.master;

import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimDate;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimProject;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimAssignee;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimIssueType;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimDateRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimProjectRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimAssigneeRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimIssueTypeRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.MasterCycleTimeRepository;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class PopulateDimensionsTasklet implements Tasklet {

  private final MasterCycleTimeRepository masterCycleTimeRepository;
  private final DimDateRepository dimDateRepository;
  private final DimProjectRepository dimProjectRepository;
  private final DimAssigneeRepository dimAssigneeRepository;
  private final DimIssueTypeRepository dimIssueTypeRepository;

  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution,
    @NonNull ChunkContext chunkContext) throws Exception {

    log.info("Starting PopulateDimensionsTasklet");

    truncateTables();
    populateDimDate();
    populateDimProject();
    populateDimAssignee();
    populateDimIssueType();

    log.info("Finished PopulateDimensionsTasklet");

    return RepeatStatus.FINISHED;
  }

  private void truncateTables() {
    dimDateRepository.truncateTable();
    dimProjectRepository.truncateTable();
    dimAssigneeRepository.truncateTable();
    dimIssueTypeRepository.truncateTable();
  }

  private void populateDimDate() {
    Set<DimDate> dimDates = masterCycleTimeRepository.findAll()
      .stream()
      .map(data -> DimDate.builder()
        .year(data.getYear())
        .month(data.getMonth())
        .build()
      ).collect(Collectors.toSet());

    dimDateRepository.saveAllAndFlush(dimDates);
  }

  private void populateDimProject() {
    Set<DimProject> projects = masterCycleTimeRepository.findAll()
      .stream()
      .map(data ->
        DimProject.builder()
          .projectKey(data.getProjectKey())
          .cellName(data.getCellName())
          .cellId(data.getCellId())
          .tribeName(data.getTribeName())
          .tribeId(data.getTribeId())
          .build()
      ).collect(Collectors.toSet());

    dimProjectRepository.saveAllAndFlush(projects);
  }

  private void populateDimAssignee() {
    Set<DimAssignee> assignees = masterCycleTimeRepository.findAll()
      .stream()
      .map(data ->
        DimAssignee.builder().assigneeName(data.getAssigneeName()).build()
      ).collect(Collectors.toSet());

    dimAssigneeRepository.saveAllAndFlush(assignees);
  }

  private void populateDimIssueType() {
    Set<DimIssueType> issueTypes = masterCycleTimeRepository.findAll()
      .stream()
      .map(data ->
        DimIssueType.builder().issueTypeName(data.getIssueTypeName()).build()
      ).collect(Collectors.toSet());

    dimIssueTypeRepository.saveAllAndFlush(issueTypes);
  }
}
