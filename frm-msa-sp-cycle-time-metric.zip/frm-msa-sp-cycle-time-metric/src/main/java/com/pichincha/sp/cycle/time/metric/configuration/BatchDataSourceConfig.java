package com.pichincha.sp.cycle.time.metric.configuration;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.batch.BatchDataSource;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.jdbc.support.JdbcTransactionManager;

@Configuration
public class BatchDataSourceConfig {

  @Bean
  @Primary
  @ConfigurationProperties("spring.datasource.batch")
  public DataSourceProperties batchDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean(value = "dataSource")
  @Primary
  @BatchDataSource
  public DataSource batchDataSource() {
    var dataSource = batchDataSourceProperties()
        .initializeDataSourceBuilder()
        .build();

    initializeBatchSchema(dataSource);

    return dataSource;
  }


  @Bean
  @Primary
  public JdbcTemplate batchJdbcTemplate(@Qualifier("dataSource") DataSource dataSource) {
    return new JdbcTemplate(dataSource);
  }

  @Bean
  @Primary
  public JdbcTransactionManager transactionManager(DataSource dataSource) {
    return new JdbcTransactionManager(dataSource);
  }

  private static void initializeBatchSchema(DataSource dataSource) {
    JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

    String checkTableExistsQuery = "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'batch_job_instance'";
    Integer tableCount = jdbcTemplate.queryForObject(checkTableExistsQuery, Integer.class);

    if (tableCount == null || tableCount == 0) {
      ResourceDatabasePopulator populate = new ResourceDatabasePopulator();
      populate.addScript(
          new ClassPathResource("org/springframework/batch/core/schema-postgresql.sql"));
      DataSourceInitializer initializer = new DataSourceInitializer();
      initializer.setDataSource(dataSource);
      initializer.setDatabasePopulator(populate);
      initializer.afterPropertiesSet();
    }
  }

}