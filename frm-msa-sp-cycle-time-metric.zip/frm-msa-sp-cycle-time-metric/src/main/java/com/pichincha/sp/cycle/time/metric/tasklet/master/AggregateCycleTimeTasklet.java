package com.pichincha.sp.cycle.time.metric.tasklet.master;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pichincha.sp.cycle.time.metric.exception.CustomException;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurIssueStatusDuration;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurIssueStatusDurationRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.FactCycleTime;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.MasterCycleTimeRepository;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class AggregateCycleTimeTasklet implements Tasklet {

  private final CurIssueStatusDurationRepository statusDurationRepository;
  private final CurJiraIssueRepository issueRepository;
  private final MasterCycleTimeRepository masterCycleTimeRepository;
  private final ObjectMapper objectMapper = new ObjectMapper();

  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution,
    @NonNull ChunkContext chunkContext) {

    log.info("Starting AggregateCycleTimeTasklet");

    processData();

    log.info("Finished AggregateCycleTimeTasklet");

    return RepeatStatus.FINISHED;
  }

  private void processData() {
    LocalDate today = LocalDate.now();
    LocalDate firstDayOfMonth = today.withDayOfMonth(1);
    LocalDate lastDayOfMonth = today.withDayOfMonth(today.lengthOfMonth());

    List<CurIssueStatusDuration> durations = statusDurationRepository.findByEndDateBetween(
      firstDayOfMonth, lastDayOfMonth);

    List<FactCycleTime> masterDataList = durations.stream()
      .map(this::processDuration)
      .filter(Objects::nonNull)
      .toList();

    if (!masterDataList.isEmpty()) {
      processByMonth(masterDataList);
    }
  }

  private FactCycleTime processDuration(CurIssueStatusDuration duration) {
    CurJiraIssue issue = issueRepository.findByIssueKey(duration.getIssueKey());
    if (issue == null || issue.getIssueTypeName() == null) {
      return null;
    }

    LocalDate finalDate = duration.getEndDate() != null ? duration.getEndDate() : LocalDate.now();
    Map<String, Long> statusTimes = parseStatusDurations(duration);
    Long totalCycleTime = statusTimes.values().stream().mapToLong(Long::longValue).sum();
    int statusCount = statusTimes.size();

    return FactCycleTime.builder()
      .issueKey(issue.getIssueKey())
      .projectKey(issue.getProjectKey())
      .assigneeName(Optional.ofNullable(issue.getAssigneeName()).orElse("").toUpperCase())
      .issueTypeName(Optional.ofNullable(issue.getIssueTypeName()).orElse("").toUpperCase())
      .cycleTime(totalCycleTime)
      .statusCount(statusCount)
      .finalDate(finalDate)
      .year(finalDate.getYear())
      .month(finalDate.getMonthValue())
      .cellName(issue.getCellName())
      .cellId(issue.getCellId())
      .tribeId(issue.getTribeId())
      .tribeName(issue.getTribeName())
      .build();
  }

  private Map<String, Long> parseStatusDurations(CurIssueStatusDuration duration) {
    Map<String, Long> statusTimes = new HashMap<>();
    try {
      Map<String, Object> rawStatusTimes = objectMapper.readValue(duration.getStatusDurations(),
        objectMapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class));
      rawStatusTimes.forEach((key, value) -> {
        if (value instanceof Integer integerValue) {
          statusTimes.put(key, integerValue.longValue());
        } else if (value instanceof Long longValue) {
          statusTimes.put(key, longValue);
        } else {
          statusTimes.put(key, 0L);
        }
      });
    } catch (JsonProcessingException e) {
      throw new CustomException("Error parsing JSON for status durations", e);
    }
    return statusTimes;
  }

  private void processByMonth(List<FactCycleTime> data) {
    Map<YearMonth, List<FactCycleTime>> groupedByMonth = data.stream()
      .collect(Collectors.groupingBy(d -> YearMonth.from(d.getFinalDate())));

    YearMonth currentMonth = YearMonth.now();

    for (var entry : groupedByMonth.entrySet()) {
      YearMonth month = entry.getKey();
      List<FactCycleTime> records = entry.getValue();

      boolean monthExists = masterCycleTimeRepository.existsByYearAndMonth(
        month.getYear(),
        month.getMonthValue()
      );

      if (monthExists && !month.equals(currentMonth)) {
        continue;
      }

      if (monthExists) {
        var year = month.getYear();
        var monthValue =  month.getMonthValue();
        masterCycleTimeRepository.deleteByYearAndMonth(year, monthValue);
      }

      List<FactCycleTime> filteredRecords = filterByPercentiles(records);
      masterCycleTimeRepository.saveAllAndFlush(filteredRecords);
    }
  }

  private List<FactCycleTime> filterByPercentiles(List<FactCycleTime> data) {

    List<Long> cycleTimes = data.stream()
      .map(FactCycleTime::getCycleTime)
      .sorted()
      .toList();

    long p1 = getPercentile(cycleTimes, 1);
    long p99 = getPercentile(cycleTimes, 99);

    return data.stream()
      .filter(d -> d.getCycleTime() > p1 && d.getCycleTime() < p99)
      .toList();
  }

  private static long getPercentile(List<Long> sortedList, double percentile) {
    int index = (int) Math.ceil(percentile / 100.0 * sortedList.size()) - 1;
    return sortedList.get(Math.max(0, Math.min(index, sortedList.size() - 1)));
  }
}