package com.pichincha.sp.cycle.time.metric.configuration;

import feign.Logger;
import feign.Logger.Level;
import feign.RequestInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class JiraFeignConfig {

  private final ApplicationProperties applicationProperties;

  public JiraFeignConfig(ApplicationProperties applicationProperties) {
    this.applicationProperties = applicationProperties;
  }

  @Bean
  public RequestInterceptor basicAuthRequestInterceptor() {
    return requestTemplate -> {

      String auth =
        applicationProperties.jira().username() + ":" + applicationProperties.jira().password();

      String encodedAuth = java.util.Base64.getEncoder().encodeToString(auth.getBytes());
      requestTemplate.header("Authorization", "Basic " + encodedAuth);
    };
  }

  @Bean
  public Logger.Level feignLoggerLevel() {
    return Level.BASIC;
  }
}
