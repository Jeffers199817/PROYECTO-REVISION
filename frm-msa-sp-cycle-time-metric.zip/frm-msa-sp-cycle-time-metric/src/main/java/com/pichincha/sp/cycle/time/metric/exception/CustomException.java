package com.pichincha.sp.cycle.time.metric.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.Getter;

import javax.annotation.processing.Generated;

@Getter
@Generated("lombok")
public class CustomException extends RuntimeException {
  private final String exceptionMessage;

  public CustomException(String message, RuntimeException e) {
    super(message);
    this.exceptionMessage = e.getMessage();
  }

  public CustomException(String message, JsonProcessingException e) {
    super(message);
    this.exceptionMessage = e.getMessage();
  }

  public CustomException(String s, Exception e) {
    super(s);
    this.exceptionMessage = e.getMessage();
  }
}
