package com.pichincha.sp.cycle.time.metric.tasklet.curada.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.BmcCell;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface BmcCellRepository extends JpaRepository<BmcCell, Integer> {

    BmcCell findByIdCell(Integer idCell);

}
