package com.pichincha.sp.cycle.time.metric.tasklet.curada.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.BmcTribe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BmcTribeRepository extends JpaRepository<BmcTribe, Integer> {

    BmcTribe findByIdTribe(Integer idTribe);
}
