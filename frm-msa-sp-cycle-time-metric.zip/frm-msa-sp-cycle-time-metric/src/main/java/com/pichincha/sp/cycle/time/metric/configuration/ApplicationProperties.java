package com.pichincha.sp.cycle.time.metric.configuration;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

@ConfigurationProperties(prefix = "application")
public record ApplicationProperties(
    int startTimeRetry,
    String environment,
    String teamsWebhook,
    @DefaultValue("0 0 3 * * ?") String startTimeCron,
    boolean includePrivateProjects,
    JiraProperties jira,
    Threads threads
) {

  public record Threads(
    int insertJiraChangelog,
    int partitionInsertJiraChangelog
  ) {}

  public record JiraProperties(
      String url,
      String username,
      String password,
      Paths paths
  ) {

    public record Paths(
        String getProjects,
        String getIssuesByProject,
        String getChangelogByIssue
    ) {}
  }
}
