package com.pichincha.sp.cycle.time.metric;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Arquitectura tradicional para el recurso frm-msa-sp-cycle-time-metric extendiendo
 * de la interfaz generada.
<br/>
 * <b>Class</b>: PichinchaOptimusMainApplication<br/>
 * <b>Copyright</b>: &copy; 2024 Banco Pichincha<br/>
 *
 * @author Banco Pichincha <br/>
 * <u>Developed by</u>: <br/>
 * <ul>
*
<li>Cristhian Hernandez</li>
*
</ul>
 * <u>Changes</u>:<br/>
 * <ul>
*
<li>Nov 20, 2024 Creaci&oacute;n de Clase.</li>
*
</ul>
 * @version 1.0
 */
@SpringBootApplication
@EnableBatchProcessing
@EnableFeignClients
@EnableAsync
@EnableConfigurationProperties(ApplicationProperties.class)
public class OptimusMainApplication {

  public static void main(String[] args) {
    SpringApplication.run(OptimusMainApplication.class, args);
  }
}
