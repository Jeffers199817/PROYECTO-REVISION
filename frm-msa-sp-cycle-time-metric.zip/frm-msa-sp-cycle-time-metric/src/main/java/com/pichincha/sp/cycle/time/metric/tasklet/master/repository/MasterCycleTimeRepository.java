package com.pichincha.sp.cycle.time.metric.tasklet.master.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.FactCycleTime;
import jakarta.persistence.criteria.CriteriaBuilder.In;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MasterCycleTimeRepository extends JpaRepository<FactCycleTime, Long> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE MST.CYCLE_TIME_FACT", nativeQuery = true)
  void truncateTable();

  boolean existsByYearAndMonth(Integer year, Integer month);

  @Modifying
  @Transactional
  @Query(value = "DELETE FROM MST.CYCLE_TIME_FACT WHERE year = :year AND month = :month", nativeQuery = true)
  void deleteByYearAndMonth(Integer year, Integer month);

}
