package com.pichincha.sp.cycle.time.metric.util;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

@Slf4j
public class FiltersUtils {

  private static final ExpressionParser parser = new SpelExpressionParser();

  private FiltersUtils() {
    throw new IllegalStateException("Utility class");
  }

  public static boolean evaluateFilters(Object object, List<DataFilter> filters) {
    if (object == null || filters == null || filters.isEmpty()) {
      return true;
    }

    List<DataFilter> andFilters = filters.stream()
        .filter(f -> "AND".equalsIgnoreCase(f.getOperator()))
        .toList();

    List<DataFilter> orFilters = filters.stream()
        .filter(f -> "OR".equalsIgnoreCase(f.getOperator()))
        .toList();

    boolean andResult = andFilters.isEmpty() || andFilters.stream()
        .allMatch(filter -> getFieldValue(object, filter.getVariable())
            .map(value -> evaluateExpression(value, filter.getExpression()))
            .orElse(false));

    boolean orResult = !orFilters.isEmpty() && orFilters.stream()
        .anyMatch(filter -> getFieldValue(object, filter.getVariable())
            .map(value -> evaluateExpression(value, filter.getExpression()))
            .orElse(false));

    return andResult || orResult;
  }

  private static Optional<Object> getFieldValue(Object object, String propertyName) {
    if (propertyName == null || propertyName.isEmpty()) {
      return Optional.empty();
    }

    PropertyDescriptor descriptor = BeanUtils.getPropertyDescriptor(object.getClass(), propertyName);
    if (descriptor == null || descriptor.getReadMethod() == null) {
      log.warn("not found property '{}' in class '{}'", propertyName, object.getClass().getSimpleName());
      return Optional.empty();
    }

    try {
      return Optional.ofNullable(descriptor.getReadMethod().invoke(object));
    } catch (IllegalAccessException | InvocationTargetException e) {
      log.error("Property '{}' no accessible: {}", propertyName, e.getMessage());
      return Optional.empty();
    }
  }

  private static boolean evaluateExpression(Object value, String expression) {

    try {
      return Boolean.TRUE.equals(parser.parseExpression(expression).getValue(new StandardEvaluationContext(value), Boolean.class));
    } catch (Exception e) {
      log.error("Error evaluating SpEL expression '{}': {}", expression, e.getMessage());
      return false;
    }
  }

}
