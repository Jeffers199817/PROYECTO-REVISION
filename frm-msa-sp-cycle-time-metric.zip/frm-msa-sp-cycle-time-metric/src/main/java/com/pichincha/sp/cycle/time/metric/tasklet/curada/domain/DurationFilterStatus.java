package com.pichincha.sp.cycle.time.metric.tasklet.curada.domain;

import javax.annotation.processing.Generated;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Generated("lombok")
@Setter
@Getter
@Builder(toBuilder = true)
public class DurationFilterStatus {
  private String status;
}
