package com.pichincha.sp.cycle.time.metric.tasklet.master.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import javax.annotation.processing.Generated;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "CYCLE_TIME_DIM_PROJECT", schema = "MST")
public class DimProject {

  @Id
  @Column(name = "project_key", nullable = false, unique = true)
  private String projectKey;

  @Column(name = "tribe_name")
  private String tribeName;

  @Column(name = "cell_name")
  private String cellName;

  @Column(name = "cell_id")
  private Integer cellId;

  @Column(name = "tribe_id")
  private Integer tribeId;
}
