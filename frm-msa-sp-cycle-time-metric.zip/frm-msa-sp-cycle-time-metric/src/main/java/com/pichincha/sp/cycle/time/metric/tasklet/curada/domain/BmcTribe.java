package com.pichincha.sp.cycle.time.metric.tasklet.curada.domain;

import javax.annotation.processing.Generated;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "BMC_TRIBE", schema = "CUR")
public class BmcTribe {

    @Id
    @Column(name = "ID_TRIBE", nullable = false)
    private Integer idTribe;

    @Column(name = "STATE", nullable = false, length = 8)
    private String state;

    @Column(name = "USER_AUDIT", length = 8)
    private String userAudit;

    @Column(name = "FINISH_DATE", length = 4)
    private String finishDate;

    @Column(name = "TRIBE_NAME", nullable = false, length = 76)
    private String tribeName;

    @Column(name = "DESCRIPTION", length = 124)
    private String description;

    @Column(name = "TYPE", length = 8)
    private String type;

    @Column(name = "CREATION_DATE_TRIBE", length = 26)
    private String creationDateTribe;

    @Column(name = "CREATION_DATE")
    private LocalDateTime creationDate;

    @Column(name = "MODIFICATION_DATE")
    private LocalDateTime modificationDate;

    @Column(name = "TAGS", length = 96)
    private String tags;

}
