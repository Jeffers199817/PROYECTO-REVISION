package com.pichincha.sp.cycle.time.metric.configuration;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.FilterJiraChangelogTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.FilterJiraIssueTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.FilterJiraProjectTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.DurationIssueStatusTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.master.AggregateCycleTimeTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.master.PopulateDimensionsTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.InsertChangelogTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.InsertJiraIssuesTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.InsertProjectJiraTasklet;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@RequiredArgsConstructor
public class BatchJobConfig {

  private final JobRepository jobRepository;
  private final PlatformTransactionManager transactionManager;
  private final JobExecutionListener jobExecutionListener;
  private final InsertProjectJiraTasklet insertProjectJiraTasklet;
  private final InsertJiraIssuesTasklet insertJiraIssuesTasklet;
  private final InsertChangelogTasklet insertChangelogTasklet;
  private final DurationIssueStatusTasklet durationIssueStatusTasklet;
  private final FilterJiraProjectTasklet filterJiraProjectTasklet;
  private final FilterJiraIssueTasklet filterJiraIssueTasklet;
  private final FilterJiraChangelogTasklet filterJiraChangelogTasklet;
  private final AggregateCycleTimeTasklet aggregateCycleTimeTasklet;
  private final PopulateDimensionsTasklet populateDimensionsTasklet;

  @Bean
  public Job batchJob(
    Step stepRawInsertProjectJira,
    Step stepRawInsertIssuesJira,
    Step stepRawInsertChangelogJira,
    Step stepCurFilterProjectJira,
    Step stepCurFilterIssueJira,
    Step stepCurFilterChangelogJira,
    Step stepCurDurationIssueStatus,
    Step stepMstAggregateCycleTime,
    Step stepMstPopulateDimsCycleTime
  ) {
    return new JobBuilder("batchJob", jobRepository)
      .listener(jobExecutionListener)
      .start(stepRawInsertProjectJira)
      .next(stepRawInsertIssuesJira)
      .next(stepRawInsertChangelogJira)
      .next(stepCurFilterProjectJira)
      .next(stepCurFilterIssueJira)
      .next(stepCurFilterChangelogJira)
      .next(stepCurDurationIssueStatus)
      .next(stepMstAggregateCycleTime)
      .next(stepMstPopulateDimsCycleTime)
      .build();
  }

  @Bean
  public Job batchJobRaw(Step stepRawInsertProjectJira,
    Step stepRawInsertIssuesJira,
    Step stepRawInsertChangelogJira) {
    return new JobBuilder("batchJobRaw", jobRepository)
      .listener(jobExecutionListener)
      .start(stepRawInsertProjectJira)
      .next(stepRawInsertIssuesJira)
      .next(stepRawInsertChangelogJira)
      .build();
  }

  @Bean
  public Job batchJobCurada(Step stepCurFilterProjectJira,
    Step stepCurFilterIssueJira,
    Step stepCurFilterChangelogJira,
    Step stepCurDurationIssueStatus) {
    return new JobBuilder("batchJobCurada", jobRepository)
      .listener(jobExecutionListener)
      .start(stepCurFilterProjectJira)
      .next(stepCurFilterIssueJira)
      .next(stepCurFilterChangelogJira)
      .next(stepCurDurationIssueStatus)
      .build();
  }

  @Bean
  public Job batchJobMaster(Step stepMstAggregateCycleTime,
    Step stepMstPopulateDimsCycleTime) {
    return new JobBuilder("batchJobMaster", jobRepository)
      .listener(jobExecutionListener)
      .start(stepMstAggregateCycleTime)
      .next(stepMstPopulateDimsCycleTime)
      .build();
  }

  @Bean
  public Step stepRawInsertProjectJira() {
    return new StepBuilder("getJiraProjects", jobRepository)
      .tasklet(insertProjectJiraTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepRawInsertIssuesJira() {
    return new StepBuilder("getJiraIssues", jobRepository)
      .tasklet(insertJiraIssuesTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepRawInsertChangelogJira() {
    return new StepBuilder("getJiraChangelog", jobRepository)
      .tasklet(insertChangelogTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepCurFilterProjectJira() {
    return new StepBuilder("filterProjectJira", jobRepository)
      .tasklet(filterJiraProjectTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepCurFilterIssueJira() {
    return new StepBuilder("filterIssueJira", jobRepository)
      .tasklet(filterJiraIssueTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepCurFilterChangelogJira() {
    return new StepBuilder("filterChangelogJira", jobRepository)
      .tasklet(filterJiraChangelogTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepCurDurationIssueStatus() {
    return new StepBuilder("durationIssueStatus", jobRepository)
      .tasklet(durationIssueStatusTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepMstAggregateCycleTime() {
    return new StepBuilder("aggregateCycleTime", jobRepository)
      .tasklet(aggregateCycleTimeTasklet, transactionManager)
      .build();
  }

  @Bean
  public Step stepMstPopulateDimsCycleTime() {
    return new StepBuilder("populateDimsCycleTime", jobRepository)
      .tasklet(populateDimensionsTasklet, transactionManager)
      .build();
  }


}