package com.pichincha.sp.cycle.time.metric.tasklet.master.domain;

import jakarta.persistence.*;
import javax.annotation.processing.Generated;
import lombok.*;

import java.time.LocalDate;

@Generated("lombok")
@Getter
@Setter
@Builder(toBuilder = true)
@Entity
@Table(name = "CYCLE_TIME_FACT", schema = "MST",
    indexes = {
        @Index(name = "IDX_PROJECT_KEY", columnList = "project_key"),
        @Index(name = "IDX_FINAL_DATE", columnList = "final_date"),
        @Index(name = "IDX_ASSIGNEE_NAME", columnList = "assignee_name"),
        @Index(name = "IDX_ISSUE_TYPE_NAME", columnList = "issue_type_name")
    })
@NoArgsConstructor
@AllArgsConstructor
public class FactCycleTime {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "issue_key", nullable = false)
  private String issueKey;

  @Column(name = "project_key", nullable = false)
  private String projectKey;

  @Column(name = "assignee_name")
  private String assigneeName;

  @Column(name = "cell_name")
  private String cellName;

  @Column(name = "cell_id")
  private Integer cellId;

  @Column(name = "tribe_name")
  private String tribeName;

  @Column(name =  "tribe_id")
  private Integer tribeId;

  @Column(name = "cycle_time", nullable = false)
  private Long cycleTime;

  @Column(name = "status_count", nullable = false)
  private Integer statusCount;

  @Column(name = "final_date", nullable = false)
  private LocalDate finalDate;

  @Column(name = "year", nullable = false)
  private Integer year;

  @Column(name = "month", nullable = false)
  private Integer month;

  @Column(name = "issue_type_name", nullable = false)
  private String issueTypeName;
}