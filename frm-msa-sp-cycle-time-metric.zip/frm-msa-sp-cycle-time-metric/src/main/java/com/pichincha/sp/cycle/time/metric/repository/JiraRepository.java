package com.pichincha.sp.cycle.time.metric.repository;

import com.pichincha.sp.cycle.time.metric.configuration.JiraFeignConfig;
import com.pichincha.sp.cycle.time.metric.repository.dto.ChangelogResponse;
import com.pichincha.sp.cycle.time.metric.repository.dto.IssueResponse;
import com.pichincha.sp.cycle.time.metric.repository.dto.JiraProjectResponse;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@Repository
@FeignClient(name = "jiraRepository", url = "${application.jira.url}", configuration = JiraFeignConfig.class)
public interface JiraRepository {

  @GetMapping("/rest/api/3/project/search")
  JiraProjectResponse getProjects(
      @RequestParam("startAt") int startAt,
      @RequestParam("maxResults") int maxResults,
      @RequestParam("properties") String properties,
      @RequestParam("expand") String expand
  );

  @GetMapping("/rest/api/3/search")
  IssueResponse getIssues(@RequestParam("jql") String jql,
      @RequestParam("startAt") int startAt,
      @RequestParam("maxResults") int maxResults,
      @RequestParam("fields") String fields);

  @GetMapping("/rest/api/3/issue/{issueKey}/changelog")
  ChangelogResponse getChangelog(@PathVariable("issueKey") String issueKey,
      @RequestParam("startAt") int startAt,
      @RequestParam("maxResults") int maxResults);

  @GetMapping("${application.jira.paths.get-properties-by-project}")
  Map<String, Object> getPropertiesByProject(@RequestParam Map<String, String> params);


}
