package com.pichincha.sp.cycle.time.metric.tasklet.curada;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraChangelog;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraChangelog;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class FilterJiraChangelogTasklet implements Tasklet {

  private final CurJiraIssueRepository curIssueRepository;
  private final CurJiraChangelogRepository curChangelogRepository;
  private final RawJiraChangelogRepository rawChangelogRepository;
  private final CurDataFilterRepository dataFilterRepository;


  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution,
    @NonNull ChunkContext chunkContext) {

    log.info("Starting FilterJiraChangelogTasklet");

    int offset = 0;
    int batchSize = 500;

    List<DataFilter> filters = dataFilterRepository.findByStageAndTasklet(
      "CUR",
      FilterJiraChangelogTasklet.class.getSimpleName());

    List<String> issueKeys = curIssueRepository.findIssueKeysAndProcessDateNow(offset, batchSize,
      LocalDate.now());

    while (!issueKeys.isEmpty()) {

      List<List<String>> batches = partitionList(issueKeys, 75);
      batches.forEach(batch -> {
        ExecutorService executor = Executors.newFixedThreadPool(75);
        List<CompletableFuture<Void>> futures = batch.stream()
          .map(
            issueKey -> CompletableFuture.runAsync(() -> processIssue(issueKey, filters), executor))
          .toList();

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        executor.shutdown();
      });

      offset += batchSize;
      issueKeys = curIssueRepository.findIssueKeysAndProcessDateNow(offset, batchSize,
        LocalDate.now());
    }

    log.info("Finished FilterJiraChangelogTasklet");

    return RepeatStatus.FINISHED;
  }

  private void processIssue(String issueKey, List<DataFilter> filters) {
    List<CurJiraChangelog> curJiraChanges = rawChangelogRepository.findByIssueKey(issueKey)
      .stream().map(this::mapToCurJiraChangelog)
      .filter(curJiraChangelog -> FiltersUtils.evaluateFilters(curJiraChangelog, filters))
      .toList();

    if (!curJiraChanges.isEmpty()) {
      curChangelogRepository.saveAllAndFlush(curJiraChanges);
    }
  }

  private CurJiraChangelog mapToCurJiraChangelog(JiraChangelog changelog) {
    if (changelog == null) {
      return null;
    }

    CurJiraChangelog data = this.curChangelogRepository.findByChangelogId(
      changelog.getChangelogId());

    CurJiraChangelog curJiraChangelog = new CurJiraChangelog();

    if (data != null) {
      curJiraChangelog = data;
    }

    return curJiraChangelog.toBuilder()
      .changelogId(changelog.getChangelogId())
      .issueKey(changelog.getIssueKey())
      .authorEmail(changelog.getAuthorEmail())
      .authorName(changelog.getAuthorName().toUpperCase())
      .changelogCreated(changelog.getChangelogCreated())
      .itemField(changelog.getItemField().toUpperCase())
      .itemFromString(changelog.getItemFromString().toUpperCase())
      .itemToString(changelog.getItemToString().toUpperCase())
      .build();
  }


  private static <T> List<List<T>> partitionList(List<T> list, int size) {
    List<List<T>> partitions = new ArrayList<>();
    for (int i = 0; i < list.size(); i += size) {
      partitions.add(list.subList(i, Math.min(i + size, list.size())));
    }
    return partitions;
  }
}