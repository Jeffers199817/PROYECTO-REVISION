package com.pichincha.sp.cycle.time.metric.repository.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import javax.annotation.processing.Generated;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChangelogResponse {

  private int startAt;
  private int maxResults;
  private int total;
  private Boolean isLast;
  private List<Changelog> values;

  @Generated("lombok")
  @Setter
  @Getter
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Changelog {
    private String id;

    @JsonProperty("author")
    private Author author;

    private String created;

    @JsonProperty("items")
    private List<Item> items;

    @Generated("lombok")
    @Setter
    @Getter
    @AllArgsConstructor
    @Builder(toBuilder = true)
    @NoArgsConstructor
    public static class Author {
      private String emailAddress;
      private String displayName;
      private boolean active;
    }

    @Generated("lombok")
    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Item {
      private String field;

      @JsonProperty("fieldtype")
      private String fieldType;
      private String fieldId;
      private String from;
      private String fromString;
      private String to;
      private String toString;
    }
  }
}