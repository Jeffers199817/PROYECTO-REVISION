package com.pichincha.sp.cycle.time.metric.tasklet.curada.domain;

import jakarta.persistence.criteria.CriteriaBuilder.In;
import javax.annotation.processing.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Generated("lombok")
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "\"JIRA_PROJECTS\"", schema = "CUR")
@AllArgsConstructor
public class CurJiraProject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 500)
    private String description;


    @Column(length = 100)
    private String name;

    @Column(length = 10)
    private String projectKey;

    @Column(length = 10)
    private String projectId;

    @Column(length = 20)
    private String projectType;

    @Column(length = 10)
    private String projectCategoryId;
    @Column(length = 100)
    private String projectCategoryName;
    private LocalDateTime createdAt;
    private LocalDate processDate;

    @Column(length = 10)
    private Integer cellId;
    @Column(length = 10)
    private Integer tribeId;

    @Column(length = 150)
    private String cellName;
    @Column(length = 150)
    private String tribeName;


}
