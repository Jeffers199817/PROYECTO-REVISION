package com.pichincha.sp.cycle.time.metric.tasklet.raw.repository;

import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraChangelog;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RawJiraChangelogRepository extends JpaRepository<JiraChangelog, Integer> {

  @Modifying
  @Transactional
  @Query(value = "TRUNCATE TABLE RAW.JIRA_CHANGELOG", nativeQuery = true)
  void truncateTable();

  List<JiraChangelog> findByIssueKey(String issueKey);

}


