package com.pichincha.sp.cycle.time.metric.repository.dto;


import javax.annotation.processing.Generated;
import java.io.Serial;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Generated("lombok")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class JiraProjectResponse implements Serializable {

  @Serial
  private static final long serialVersionUID = -4609972005675544715L;
  private int startAt;
  private int maxResults;
  private int total;
  private Boolean isLast;
  private List<Project> values;

  @Data
  @Getter
  @Setter
  @AllArgsConstructor
  @NoArgsConstructor
  @ToString
  public static class Project implements Serializable {

    @Serial
    private static final long serialVersionUID = 1588533307563039948L;
    private String id;
    private String key;
    private String name;
    private String description;
    private Boolean isPrivate;
    private String projectTypeKey;
    private ProjectCategory projectCategory;

    private Boolean archived;
    private User archivedBy;
    private String archivedDate;

    private Boolean deleted;
    private User deletedBy;
    private String deletedDate;

    private String style;

    private Map<String, String> properties;

    @Generated("lombok")
    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder(toBuilder = true)
    public static class User implements Serializable {

      @Serial
      private static final long serialVersionUID = -7923634706212971731L;
      private String accountId;
      private String displayName;
    }


    @Generated("lombok")
    @Setter
    @Getter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ProjectCategory implements Serializable {

      @Serial
      private static final long serialVersionUID = 2023347012191123354L;
      private String id;
      private String name;
    }
  }

}
