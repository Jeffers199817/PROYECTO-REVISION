package com.pichincha.sp.cycle.time.metric.tasklet.raw.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import javax.annotation.processing.Generated;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Generated("lombok")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "JIRA_CHANGELOG", schema = "RAW")
public class JiraChangelog {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;


  @Column(name = "author_active")
  private Boolean authorActive;


  @Column(name = "item_field_type")
  private String itemFieldType;

  @Column(name = "item_field_id")
  private String itemFieldId;

  @Column(name = "item_from")
  private String itemFrom;

  @Column(name = "item_to")
  private String itemTo;

  @Column(name = "changelog_id", nullable = false)
  private Long changelogId;

  @Column(name = "issue_key", nullable = false)
  private String issueKey;

  @Column(name = "author_email")
  private String authorEmail;

  @Column(name = "author_name")
  private String authorName;

  @Column(name = "changelog_created", nullable = false, updatable = false)
  private LocalDateTime changelogCreated;

  @Column(name = "item_field")
  private String itemField;

  @Column(name = "item_from_string")
  private String itemFromString;

  @Column(name = "item_to_string")
  private String itemToString;

}
