package com.pichincha.sp.cycle.time.metric.configuration;

import com.pichincha.sp.cycle.time.metric.exception.CustomException;
import jakarta.persistence.EntityManagerFactory;
import java.util.Map;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Slf4j
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    basePackages = {
        "com.pichincha.sp.cycle.time.metric.tasklet.raw.repository",
        "com.pichincha.sp.cycle.time.metric.tasklet.curada.repository",
        "com.pichincha.sp.cycle.time.metric.tasklet.master.repository"
    },
    entityManagerFactoryRef = "businessEntityManagerFactory",
    transactionManagerRef = "businessTransactionManager"
)
public class BusinessDbConfig {

  @Bean
  @ConfigurationProperties("spring.datasource.business")
  public DataSourceProperties businessDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean
  public DataSource businessDataSource() {
    var datasource = businessDataSourceProperties()
        .initializeDataSourceBuilder()
        .build();

    initializeSchema(datasource);
    return datasource;
  }


  @Bean
  public JdbcTemplate businessJdbcTemplate(@Qualifier("businessDataSource") DataSource dataSource) {
    return new JdbcTemplate(dataSource);
  }


  @Bean(name = "businessEntityManagerFactory")
  public LocalContainerEntityManagerFactoryBean businessEntityManagerFactory(
      @Qualifier("businessDataSource") DataSource dataSource,
      EntityManagerFactoryBuilder builder) {
    return builder
        .dataSource(dataSource)
        .packages("com.pichincha.sp.cycle.time.metric.tasklet") // Cambia según tus entidades
        .persistenceUnit("businessPU")
        .build();
  }

  @Bean(name = "businessTransactionManager")
  public JpaTransactionManager businessTransactionManager(
      @Qualifier("businessEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
    return new JpaTransactionManager(entityManagerFactory);
  }

  private void initializeSchema(DataSource dataSource) {
    JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

    // Mapear cada script con la tabla que crea
    Map<String, String> scriptToTableMap = Map.of(
        "db/migration/v0001__create_tables_jira_project.sql", "RAW.JIRA_PROJECTS",
        "db/migration/v0002__create_tables_jira_issue.sql", "RAW.JIRA_ISSUES",
        "db/migration/v0003__create_tables_jira_changelog.sql", "RAW.JIRA_CHANGELOG",
        "db/migration/v0004__create_tables_cur_filter_data.sql", "CUR.DATA_FILTER",
        "db/migration/V0005__create_tables_cur_issues_status_duration.sql", "CUR.JIRA_ISSUE_STATUS_DURATION",
        "db/migration/V0006__create_tables_mst_cycle_time.sql", "MST.CYCLE_TIME_FACT",
        "db/migration/V0007__create_tables_mst_dims.sql", "MST.CYCLE_TIME_DIM_DATE"
    );

    scriptToTableMap.forEach((scriptPath, tableName) -> {

      var table = tableName.split("\\.")[1];
      var schema = tableName.split("\\.")[0];

      String checkTableExistsQuery = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?";
      @SuppressWarnings("deprecation") Integer tableCount = jdbcTemplate.queryForObject(checkTableExistsQuery, new Object[]{schema, table}, Integer.class);

      if (tableCount == null || tableCount == 0) {
        // Si la tabla no existe, ejecutar el script
        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        populator.addScript(new ClassPathResource(scriptPath));
        DataSourceInitializer initializer = new DataSourceInitializer();
        initializer.setDataSource(dataSource);
        initializer.setDatabasePopulator(populator);
        try {
          initializer.afterPropertiesSet();
          log.info("Tabla creada: {}", tableName);
        } catch (Exception e) {
          throw new CustomException("Error al ejecutar el script: " + scriptPath, e);
        }
      } else {
        log.info("La tabla ya existe: {}. Script no ejecutado: {}", tableName, scriptPath);
      }
    });
  }
}