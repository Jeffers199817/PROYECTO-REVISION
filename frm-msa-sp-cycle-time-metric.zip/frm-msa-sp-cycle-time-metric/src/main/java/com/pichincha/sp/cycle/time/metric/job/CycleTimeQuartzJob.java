package com.pichincha.sp.cycle.time.metric.job;


import static com.pichincha.sp.cycle.time.metric.util.ConstantsUtils.JOB_EXECUTION_ID;
import static com.pichincha.sp.cycle.time.metric.util.ConstantsUtils.RETRY_COUNT;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import java.util.Date;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class CycleTimeQuartzJob implements Job {

  private static final int MAX_RETRIES = 3;

  private final JobLauncher jobLauncher;
  private final  org.springframework.batch.core.Job batchJob;
  private final JdbcTemplate jdbcTemplate;
  private final ApplicationProperties applicationProperties;

  @Override
  public void execute(JobExecutionContext context) throws JobExecutionException {
    try {

      Long jobExecutionId = context.getMergedJobDataMap().containsKey(JOB_EXECUTION_ID)
          ? context.getMergedJobDataMap().getLong(JOB_EXECUTION_ID)
          : null;

      int retryCount = context.getMergedJobDataMap().containsKey(RETRY_COUNT)
          ? context.getMergedJobDataMap().getIntValue(RETRY_COUNT)
          : 0;

      JobParametersBuilder jobParametersBuilder = new JobParametersBuilder()
          .addLong("time", System.currentTimeMillis());

      getFailedStep(jobExecutionId)
          .ifPresent(step -> jobParametersBuilder.addString("startStep", step));

      JobParameters jobParameters = jobParametersBuilder.toJobParameters();

      JobExecution jobExecution = jobLauncher.run(batchJob, jobParameters);

      if (jobExecution.getStatus() == BatchStatus.FAILED) {
        registerFailureAndRetry(context, jobExecution.getId(), retryCount + 1);
      }
    } catch (Exception e) {
      registerFailureAndRetry(context, null, 0);
    }
  }

  private void registerFailureAndRetry(JobExecutionContext context,
      Long jobExecutionId, int retryCount) {

    if (retryCount >= MAX_RETRIES) {
      log.error("Max retries reached, aborting job");
      return;
    }

    try {
      JobDetail jobDetail = context.getJobDetail();

      jobDetail.getJobDataMap().put(JOB_EXECUTION_ID, jobExecutionId);
      jobDetail.getJobDataMap().put(RETRY_COUNT, retryCount);

      Trigger retryTrigger = TriggerBuilder.newTrigger()
          .forJob(jobDetail)
          .usingJobData(jobDetail.getJobDataMap())
          .withIdentity("retryTrigger-" + System.currentTimeMillis())
          .startAt(new Date(System.currentTimeMillis() +
              (long) applicationProperties.startTimeRetry() * 60 * 1000 * 60))
          .build();

      context.getScheduler().scheduleJob(retryTrigger);
    } catch (SchedulerException ex) {
      log.error("Error programing retry job: {}", ex.getMessage());
    }
  }

  private Optional<String> getFailedStep(Long jobExecutionId) {

    if (jobExecutionId == null) {
      return Optional.empty();
    }

    String sql = """
          SELECT STEP_NAME
          FROM BATCH_STEP_EXECUTION
          WHERE JOB_EXECUTION_ID = ?
          AND STATUS = 'FAILED'
          ORDER BY START_TIME DESC
          LIMIT 1
      """;

    try {
      String data = jdbcTemplate.queryForObject(sql,
          (rs, rowNum) -> rs.getString("STEP_NAME"), jobExecutionId);
      return Optional.ofNullable(data);
    } catch (Exception e) {
      return Optional.empty();
    }
  }
}