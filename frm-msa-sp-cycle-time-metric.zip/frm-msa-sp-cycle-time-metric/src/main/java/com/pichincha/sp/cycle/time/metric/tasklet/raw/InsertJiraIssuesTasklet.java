package com.pichincha.sp.cycle.time.metric.tasklet.raw;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.repository.JiraRepository;
import com.pichincha.sp.cycle.time.metric.repository.dto.IssueResponse;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraProject;
import com.pichincha.sp.cycle.time.metric.util.ConvertUtils;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class InsertJiraIssuesTasklet implements Tasklet {

  private final JiraRepository jiraRepository;
  private final RawJiraIssueRepository issueRepository;
  private final RawJiraProjectRepository projectRepository;
  private final CurDataFilterRepository dataFilterRepository;

  @Override
  public RepeatStatus execute(@NonNull StepContribution contribution, @NonNull ChunkContext chunkContext) {

    log.info("Starting InsertJiraIssuesTasklet");

    List<JiraProject> projectKeys = projectRepository.findAll();

    List<DataFilter> filters = dataFilterRepository.findByStageAndTasklet(
        "RAW",
        InsertJiraIssuesTasklet.class.getSimpleName());

    issueRepository.truncateTable();

    ExecutorService executor = Executors.newFixedThreadPool(50);
    CompletableFuture<?>[] futures = projectKeys.stream()
        .map(project -> CompletableFuture.runAsync(() ->
            fetchIssues(project.getProjectKey(), filters), executor)
        ).toArray(CompletableFuture[]::new);

    CompletableFuture.allOf(futures).join();
    executor.shutdown();


    log.info("Finished InsertJiraIssuesTasklet");

    return RepeatStatus.FINISHED;
  }

  private void fetchIssues(String projectKey, List<DataFilter> filters) {
    int startAt = 0;
    int maxResults = 100;
    boolean isLast;

    do {
      IssueResponse response = jiraRepository.getIssues(
          "project=\"" + projectKey + "\"",
          startAt,
          maxResults,
          "assignee,reporter,issuetype,customfield_10014,created,summary,status"
      );

      if (response != null && response.getIssues() != null) {
        List<JiraIssue> issues = response.getIssues().stream()
            .map(InsertJiraIssuesTasklet::mapToJiraIssue)
            .filter(issue -> FiltersUtils.evaluateFilters(issue, filters))
            .toList();

        issueRepository.saveAllAndFlush(issues);

        startAt += maxResults;
        isLast = (startAt >= response.getTotal());
      } else {
        isLast = true;
      }
    } while (!isLast);
  }

  private static JiraIssue mapToJiraIssue(IssueResponse.Issue issue) {
    JiraIssue jiraIssue = new JiraIssue();
    jiraIssue.setProjectKey(issue.getKey().split("-")[0]);
    jiraIssue.setIssueId(Long.parseLong(issue.getId()));
    jiraIssue.setIssueKey(issue.getKey());
    jiraIssue.setSummary(issue.getFields().getSummary());
    jiraIssue.setIssueTypeName(issue.getFields().getIssueType().getName().toUpperCase());
    jiraIssue.setIssueTypeSubtask(issue.getFields().getIssueType().isSubtask());
    jiraIssue.setIssueTypeId(issue.getFields().getIssueType().getId());

    if (issue.getFields().getReporter() != null) {
      jiraIssue.setReporterEmail(issue.getFields().getReporter().getEmailAddress());
      jiraIssue.setReporterName(issue.getFields().getReporter().getDisplayName().toUpperCase());
      jiraIssue.setReporterActive(issue.getFields().getReporter().isActive());
    }

    if (issue.getFields().getAssignee() != null) {
      jiraIssue.setAssigneeEmail(issue.getFields().getAssignee().getEmailAddress());
      jiraIssue.setAssigneeName(Optional.ofNullable(issue.getFields().getAssignee().getDisplayName()).orElse("").toUpperCase());
      jiraIssue.setAssigneeActive(issue.getFields().getAssignee().isActive());
    }

    jiraIssue.setIssuePartner(issue.getFields().getCustomField10014());
    jiraIssue.setStatusName(issue.getFields().getStatus().getName().toUpperCase());
    jiraIssue.setStatusId(issue.getFields().getStatus().getId());
    jiraIssue.setIssueCreated(ConvertUtils.convertToUTC(issue.getFields().getCreated()));

    return jiraIssue;
  }

}
