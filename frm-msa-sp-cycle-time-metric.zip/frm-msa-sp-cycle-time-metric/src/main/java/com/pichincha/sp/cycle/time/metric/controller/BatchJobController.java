package com.pichincha.sp.cycle.time.metric.controller;

import com.pichincha.sp.cycle.time.metric.service.BatchJobService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/batch")
@RequiredArgsConstructor
public class BatchJobController {

  private final BatchJobService batchJobService;

  @PostMapping("/execute")
  public ResponseEntity<String> executeJob(@RequestParam String stage) {
    log.info("Ejecutando Job: {}", stage);
    batchJobService.runJobAsync(stage);
    return ResponseEntity.ok("Ejecución del Job iniciada en segundo plano.");
  }

}