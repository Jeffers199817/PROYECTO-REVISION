
CREATE TABLE MST.CYCLE_TIME_DIM_DATE
(
    id    BIGINT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    year  INT                   NOT NULL,
    month INT                   NOT NULL,
    UNIQUE (year, month)
);


CREATE TABLE MST.CYCLE_TIME_DIM_PROJECT
(
    project_key VARCHAR(50) PRIMARY KEY,
    tribe_name  VARCHAR(100),
    cell_name   VARCHAR(100),
    cell_id INT,
    tribe_id INT
);


CREATE TABLE MST.CYCLE_TIME_DIM_ASSIGNEE
(
    id            BIGINT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    assignee_name VARCHAR(255) UNIQUE   NOT NULL
);


CREATE TABLE MST.CYCLE_TIME_DIM_ISSUE_TYPE
(
    id              BIGINT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    issue_type_name VARCHAR(255) UNIQUE   NOT NULL
);


CREATE INDEX idx_dim_date_year_month ON MST.CYCLE_TIME_DIM_DATE (year, month);
CREATE INDEX idx_dim_project_tribe ON MST.CYCLE_TIME_DIM_PROJECT (tribe_name);
CREATE INDEX idx_dim_assignee_name ON MST.CYCLE_TIME_DIM_ASSIGNEE (assignee_name);
CREATE INDEX idx_dim_issue_type_name ON MST.CYCLE_TIME_DIM_ISSUE_TYPE (issue_type_name);
