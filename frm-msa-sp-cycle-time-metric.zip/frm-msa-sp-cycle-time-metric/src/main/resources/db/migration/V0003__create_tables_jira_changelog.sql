CREATE TABLE RAW.JIRA_CHANGELOG (
                                id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                changelog_id BIGINT NOT NULL,
                                author_email VARCHAR(100),
                                author_name VARCHAR(200),
                                issue_key VARCHAR(50) NOT NULL,
                                author_active BIT,
                                changelog_created DATETIME NOT NULL,
                                item_field VARCHAR(100),
                                item_field_type VARCHAR(100),
                                item_field_id VARCHAR(100),
                                item_from TEXT,
                                item_from_string TEXT,
                                item_to TEXT,
                                item_to_string TEXT
);


CREATE TABLE CUR.JIRA_CHANGELOG (
                                    id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                    changelog_id BIGINT NOT NULL,
                                    author_email VARCHAR(100),
                                    author_name VARCHAR(200),
                                    issue_key VARCHAR(50) NOT NULL,
                                    changelog_created DATETIME NOT NULL,
                                    item_field VARCHAR(100),
                                    item_from_string TEXT,
                                    item_to_string TEXT
);


CREATE INDEX idx_raw_changelog_issue_key ON RAW.JIRA_CHANGELOG (issue_key);
CREATE INDEX idx_raw_changelog_id ON RAW.JIRA_CHANGELOG (changelog_id);
CREATE INDEX idx_raw_changelog_created ON RAW.JIRA_CHANGELOG (changelog_created);
CREATE INDEX idx_raw_changelog_author_email ON RAW.JIRA_CHANGELOG (author_email);
CREATE INDEX idx_raw_changelog_item_field ON RAW.JIRA_CHANGELOG (item_field);


CREATE INDEX idx_cur_changelog_issue_key ON CUR.JIRA_CHANGELOG (issue_key);
CREATE INDEX idx_cur_changelog_id ON CUR.JIRA_CHANGELOG (changelog_id);
CREATE INDEX idx_cur_changelog_created ON CUR.JIRA_CHANGELOG (changelog_created);
CREATE INDEX idx_cur_changelog_author_email ON CUR.JIRA_CHANGELOG (author_email);
CREATE INDEX idx_cur_changelog_item_field ON CUR.JIRA_CHANGELOG (item_field);
