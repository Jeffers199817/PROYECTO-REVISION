CREATE TABLE MST.CYCLE_TIME_FACT (
                                          id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                          issue_key VARCHAR(50) NOT NULL,
                                          project_key VARCHAR(50) NOT NULL,
                                          assignee_name VARCHAR(255),
                                          issue_type_name VARCHAR(150),
                                          cell_name VARCHAR(150),
                                          tribe_name VARCHAR(150),
                                          cycle_time BIGINT NOT NULL,
                                          status_count INT NOT NULL,
                                          final_date DATE NOT NULL,
                                          year INT NOT NULL,
                                          month INT NOT NULL,
                                          cell_id INT,
                                          tribe_id INT
);

CREATE INDEX IDX_PROJECT_KEY ON MST.CYCLE_TIME_FACT (project_key);
CREATE INDEX IDX_FINAL_DATE ON MST.CYCLE_TIME_FACT (final_date);
CREATE INDEX IDX_ASSIGNEE_NAME ON MST.CYCLE_TIME_FACT (assignee_name);
CREATE INDEX IDX_ISSUE_TYPE_NAME ON MST.CYCLE_TIME_FACT (issue_type_name);
CREATE INDEX IDX_ISSUE_CELL_ID ON MST.CYCLE_TIME_FACT (cell_id);
CREATE INDEX IDX_ISSUE_TRIBE_ID ON MST.CYCLE_TIME_FACT (tribe_id);


