CREATE TABLE RAW.JIRA_PROJECTS
(
    id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    archived BIT ,
    archived_by NVARCHAR(11),
    archived_date DATETIME,
    deleted BIT,
    deleted_by NVARCHAR(51),
    deleted_date DATETIME,
    description NVARCHAR(501),
    is_private BIT NOT NULL,
    name NVARCHAR(100),
    project_key NVARCHAR(11) UNIQUE NOT NULL,
    project_id NVARCHAR(11),
    project_type NVARCHAR(21),
    project_category_id NVARCHAR(11),
    project_category_name NVARCHAR(101),
    created_at DATETIME NOT NULL DEFAULT GETDATE(),
    process_date DATE,
    cell_id NVARCHAR(11),
    tribe_id NVARCHAR(11),
    style NVARCHAR(21)
);

CREATE TABLE CUR.JIRA_PROJECTS
(
    id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    description NVARCHAR(500),
    name NVARCHAR(100),
    project_key NVARCHAR(10) UNIQUE NOT NULL,
    project_id NVARCHAR(10),
    project_type NVARCHAR(20),
    project_category_id NVARCHAR(10),
    project_category_name NVARCHAR(100),
    created_at DATETIME NOT NULL DEFAULT GETDATE(),
    process_date DATE,
    cell_id INT,
    tribe_id INT,
    cell_name NVARCHAR(150),
    tribe_name NVARCHAR(150),
);


CREATE INDEX idx_raw_jira_project_key ON RAW.JIRA_PROJECTS (project_key);
CREATE INDEX idx_raw_jira_project_id ON RAW.JIRA_PROJECTS (project_id);
CREATE INDEX idx_raw_jira_process_date ON RAW.JIRA_PROJECTS (process_date);
CREATE INDEX idx_raw_jira_project_category_id ON RAW.JIRA_PROJECTS (project_category_id);
CREATE INDEX idx_raw_jira_project_category_name ON RAW.JIRA_PROJECTS (project_category_name);
CREATE INDEX idx_raw_jira_cell_id ON RAW.JIRA_PROJECTS (cell_id);
CREATE INDEX idx_raw_jira_tribe_id ON RAW.JIRA_PROJECTS (tribe_id);



CREATE INDEX idx_cur_jira_project_key ON CUR.JIRA_PROJECTS (project_key);
CREATE INDEX idx_cur_jira_project_id ON CUR.JIRA_PROJECTS (project_id);
CREATE INDEX idx_cur_jira_process_date ON CUR.JIRA_PROJECTS (process_date);
CREATE INDEX idx_cur_jira_project_category_id ON CUR.JIRA_PROJECTS (project_category_id);
CREATE INDEX idx_cur_jira_project_category_name ON CUR.JIRA_PROJECTS (project_category_name);
CREATE INDEX idx_cur_jira_cell_id ON CUR.JIRA_PROJECTS (cell_id);
CREATE INDEX idx_cur_jira_tribe_id ON CUR.JIRA_PROJECTS (tribe_id);
CREATE INDEX idx_cur_jira_cell_name ON CUR.JIRA_PROJECTS (cell_name);
CREATE INDEX idx_cur_jira_tribe_name ON CUR.JIRA_PROJECTS (tribe_name);
