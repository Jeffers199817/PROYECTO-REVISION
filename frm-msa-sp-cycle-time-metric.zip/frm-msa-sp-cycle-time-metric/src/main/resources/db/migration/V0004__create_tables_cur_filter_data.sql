CREATE TABLE CUR.DATA_FILTER
(
    id          INT IDENTITY (1,1) PRIMARY KEY,
    stage       VARCHAR(20)   NOT NULL CHECK (stage IN ('RAW', 'CUR', 'MST')),
    operator    VARCHAR(3)    NOT NULL CHECK (operator IN ('AND', 'OR')),
    tasklet     VARCHAR(100)  NOT NULL,
    variable    VARCHAR(100)  NOT NULL,
    expression  VARCHAR(5000) NOT NULL,
    description NVARCHAR(255) NULL,
    enabled     BIT      DEFAULT 1,
    created_at  DATETIME DEFAULT GETDATE()
);