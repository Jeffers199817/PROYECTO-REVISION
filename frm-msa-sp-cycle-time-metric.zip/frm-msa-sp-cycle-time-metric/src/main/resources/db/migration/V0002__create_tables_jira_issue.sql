CREATE TABLE RAW.JIRA_ISSUES (
                             id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                             project_key VARCHAR(50) NOT NULL,
                             issue_id BIGINT NOT NULL,
                             issue_key VARCHAR(50) NOT NULL,
                             summary TEXT NOT NULL,
                             issue_type_name VARCHAR(100) NOT NULL,
                             issue_type_subtask BIT NOT NULL,
                             issue_type_id VARCHAR(20) NOT NULL,
                             reporter_email VARCHAR(100),
                             reporter_name VARCHAR(200),
                             reporter_active BIT,
                             assignee_email VARCHAR(100),
                             assignee_name VARCHAR(200),
                             assignee_active BIT,
                             issue_partner VARCHAR(50),
                             status_name VARCHAR(100) NOT NULL,
                             issue_created DATETIME NOT NULL,
                             status_id BIGINT NOT NULL
);

CREATE TABLE CUR.JIRA_ISSUES (
                                 id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                 project_key VARCHAR(50) NOT NULL,
                                 issue_key VARCHAR(50) NOT NULL,
                                 issue_type_name VARCHAR(100) NOT NULL,
                                 assignee_email VARCHAR(100),
                                 assignee_name VARCHAR(200),
                                 issue_partner VARCHAR(50),
                                 status_name VARCHAR(100) NOT NULL,
                                 issue_created DATETIME NOT NULL,
                                 process_date DATE,
                                 status_id BIGINT NOT NULL,
                                 cell_id INT,
                                 tribe_id INT,
                                 cell_name NVARCHAR(150),
                                 tribe_name NVARCHAR(150),
);

CREATE INDEX idx_jira_issue_project_key ON CUR.JIRA_ISSUES (project_key);
CREATE INDEX idx_jira_issue_key ON CUR.JIRA_ISSUES (issue_key);
CREATE INDEX idx_jira_issue_type_name ON CUR.JIRA_ISSUES (issue_type_name);
CREATE INDEX idx_jira_issue_process_date ON CUR.JIRA_ISSUES (process_date);

CREATE INDEX idx_jira_issue_key ON RAW.JIRA_ISSUES (issue_key);
CREATE INDEX idx_jira_issue_project_key ON RAW.JIRA_ISSUES (project_key);
CREATE INDEX idx_jira_issue_type_name ON RAW.JIRA_ISSUES (issue_type_name);
