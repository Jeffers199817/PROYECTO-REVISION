CREATE TABLE CUR.JIRA_ISSUE_STATUS_DURATION
(
    id               BIGINT IDENTITY (1,1) PRIMARY KEY,
    issue_key        VARCHAR(50)   NOT NULL,
    project_key      VARCHAR(50)   NOT NULL,
    end_date DATE,
    process_date DATE,
    status_durations NVARCHAR(MAX) NOT NULL
);

CREATE INDEX IDX_PROJECT_KEY ON CUR.JIRA_ISSUE_STATUS_DURATION (project_key);
CREATE INDEX idx_cur_issue_status_duration_issue_key ON CUR.JIRA_ISSUE_STATUS_DURATION (issue_key);
CREATE INDEX idx_cur_issue_status_duration_end_date ON CUR.JIRA_ISSUE_STATUS_DURATION (end_date);
CREATE INDEX idx_cur_issue_status_duration_process_date ON CUR.JIRA_ISSUE_STATUS_DURATION (process_date);
