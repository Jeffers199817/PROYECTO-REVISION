package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.FilterJiraIssueTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
class FilterJiraIssueTaskletTest {

  private static final String PROJECT_KEY = "PROJ1";
  private static final String ISSUE_KEY = "PROJ1-123";

  @Mock private CurJiraProjectRepository curProjectRepository;
  @Mock private RawJiraIssueRepository rawIssueRepository;
  @Mock private CurJiraIssueRepository repository;
  @Mock private CurDataFilterRepository dataFilterRepository;

  @InjectMocks private FilterJiraIssueTasklet tasklet;
  @Mock private StepContribution stepContribution;
  @Mock private ChunkContext chunkContext;

  private CurJiraProject mockCurProject;
  private JiraIssue mockJiraIssue;
  @BeforeEach
  void setUp() {
    mockCurProject = new CurJiraProject();
    mockCurProject.setProjectKey(PROJECT_KEY);

    mockJiraIssue = new JiraIssue();
    mockJiraIssue.setIssueKey(ISSUE_KEY);
    mockJiraIssue.setProjectKey(PROJECT_KEY);
    mockJiraIssue.setIssueTypeName("Bug");
    mockJiraIssue.setAssigneeEmail("assignee@example.com");
    mockJiraIssue.setAssigneeName("John Doe");
    mockJiraIssue.setStatusName("Done");
    mockJiraIssue.setStatusId(10001L);
    mockJiraIssue.setIssueCreated(LocalDateTime.now());

  }

  @Test
  void executeShouldProcessAndSaveFilteredIssues() throws Exception {
    // Mockeamos los datos de entrada
    when(dataFilterRepository.findByStageAndTasklet("CUR", FilterJiraIssueTasklet.class.getSimpleName()))
        .thenReturn(List.of(new DataFilter()));

    when(curProjectRepository.findByOffsetAndBatchSizeProcessDateNow(anyInt(), anyInt(), any()))
        .thenReturn(List.of(mockCurProject))
        .thenReturn(Collections.emptyList());

    when(rawIssueRepository.findByProjectKey(PROJECT_KEY)).thenReturn(List.of(mockJiraIssue));
    when(repository.findByIssueKey(ISSUE_KEY)).thenReturn(null); // Simula que no existe aún en la BD

    try (MockedStatic<FiltersUtils> mockedFilters = mockStatic(FiltersUtils.class)) {
      mockedFilters.when(() -> FiltersUtils.evaluateFilters(any(CurJiraIssue.class), anyList()))
          .thenReturn(true);

      RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

      verify(repository, times(1)).saveAllAndFlush(anyList());
      assertEquals(RepeatStatus.FINISHED, status);
    }
  }

  @Test
  void executeShouldNotSaveIfNoIssuesPassFilters() throws Exception {
    when(dataFilterRepository.findByStageAndTasklet("CUR", FilterJiraIssueTasklet.class.getSimpleName()))
        .thenReturn(List.of(new DataFilter()));

    when(curProjectRepository.findByOffsetAndBatchSizeProcessDateNow(anyInt(), anyInt(), any()))
        .thenReturn(List.of(mockCurProject))
        .thenReturn(Collections.emptyList());

    when(rawIssueRepository.findByProjectKey(PROJECT_KEY)).thenReturn(List.of(mockJiraIssue));
    when(repository.findByIssueKey(ISSUE_KEY)).thenReturn(null);

    try (MockedStatic<FiltersUtils> mockedFilters = mockStatic(FiltersUtils.class)) {
      mockedFilters.when(() -> FiltersUtils.evaluateFilters(any(CurJiraIssue.class), anyList()))
          .thenReturn(false);

      RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

      verify(repository, times(1)).saveAllAndFlush(anyList());
      assertEquals(RepeatStatus.FINISHED, status);
    }
  }

  @Test
  void executeShouldHandleEmptyProjectList() throws Exception {
    when(curProjectRepository.findByOffsetAndBatchSizeProcessDateNow(anyInt(), anyInt(), any()))
        .thenReturn(Collections.emptyList());

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    verify(repository, never()).saveAllAndFlush(anyList());
    assertEquals(RepeatStatus.FINISHED, status);
  }

}