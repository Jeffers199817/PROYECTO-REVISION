package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import com.pichincha.sp.cycle.time.metric.repository.JiraRepository;
import com.pichincha.sp.cycle.time.metric.repository.dto.ChangelogResponse;
import com.pichincha.sp.cycle.time.metric.repository.dto.ChangelogResponse.Changelog;
import com.pichincha.sp.cycle.time.metric.repository.dto.ChangelogResponse.Changelog.Author;
import com.pichincha.sp.cycle.time.metric.repository.dto.ChangelogResponse.Changelog.Item;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraChangelog;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.InsertChangelogTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.InsertJiraIssuesTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraIssueRepository;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
class InsertChangelogTaskletTest {

  @Mock
  private JiraRepository jiraRepository;

  @Mock
  private RawJiraChangelogRepository changelogRepository;

  @Mock
  private RawJiraIssueRepository issueRepository;

  @InjectMocks
  private InsertChangelogTasklet tasklet;

  @Mock
  private StepContribution stepContribution;

  @Mock
  private ChunkContext chunkContext;

  @Mock
  private CurDataFilterRepository dataFilterRepository;

  @Mock
  private ApplicationProperties applicationProperties;

  @BeforeEach
  void setUp() {
    when(applicationProperties.threads()).thenReturn(new ApplicationProperties.Threads(1, 1));
    when(issueRepository.findIssueKeys(anyInt(), anyInt()))
        .thenReturn(List.of("PROJ1-123"))
        .thenReturn(Collections.emptyList());

    when(dataFilterRepository.findByStageAndTasklet(eq("RAW"), eq(InsertChangelogTasklet.class.getSimpleName())))
      .thenReturn(Collections.emptyList());
  }

  @Test
  void executeShouldProcessChangelogAndSave() {
    ChangelogResponse responseMock = mock(ChangelogResponse.class);
    when(responseMock.getIsLast()).thenReturn(true);

    Changelog changelogMock = mock(Changelog.class);
    when(changelogMock.getId()).thenReturn("98765");
    when(changelogMock.getCreated()).thenReturn("2024-02-01T12:00:00.000+0000");

    Changelog.Author authorMock = mock(Changelog.Author.class);
    when(changelogMock.getAuthor()).thenReturn(null).thenReturn(authorMock);

    when(authorMock.getEmailAddress()).thenReturn("test@example.com");
    when(authorMock.getDisplayName()).thenReturn("Test User");
    when(authorMock.isActive()).thenReturn(true);

    Item itemMock = mock(Item.class);
    when(itemMock.getField()).thenReturn("status");
    when(itemMock.getFieldType()).thenReturn("jira");
    when(itemMock.getFieldId()).thenReturn("10010");
    when(itemMock.getFrom()).thenReturn("To Do");
    when(itemMock.getFromString()).thenReturn("To Do");
    when(itemMock.getTo()).thenReturn("In Progress");
    when(itemMock.getToString()).thenReturn("In Progress");

    when(changelogMock.getItems()).thenReturn(List.of(itemMock));
    when(responseMock.getValues()).thenReturn(List.of(changelogMock));

    when(jiraRepository.getChangelog(anyString(), anyInt(), anyInt()))
        .thenReturn(responseMock);

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    verify(changelogRepository, times(1)).truncateTable();
    verify(issueRepository, atLeast(2)).findIssueKeys(anyInt(), anyInt());
    verify(jiraRepository, atLeastOnce()).getChangelog(anyString(), anyInt(), anyInt());
    verify(changelogRepository, atLeastOnce()).saveAllAndFlush(anyList());

    assertEquals(RepeatStatus.FINISHED, status);
  }
  // El método de prueba para mapToJiraChangelog se ha movido a una clase separada
  // para evitar conflictos con Mockito: MapToJiraChangelogTest
}