package com.pichincha.sp.cycle.time.metric.listener;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.http.HttpEntity;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class JobCompletionNotificationListenerTest {

  @Mock
  private ApplicationProperties applicationProperties;

  private final String teamsWebhook = "http://fake-webhook-url";

  @Mock
  private RestTemplate restTemplate;

  @InjectMocks
  private JobCompletionNotificationListener listener;

  private JobExecution jobExecution;

  @BeforeEach
  void setUp() {
    jobExecution = mock(JobExecution.class);
  }

  @Test
  void afterJobShouldNotSendNotificationWhenEnvironmentIsNotProduction() {
    when(applicationProperties.environment()).thenReturn("dev");
    when(jobExecution.getStatus()).thenReturn(BatchStatus.COMPLETED);

    listener.afterJob(jobExecution);

    verify(applicationProperties, times(1)).environment();
    verifyNoInteractions(restTemplate); // No se debe llamar a Teams en entornos distintos a producción
  }

  @Test
  void afterJobShouldSendNotificationOnSuccessWhenEnvironmentIsProduction() {
    when(applicationProperties.environment()).thenReturn("production");
    when(applicationProperties.teamsWebhook()).thenReturn(teamsWebhook);
    when(jobExecution.getStatus()).thenReturn(BatchStatus.COMPLETED);

    listener.afterJob(jobExecution);

    ArgumentCaptor<HttpEntity<String>> captor = ArgumentCaptor.forClass(HttpEntity.class);
    verify(restTemplate, times(1)).postForEntity(eq(teamsWebhook), captor.capture(), eq(String.class));


    HttpEntity<String> requestSent = captor.getValue();
    assertTrue(requestSent.getBody().contains("El job ha finalizado correctamente."));
    assertTrue(requestSent.getBody().contains("✅"));
  }

  @Test
  void afterJobShouldSendNotificationOnFailureWhenEnvironmentIsProduction() {
    when(applicationProperties.environment()).thenReturn("production");
    when(applicationProperties.teamsWebhook()).thenReturn(teamsWebhook);
    when(jobExecution.getStatus()).thenReturn(BatchStatus.FAILED);

    listener.afterJob(jobExecution);

    ArgumentCaptor<HttpEntity<String>> captor = ArgumentCaptor.forClass(HttpEntity.class);
    verify(restTemplate, times(1)).postForEntity(eq(teamsWebhook), captor.capture(), eq(String.class));

    HttpEntity<String> requestSent = captor.getValue();
    assertTrue(requestSent.getBody().contains("El job ha fallado."));
    assertTrue(requestSent.getBody().contains("❌"));
  }
}