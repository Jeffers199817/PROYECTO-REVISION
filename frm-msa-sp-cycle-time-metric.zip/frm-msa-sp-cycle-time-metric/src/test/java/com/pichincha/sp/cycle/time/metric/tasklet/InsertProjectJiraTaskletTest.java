package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import com.pichincha.sp.cycle.time.metric.repository.JiraRepository;
import com.pichincha.sp.cycle.time.metric.repository.dto.JiraProjectResponse;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.InsertProjectJiraTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class InsertProjectJiraTaskletTest {

  @Mock
  private JiraRepository jiraRepository;

  @Mock
  private RawJiraProjectRepository repository;

  @Mock
  private ApplicationProperties properties;

  @Mock
  private CurDataFilterRepository dataFilterRepository;

  @InjectMocks
  private InsertProjectJiraTasklet tasklet;

  @Mock
  private StepContribution stepContribution;

  @Mock
  private ChunkContext chunkContext;

  @BeforeEach
  void setUp() {
    lenient().when(properties.includePrivateProjects()).thenReturn(true);
  }

  @Test
  void executeShouldTruncateTableAndProcessProjects() {
    when(dataFilterRepository.findByStageAndTasklet(eq("RAW"), eq(InsertProjectJiraTasklet.class.getSimpleName())))
        .thenReturn(Collections.emptyList());

    JiraProjectResponse mockResponse = mock(JiraProjectResponse.class);
    when(mockResponse.getValues()).thenReturn(Collections.emptyList());
    when(mockResponse.getIsLast()).thenReturn(true);

    when(jiraRepository.getProjects(anyInt(), anyInt(), anyString(), anyString())).thenReturn(mockResponse);

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    verify(repository, times(1)).truncateTable();
    verify(jiraRepository, atLeastOnce()).getProjects(anyInt(), anyInt(), anyString(), anyString());
    assertEquals(RepeatStatus.FINISHED, status);
  }

  @Test
  void executeShouldFilterAndSaveProjects() {
    DataFilter mockFilter = mock(DataFilter.class);
    when(dataFilterRepository.findByStageAndTasklet(eq("RAW"), eq(InsertProjectJiraTasklet.class.getSimpleName())))
        .thenReturn(List.of(mockFilter));

    JiraProjectResponse.Project mockProject = mock(JiraProjectResponse.Project.class);
    when(mockProject.getIsPrivate()).thenReturn(true);

    JiraProjectResponse mockResponse = mock(JiraProjectResponse.class);
    when(mockResponse.getValues()).thenReturn(List.of(mockProject));
    when(mockResponse.getIsLast()).thenReturn(true);
    when(mockProject.getDescription()).thenReturn("Some description");

    when(jiraRepository.getProjects(anyInt(), anyInt(), anyString(), anyString())).thenReturn(mockResponse);

    try (MockedStatic<FiltersUtils> mockedFilters = mockStatic(FiltersUtils.class)) {
      mockedFilters.when(() -> FiltersUtils.evaluateFilters(any(JiraProject.class), ArgumentMatchers.<List<DataFilter>>any()))
          .thenReturn(true);

      RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

      verify(repository, times(1)).saveAllAndFlush(anyList());
      assertEquals(RepeatStatus.FINISHED, status);
    }
  }
}
