package com.pichincha.sp.cycle.time.metric.service;


import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.lenient;

import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.ContextConfiguration;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@ContextConfiguration(classes = {BatchJobServiceTest.TestTaskExecutorConfig.class})
class BatchJobServiceTest {

  @Mock
  private JobLauncher jobLauncher;

  @InjectMocks
  private BatchJobService batchJobService;


  @Autowired
  private ThreadPoolTaskExecutor pool;

  @BeforeEach
  void setUp() throws Exception {

    try (AutoCloseable mocks = MockitoAnnotations.openMocks(this)) {
      lenient().when(jobLauncher.run(any(Job.class), any(JobParameters.class))).thenReturn(null);
    }
  }


  @Test
  void runJobAsyncWithRawStageShouldLaunchRawJob() throws InterruptedException {
    batchJobService.runJobAsync("RAW");

    boolean awaitTermination = pool.getThreadPoolExecutor().awaitTermination(1, TimeUnit.SECONDS);
    assertThat(awaitTermination).isFalse();

  }

  @Test
  void runJobAsyncWithRawStageShouldLaunchCuradaJob() throws InterruptedException {
    batchJobService.runJobAsync("CURADA");

    boolean awaitTermination = pool.getThreadPoolExecutor().awaitTermination(1, TimeUnit.SECONDS);
    assertThat(awaitTermination).isFalse();

  }

  @Test
  void runJobAsyncWithRawStageShouldLaunchMasterJob() throws InterruptedException {
    batchJobService.runJobAsync("MASTER");

    boolean awaitTermination = pool.getThreadPoolExecutor().awaitTermination(1, TimeUnit.SECONDS);
    assertThat(awaitTermination).isFalse();

  }

  @Test
  void runJobAsyncWithRawStageShouldLaunchAllJob() throws InterruptedException {
    batchJobService.runJobAsync("ALL");

    boolean awaitTermination = pool.getThreadPoolExecutor().awaitTermination(1, TimeUnit.SECONDS);
    assertThat(awaitTermination).isFalse();

  }

  @Configuration
  static class TestTaskExecutorConfig {
    @Bean
    public ThreadPoolTaskExecutor taskExecutor() {
      ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
      executor.setCorePoolSize(1);
      executor.setMaxPoolSize(1);
      executor.setQueueCapacity(1);
      executor.setThreadNamePrefix("TestExecutor-");
      executor.initialize();
      return executor;
    }
  }

}