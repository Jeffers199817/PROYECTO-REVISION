package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.FilterJiraChangelogTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraChangelog;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraChangelog;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
class FilterJiraChangelogTaskletTest {

  public static final String ISSUE_KEY = "ISSUE-123";
  @Mock
  private CurJiraIssueRepository curIssueRepository;

  @Mock
  private CurJiraChangelogRepository curChangelogRepository;

  @Mock
  private RawJiraChangelogRepository rawChangelogRepository;

  @Mock
  private CurDataFilterRepository dataFilterRepository;

  @InjectMocks
  private FilterJiraChangelogTasklet tasklet;

  @Mock
  private StepContribution stepContribution;

  @Mock
  private ChunkContext chunkContext;

  @BeforeEach
  void setUp() {
    when(dataFilterRepository.findByStageAndTasklet(anyString(), anyString()))
        .thenReturn(Collections.emptyList());
    when(curIssueRepository.findIssueKeysAndProcessDateNow(anyInt(), anyInt(), any()))
        .thenReturn(List.of(ISSUE_KEY))
        .thenReturn(Collections.emptyList());
  }

  @Test
  void testExecuteWhenIssuesAreProcessedThenSavesFilteredChangelogsAndBreaksLoop() {
    List<JiraChangelog> rawChangelogs = List.of(
        JiraChangelog.builder()
            .changelogId(123L)
            .issueKey(ISSUE_KEY)
            .authorEmail("author@mail.com")
            .authorName("Author")
            .changelogCreated(LocalDateTime.now())
            .itemField("Status")
            .itemFrom("Open")
            .itemTo("Closed")
            .itemFromString("Open")
            .itemToString("Closed")
            .build()
    );

    when(rawChangelogRepository.findByIssueKey(ISSUE_KEY)).thenReturn(rawChangelogs);
    when(curChangelogRepository.findByChangelogId(anyLong())).thenReturn(null);
    when(curChangelogRepository.saveAllAndFlush(anyList())).thenReturn(Collections.emptyList());

    try (MockedStatic<FiltersUtils> filtersUtilsMockedStatic = mockStatic(FiltersUtils.class)) {
      filtersUtilsMockedStatic.when(() -> FiltersUtils.evaluateFilters(any(CurJiraChangelog.class), anyList()))
          .thenReturn(true);

      RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

      assertEquals(RepeatStatus.FINISHED, status);
      verify(curIssueRepository, times(2)).findIssueKeysAndProcessDateNow(anyInt(), anyInt(), any());
      verify(rawChangelogRepository, atLeastOnce()).findByIssueKey(anyString());
      verify(curChangelogRepository, atLeastOnce()).saveAllAndFlush(anyList());
    }
  }
}
