package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.DurationIssueStatusTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraChangelog;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurIssueStatusDurationRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraChangelogRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;

@ExtendWith(MockitoExtension.class)
class DurationIssueStatusTaskletTest {

  public static final String ISSUE_KEY = "ISSUE-123";
  public static final String PROJECT_KEY = "PROJECT-1";
  @Mock
  private CurJiraChangelogRepository changelogRepository;

  @Mock
  private CurJiraIssueRepository issueRepository;

  @Mock
  private CurDataFilterRepository dataFilterRepository;

  @Mock
  private CurIssueStatusDurationRepository issueStatusDurationRepository;


  @InjectMocks
  private DurationIssueStatusTasklet tasklet;

  @Mock
  private StepContribution stepContribution;

  @Mock
  private ChunkContext chunkContext;

  @BeforeEach
  void setUp() {
    when(dataFilterRepository.findByStageAndTasklet(anyString(), anyString()))
        .thenReturn(Collections.emptyList());
  }

  @Test
  void testExecuteWhenIssuesExistThenProcessAndSave() throws Exception {
    CurJiraIssue issue = CurJiraIssue.builder()
        .issueKey(ISSUE_KEY)
        .projectKey(PROJECT_KEY)
        .build();

    List<CurJiraChangelog> changelogs = List.of(
        CurJiraChangelog.builder()
            .changelogCreated(LocalDateTime.now().minusDays(2))
            .itemToString("Open")
            .build(),
        CurJiraChangelog.builder()
            .changelogCreated(LocalDateTime.now().minusDays(1))
            .itemToString("In Progress")
            .build()
    );

    when(issueRepository.findByProcessDate(any())).thenReturn(List.of(issue));
    when(changelogRepository.findByIssueKey(ISSUE_KEY)).thenReturn(changelogs);

    tasklet.execute(stepContribution, chunkContext);

    verify(issueStatusDurationRepository, times(1)).saveAllAndFlush(anyList());
  }

  @Test
  void testExecuteWhenNoIssuesThenNoProcessing() throws Exception {

    when(issueRepository.findByProcessDate(any())).thenReturn(Collections.emptyList());
    tasklet.execute(stepContribution, chunkContext);

    verify(issueStatusDurationRepository, never()).saveAllAndFlush(anyList());
  }


  @Test
  void testExecuteWhenFiltersAppliedThenCorrectDurationsSaved() throws Exception {
    CurJiraIssue issue = CurJiraIssue.builder()
        .issueKey(ISSUE_KEY)
        .projectKey(PROJECT_KEY)
        .build();

    List<CurJiraChangelog> changelogs = List.of(
        CurJiraChangelog.builder()
            .changelogCreated(LocalDateTime.now().minusDays(3))
            .itemToString("Open")
            .build(),
        CurJiraChangelog.builder()
            .changelogCreated(LocalDateTime.now().minusDays(1))
            .itemToString("Closed")
            .build()
    );

    when(issueRepository.findByProcessDate(any())).thenReturn(List.of(issue));
    when(changelogRepository.findByIssueKey(ISSUE_KEY)).thenReturn(changelogs);

    try (MockedStatic<FiltersUtils> filtersUtilsMockedStatic = mockStatic(FiltersUtils.class)) {
      filtersUtilsMockedStatic.when(() -> FiltersUtils.evaluateFilters(any(), anyList()))
          .thenReturn(true);

      tasklet.execute(stepContribution, chunkContext);

      verify(issueStatusDurationRepository, times(1)).saveAllAndFlush(anyList());
    }
  }
}