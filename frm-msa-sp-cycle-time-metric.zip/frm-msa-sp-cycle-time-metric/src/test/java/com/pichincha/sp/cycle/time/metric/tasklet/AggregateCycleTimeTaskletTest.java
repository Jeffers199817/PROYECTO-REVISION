package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pichincha.sp.cycle.time.metric.exception.CustomException;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurIssueStatusDuration;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurIssueStatusDurationRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.AggregateCycleTimeTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.FactCycleTime;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.MasterCycleTimeRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
class AggregateCycleTimeTaskletTest {

  public static final String PROJ_1 = "PROJ-1";
  public static final String ISSUE_KEY = "ISSUE-123";
  @Mock
  private CurIssueStatusDurationRepository statusDurationRepository;

  @Mock
  private CurJiraIssueRepository issueRepository;

  @Mock
  private CurJiraProjectRepository projectRepository;

  @Mock
  private MasterCycleTimeRepository masterCycleTimeRepository;

  @Mock
  private ObjectMapper objectMapper;

  @InjectMocks
  private AggregateCycleTimeTasklet tasklet;

  @Mock
  private StepContribution stepContribution;

  @Mock
  private ChunkContext chunkContext;



  @BeforeEach
  void setUp() {

    CurJiraIssue mockIssue;
    CurIssueStatusDuration mockDuration;

    mockIssue = CurJiraIssue.builder()
        .issueKey(ISSUE_KEY)
        .projectKey(PROJ_1)
        .assigneeName("John Doe")
        .issueTypeName("Bug")
        .build();

    mockDuration = CurIssueStatusDuration.builder()
        .issueKey(ISSUE_KEY)
        .statusDurations("{\"Open\": 172800}")
        .endDate(LocalDate.now())
        .build();

    when(statusDurationRepository.findByEndDateBetween(any(), any())).thenReturn(List.of(mockDuration));
    when(issueRepository.findByIssueKey(ISSUE_KEY)).thenReturn(mockIssue);
  }

  @Test
  void testExecuteWhenProjectsExistThenProcessesDataAndBreaksLoop() throws Exception {

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    assertEquals(RepeatStatus.FINISHED, status);
  }
}