package com.pichincha.sp.cycle.time.metric.tasklet;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.repository.JiraRepository;
import com.pichincha.sp.cycle.time.metric.repository.dto.IssueResponse;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.DataFilter;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.InsertJiraIssuesTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraIssue;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraIssueRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
class InsertJiraIssuesTaskletTest {

  @Mock
  private JiraRepository jiraRepository;

  @Mock
  private RawJiraIssueRepository issueRepository;

  @Mock
  private RawJiraProjectRepository projectRepository;

  @Mock
  private CurDataFilterRepository dataFilterRepository;

  @InjectMocks
  private InsertJiraIssuesTasklet tasklet;

  @Mock
  private StepContribution stepContribution;

  @Mock
  private ChunkContext chunkContext;

  @BeforeEach
  void setUp() {
    lenient().when(projectRepository.findAll()).thenReturn(Collections.emptyList());
  }

  @Test
  void executeShouldTruncateTableAndProcessProjects() {
    when(dataFilterRepository.findByStageAndTasklet(eq("RAW"), eq(InsertJiraIssuesTasklet.class.getSimpleName())))
        .thenReturn(Collections.emptyList());

    JiraProject project = JiraProject.builder()
        .projectKey("PROJ1")
        .build();

    when(projectRepository.findAll()).thenReturn(List.of(project));

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    verify(issueRepository, times(1)).truncateTable();
    verify(projectRepository, times(1)).findAll();
    assertEquals(RepeatStatus.FINISHED, status);
  }

  @Test
  void fetchIssuesShouldFilterAndSaveIssues() {

    JiraProject project = JiraProject.builder()
        .projectKey("PROJ1")
        .build();

    when(projectRepository.findAll()).thenReturn(List.of(project));

    DataFilter mockFilter = mock(DataFilter.class);
    when(dataFilterRepository.findByStageAndTasklet(eq("RAW"), eq(InsertJiraIssuesTasklet.class.getSimpleName())))
        .thenReturn(List.of(mockFilter));

    IssueResponse.Issue mockIssue = mock(IssueResponse.Issue.class);
    when(mockIssue.getId()).thenReturn("12345");
    when(mockIssue.getKey()).thenReturn("PROJ1-1");

    IssueResponse.Issue.Fields mockFields = mock(IssueResponse.Issue.Fields.class);
    when(mockIssue.getFields()).thenReturn(mockFields);
    when(mockFields.getSummary()).thenReturn("Test Summary");

    IssueResponse.Issue.Fields.Status mockStatus = mock(IssueResponse.Issue.Fields.Status.class);
    when(mockFields.getStatus()).thenReturn(mockStatus);
    when(mockStatus.getName()).thenReturn("Done");

    IssueResponse.Issue.Fields.IssueType mockIssueType = mock(IssueResponse.Issue.Fields.IssueType.class);
    when(mockFields.getIssueType()).thenReturn(mockIssueType);
    when(mockIssueType.getName()).thenReturn("Bug");
    when(mockIssueType.getId()).thenReturn("10001");
    when(mockIssueType.isSubtask()).thenReturn(false);

    when(mockFields.getCreated()).thenReturn("2024-02-01T12:00:00.000+0000");

    IssueResponse.Issue.Fields.User mockReporter = mock(IssueResponse.Issue.Fields.User.class);
    when(mockFields.getReporter()).thenReturn(mockReporter);
    when(mockReporter.getEmailAddress()).thenReturn("reporter@example.com");
    when(mockReporter.getDisplayName()).thenReturn("Reporter Name");
    when(mockReporter.isActive()).thenReturn(true);

    IssueResponse.Issue.Fields.User mockAssignee = mock(IssueResponse.Issue.Fields.User.class);
    when(mockFields.getAssignee()).thenReturn(mockAssignee);
    when(mockAssignee.getEmailAddress()).thenReturn("assignee@example.com");
    when(mockAssignee.getDisplayName()).thenReturn("Assignee Name");
    when(mockAssignee.isActive()).thenReturn(false);

    IssueResponse mockResponse = mock(IssueResponse.class);
    when(mockResponse.getIssues()).thenReturn(List.of(mockIssue));
    when(mockResponse.getTotal()).thenReturn(1000);

    when(jiraRepository.getIssues(anyString(), anyInt(), anyInt(), anyString())).thenReturn(mockResponse);

    try (MockedStatic<FiltersUtils> mockedFilters = mockStatic(FiltersUtils.class)) {
      mockedFilters.when(() -> FiltersUtils.evaluateFilters(any(JiraIssue.class), anyList()))
          .thenReturn(true);

      tasklet.execute(stepContribution, chunkContext);

      CompletableFuture.runAsync(() -> {}).join();

      verify(issueRepository, atLeastOnce()).saveAllAndFlush(anyList());
    }
  }
}