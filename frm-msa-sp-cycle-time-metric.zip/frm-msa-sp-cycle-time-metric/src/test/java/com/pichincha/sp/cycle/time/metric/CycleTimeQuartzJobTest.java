package com.pichincha.sp.cycle.time.metric;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.pichincha.sp.cycle.time.metric.configuration.ApplicationProperties;
import com.pichincha.sp.cycle.time.metric.job.CycleTimeQuartzJob;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.*;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.jdbc.core.JdbcTemplate;

@ExtendWith(MockitoExtension.class)
class CycleTimeQuartzJobTest {

  @Mock
  private JobLauncher jobLauncher;

  @Mock
  private org.springframework.batch.core.Job batchJob;

  @Mock
  private JdbcTemplate jdbcTemplate;

  @Mock
  private ApplicationProperties applicationProperties;

  @Mock
  private JobExecutionContext jobExecutionContext;

  @Mock
  private Scheduler scheduler;

  @Mock
  private JobDetail jobDetail;

  @Mock
  private JobKey jobKey;

  @InjectMocks
  private CycleTimeQuartzJob cycleTimeQuartzJob;

  @BeforeEach
  void setUp() {
    when(jobExecutionContext.getScheduler()).thenReturn(scheduler);
    when(jobExecutionContext.getJobDetail()).thenReturn(jobDetail);
    when(applicationProperties.startTimeRetry()).thenReturn(5); // Simula un retraso de 5 minutos para reintentos
    when(jobDetail.getJobDataMap()).thenReturn(new JobDataMap()); // Evita NullPointerException
    when(jobDetail.getKey()).thenReturn(jobKey); // Evita NullPointerException en `TriggerBuilder.forJob()`
    when(jobKey.getName()).thenReturn("testJobKey"); // Evita errores en `TriggerBuilder`
  }


  @Test
  void testExecuteWhenJobFailsThenSchedulesRetry() throws Exception {
    JobExecution jobExecution = new JobExecution(1L);
    jobExecution.setStatus(BatchStatus.FAILED);

    when(jobLauncher.run(any(), any())).thenReturn(jobExecution);
    when(jobExecutionContext.getMergedJobDataMap()).thenReturn(new JobDataMap());

    cycleTimeQuartzJob.execute(jobExecutionContext);

    verify(jobLauncher, times(1)).run(any(), any());
    verify(scheduler, times(1)).scheduleJob(any(Trigger.class)); // Debe programar un reintento
  }


  @Test
  void testRegisterFailureAndRetryWhenRetryCountLessThanMaxThenSchedulesRetry() throws SchedulerException {
    JobDataMap jobDataMap = new JobDataMap();
    jobDataMap.put("retryCount", 1);

    when(jobExecutionContext.getJobDetail()).thenReturn(jobDetail);
    when(jobDetail.getJobDataMap()).thenReturn(jobDataMap);

    cycleTimeQuartzJob.execute(jobExecutionContext);

    verify(scheduler, times(1)).scheduleJob(any(Trigger.class)); // Se programa un reintento
  }


}
