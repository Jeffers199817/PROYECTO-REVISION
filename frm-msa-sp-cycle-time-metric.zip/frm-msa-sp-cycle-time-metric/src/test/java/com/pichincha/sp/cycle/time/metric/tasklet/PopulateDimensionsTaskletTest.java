package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.tasklet.master.PopulateDimensionsTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimAssignee;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimDate;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimIssueType;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.DimProject;
import com.pichincha.sp.cycle.time.metric.tasklet.master.domain.FactCycleTime;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimAssigneeRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimDateRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimIssueTypeRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.DimProjectRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.master.repository.MasterCycleTimeRepository;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
class PopulateDimensionsTaskletTest {

  @Mock private MasterCycleTimeRepository masterCycleTimeRepository;
  @Mock private DimDateRepository dimDateRepository;
  @Mock private DimProjectRepository dimProjectRepository;
  @Mock private DimAssigneeRepository dimAssigneeRepository;
  @Mock private DimIssueTypeRepository dimIssueTypeRepository;

  @InjectMocks private PopulateDimensionsTasklet tasklet;

  @Mock private StepContribution stepContribution;
  @Mock private ChunkContext chunkContext;

  @BeforeEach
  void setUp() {
    List<FactCycleTime> mockCycleTimeData;
    mockCycleTimeData = List.of(
        FactCycleTime.builder().year(2024).month(5).projectKey("PROJ-1").tribeName("Tribe A").cellName("Cell X").assigneeName("John Doe").issueTypeName("Bug").build(),
        FactCycleTime.builder().year(2024).month(6).projectKey("PROJ-2").tribeName("Tribe B").cellName("Cell Y").assigneeName("Jane Doe").issueTypeName("Story").build()
    );

    when(masterCycleTimeRepository.findAll()).thenReturn(mockCycleTimeData);
  }

  @Test
  void testExecuteWhenDataExistsThenPopulatesTables() throws Exception {
    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);
    assertEquals(RepeatStatus.FINISHED, status);

    verify(dimDateRepository, times(1)).truncateTable();
    verify(dimProjectRepository, times(1)).truncateTable();
    verify(dimAssigneeRepository, times(1)).truncateTable();
    verify(dimIssueTypeRepository, times(1)).truncateTable();

    // Capturar los argumentos y comparar valores
    ArgumentCaptor<Set<DimDate>> dimDateCaptor = ArgumentCaptor.forClass(Set.class);
    verify(dimDateRepository).saveAllAndFlush(dimDateCaptor.capture());
    assertEquals(2, dimDateCaptor.getValue().size());

    ArgumentCaptor<Set<DimProject>> dimProjectCaptor = ArgumentCaptor.forClass(Set.class);
    verify(dimProjectRepository).saveAllAndFlush(dimProjectCaptor.capture());
    assertEquals(2, dimProjectCaptor.getValue().size());

    ArgumentCaptor<Set<DimAssignee>> dimAssigneeCaptor = ArgumentCaptor.forClass(Set.class);
    verify(dimAssigneeRepository).saveAllAndFlush(dimAssigneeCaptor.capture());
    assertEquals(2, dimAssigneeCaptor.getValue().size());

    ArgumentCaptor<Set<DimIssueType>> dimIssueTypeCaptor = ArgumentCaptor.forClass(Set.class);
    verify(dimIssueTypeRepository).saveAllAndFlush(dimIssueTypeCaptor.capture());
    assertEquals(2, dimIssueTypeCaptor.getValue().size());
  }
}