package com.pichincha.sp.cycle.time.metric.tasklet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.pichincha.sp.cycle.time.metric.tasklet.curada.FilterJiraProjectTasklet;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.BmcCell;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.BmcTribe;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.domain.CurJiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.BmcCellRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.BmcTribeRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurDataFilterRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.curada.repository.CurJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.domain.JiraProject;
import com.pichincha.sp.cycle.time.metric.tasklet.raw.repository.RawJiraProjectRepository;
import com.pichincha.sp.cycle.time.metric.util.FiltersUtils;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

@ExtendWith(MockitoExtension.class)
class FilterJiraProjectTaskletTest {

  @Mock private RawJiraProjectRepository projectRepository;
  @Mock private CurJiraProjectRepository repository;
  @Mock private CurDataFilterRepository dataFilterRepository;
  @Mock private BmcCellRepository cellRepository;
  @Mock private BmcTribeRepository tribeRepository;

  @InjectMocks private FilterJiraProjectTasklet tasklet;

  @Mock private StepContribution stepContribution;
  @Mock private ChunkContext chunkContext;

  private final List<JiraProject> projectBatch = List.of(
      JiraProject.builder()
          .projectKey("PROJ1")
          .description("Project 1 Desc")
          .name("Project 1")
          .projectId("123")
          .projectType("Software")
          .projectCategoryId("10")
          .projectCategoryName("Category A")
          .createdAt(LocalDate.now().atStartOfDay())
          .cellId("1")
          .tribeId("2")
          .build()
  );

  @BeforeEach
  void setUp() {
    lenient().when(dataFilterRepository.findByStageAndTasklet(eq("CUR"), eq(FilterJiraProjectTasklet.class.getSimpleName())))
        .thenReturn(Collections.emptyList());

    lenient().when(cellRepository.findByIdCell(anyInt())).thenReturn(BmcCell.builder().cellName("Cell Name").build());
    lenient().when(tribeRepository.findByIdTribe(anyInt())).thenReturn(BmcTribe.builder().tribeName("Tribe Name").build());
  }


  @Test
  void executeShouldProcessMultipleBatchesAndSave() throws Exception {
    when(projectRepository.findByOffsetAndBatchSize(anyInt(), anyInt()))
        .thenReturn(projectBatch)
        .thenReturn(projectBatch)
        .thenReturn(Collections.emptyList());

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    verify(projectRepository, times(3)).findByOffsetAndBatchSize(anyInt(), anyInt());
    verify(repository, atLeastOnce()).saveAllAndFlush(anyList());

    assertEquals(RepeatStatus.FINISHED, status);
  }

  @Test
  void executeShouldExitLoopWhenNoProjects() throws Exception {
    when(projectRepository.findByOffsetAndBatchSize(anyInt(), anyInt()))
        .thenReturn(Collections.emptyList());

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    verify(repository, never()).saveAllAndFlush(anyList());
    verify(projectRepository, times(1)).findByOffsetAndBatchSize(anyInt(), anyInt());
    assertEquals(RepeatStatus.FINISHED, status);
  }

  @Test
  void executeShouldFilterOutUnwantedProjects() throws Exception {
    try (MockedStatic<FiltersUtils> mockedFilters = mockStatic(FiltersUtils.class)) {
      mockedFilters.when(() -> FiltersUtils.evaluateFilters(any(CurJiraProject.class), anyList()))
          .thenReturn(false);

      when(projectRepository.findByOffsetAndBatchSize(anyInt(), anyInt()))
          .thenReturn(projectBatch)
          .thenReturn(Collections.emptyList());

      RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

      verify(repository, never()).saveAllAndFlush(anyList());
      assertEquals(RepeatStatus.FINISHED, status);
    }
  }

  @Test
  void executeShouldUpdateExistingProject() throws Exception {
    CurJiraProject existingProject = CurJiraProject.builder()
        .projectKey("PROJ1")
        .description("Old Desc")
        .name("Old Name")
        .build();

    when(repository.findByProjectKey(anyString())).thenReturn(existingProject);
    when(projectRepository.findByOffsetAndBatchSize(anyInt(), anyInt()))
        .thenReturn(projectBatch)
        .thenReturn(Collections.emptyList());

    RepeatStatus status = tasklet.execute(stepContribution, chunkContext);

    verify(repository, times(1)).saveAllAndFlush(anyList());
    assertEquals(RepeatStatus.FINISHED, status);
  }
}